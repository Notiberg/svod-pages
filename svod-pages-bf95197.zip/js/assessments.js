(function () {
  'use strict';

  // This is an open, browser-local training assessment, not a secure examination.
  // Answer keys are intentionally available to explain each result to the student.
  const assessments = {
    'yandex-design': {
      id: 'yandex-design',
      title: 'Основы продуктового дизайна',
      description: 'Пользовательские задачи, понятные интерфейсы и работа в Figma.',
      durationMinutes: 7,
      passCount: 4,
      questions: [
        {
          id: 'design-research', type: 'choice',
          prompt: 'Зачем дизайнер проводит интервью с пользователями перед созданием интерфейса?',
          options: ['Чтобы выбрать любимый цвет команды', 'Чтобы понять задачи, контекст и трудности пользователей', 'Чтобы подтвердить любое уже принятое решение', 'Чтобы заменить проверку готового прототипа'],
          correct: 1,
          explanation: 'Интервью помогает понять реальные задачи и ограничения людей. Выводы исследования затем проверяют в проектировании и тестировании.'
        },
        {
          id: 'design-button', type: 'choice',
          prompt: 'Какая подпись основной кнопки понятнее всего в форме записи на мероприятие?',
          options: ['ОК', 'Далее', 'Записаться на мероприятие', 'Нажми сюда'],
          correct: 2,
          explanation: 'Конкретная подпись объясняет результат действия. Человек заранее понимает, что произойдёт после нажатия.'
        },
        {
          id: 'design-component', type: 'choice',
          prompt: 'Нужно использовать одинаковую кнопку на двадцати экранах Figma. Как удобнее поддерживать единый дизайн?',
          options: ['Создать компонент и использовать его экземпляры', 'Нарисовать каждую кнопку заново', 'Экспортировать кнопку картинкой и менять её вручную', 'Сделать кнопки разными, чтобы их было легче различать'],
          correct: 0,
          explanation: 'Компонент объединяет повторяемые элементы. Изменение основного компонента можно распространить на его экземпляры.'
        },
        {
          id: 'design-usability', type: 'choice',
          prompt: 'Как лучше проверить, легко ли новичку найти и отправить заявку в прототипе?',
          options: ['Спросить автора, нравится ли ему макет', 'Посчитать количество теней на экране', 'Показать только красивую обложку', 'Дать представителю аудитории задачу и наблюдать за выполнением'],
          correct: 3,
          explanation: 'Проверка с представителем аудитории показывает, где человек затрудняется. Задачу формулируют без подсказок о нужной кнопке.'
        },
        {
          id: 'design-tool', type: 'word',
          prompt: 'Назови одним словом инструмент из описания практики, в котором создают макеты и интерактивные прототипы интерфейсов.',
          accepted: ['figma', 'фигма'],
          explanation: 'Figma — инструмент для совместной работы над интерфейсами и прототипами. Принимается название на русском или английском.'
        },
        {
          id: 'design-contrast', type: 'word',
          prompt: 'Как одним словом называется различие в яркости текста и фона, влияющее на читаемость?',
          accepted: ['контраст', 'contrast'],
          explanation: 'Контраст помогает отличить текст от фона. Для читаемости важны также размер шрифта, начертание и расстояния.'
        }
      ]
    },
    'sber-frontend': {
      id: 'sber-frontend',
      title: 'Основы frontend-разработки',
      description: 'Семантический HTML, CSS и базовые действия на JavaScript.',
      durationMinutes: 7,
      passCount: 4,
      questions: [
        {
          id: 'frontend-button', type: 'choice',
          prompt: 'Какой HTML-элемент подходит для действия «Отправить сообщение» внутри формы?',
          options: ['<div>', '<span>', '<button type="submit">', '<p>'],
          correct: 2,
          explanation: 'Семантическая кнопка отправки работает с формой и поддерживает стандартные способы взаимодействия, включая клавиатуру.'
        },
        {
          id: 'frontend-flex', type: 'choice',
          prompt: 'У flex-контейнера задано flex-direction: row. Какое свойство распределяет элементы вдоль главной, горизонтальной оси?',
          options: ['justify-content', 'font-weight', 'border-radius', 'text-decoration'],
          correct: 0,
          explanation: 'justify-content управляет распределением элементов вдоль главной оси flex-контейнера. Направление оси зависит от flex-direction.'
        },
        {
          id: 'frontend-text', type: 'choice',
          prompt: 'Нужно показать введённое пользователем сообщение как обычный текст. Какое свойство элемента подходит?',
          options: ['innerHTML', 'textContent', 'outerHTML', 'style.cssText'],
          correct: 1,
          explanation: 'textContent вставляет текст без интерпретации HTML-разметки. Это подходящий способ показать пользовательскую строку как текст.'
        },
        {
          id: 'frontend-equality', type: 'choice',
          prompt: 'Какой результат даст выражение JavaScript 3 === "3"?',
          options: ['true', 'Число 3', 'Строку "3"', 'false'],
          correct: 3,
          explanation: 'Строгое сравнение не приводит операнды к одному типу: число и строка различаются, поэтому результат — false.'
        },
        {
          id: 'frontend-css', type: 'word',
          prompt: 'Какой язык задаёт внешний вид HTML-страницы? Напиши одну латинскую аббревиатуру.',
          accepted: ['css'],
          explanation: 'CSS описывает внешний вид: цвета, размеры, расположение элементов и адаптивное оформление.'
        },
        {
          id: 'frontend-click', type: 'word',
          prompt: 'Как называется DOM-событие обычного клика по кнопке? Напиши одно английское слово без приставки on.',
          accepted: ['click'],
          explanation: 'Название события — click. Обработчик можно подключить, например, через addEventListener("click", ...).'
        }
      ]
    },
    'vk-product': {
      id: 'vk-product',
      title: 'Основы продуктовой аналитики',
      description: 'Метрики, простые расчёты, SQL и работа с таблицами.',
      durationMinutes: 8,
      passCount: 4,
      questions: [
        {
          id: 'analytics-count', type: 'choice',
          prompt: 'Что вычисляет выражение COUNT(*) в SQL-запросе к таблице без GROUP BY?',
          options: ['Сумму чисел во всех столбцах', 'Количество столбцов', 'Количество строк в выбранном наборе', 'Только количество уникальных значений'],
          correct: 2,
          explanation: 'COUNT(*) считает строки в выбранном наборе. Условия WHERE могут предварительно ограничить этот набор.'
        },
        {
          id: 'analytics-experiment', type: 'choice',
          prompt: 'Команда хочет проверить новую форму регистрации с помощью A/B-теста. Как корректнее организовать сравнение?',
          options: ['Случайно распределить пользователей между контрольным и новым вариантами', 'Показать новый вариант только самым активным пользователям', 'Сравнить выходной день нового варианта с будним днём старого', 'Выбрать победителя только по мнению автора макета'],
          correct: 0,
          explanation: 'Случайное распределение помогает получить сопоставимые группы. До запуска также определяют метрику, длительность и правила оценки результата.'
        },
        {
          id: 'analytics-median', type: 'choice',
          prompt: 'Время выполнения задачи у трёх участников: 2, 3 и 100 минут. Чему равна медиана?',
          options: ['2 минуты', '3 минуты', '35 минут', '100 минут'],
          correct: 1,
          explanation: 'Медиана — центральное значение упорядоченного ряда. В ряду 2, 3, 100 в середине находится 3.'
        },
        {
          id: 'analytics-conversion', type: 'choice',
          prompt: 'Форму открыли 100 человек, а отправили 20. Какова конверсия из открытия в отправку?',
          options: ['5%', '80%', '120%', '20%'],
          correct: 3,
          explanation: 'Конверсия равна 20 / 100 × 100% = 20%. В числителе — завершившие целевое действие, в знаменателе — начавшие этот этап.'
        },
        {
          id: 'analytics-select', type: 'word',
          prompt: 'Какое ключевое слово SQL начинает запрос выборки данных? Напиши одно латинское слово.',
          accepted: ['select'],
          explanation: 'SELECT задаёт выборку данных. Затем можно указать столбцы, таблицу, условия и другие части запроса.'
        },
        {
          id: 'analytics-sum', type: 'word',
          prompt: 'Как называется функция Excel для суммы диапазона? Одно слово: русское или английское имя функции, без аргументов.',
          accepted: ['сумм', 'sum'],
          explanation: 'Функция СУММ в русской локализации и SUM в английской складывает числовые значения диапазона.'
        }
      ]
    },
    'tbank-practice': {
      id: 'tbank-practice',
      title: 'Основы тестирования веб-приложений',
      description: 'Проверки интерфейса, граничные значения и понятные отчёты об ошибках.',
      durationMinutes: 7,
      passCount: 4,
      questions: [
        {
          id: 'testing-report', type: 'choice',
          prompt: 'Какой набор сведений лучше помогает разработчику воспроизвести ошибку?',
          options: ['Только фраза «ничего не работает»', 'Название любимого браузера автора', 'Окружение, шаги, ожидаемый и фактический результаты', 'Только эмоциональная оценка интерфейса'],
          correct: 2,
          explanation: 'Окружение и шаги помогают воспроизвести проблему, а ожидаемый и фактический результаты объясняют расхождение.'
        },
        {
          id: 'testing-boundary', type: 'choice',
          prompt: 'Поле принимает целые числа от 1 до 100 включительно. Какой набор лучше проверяет обе границы и значения сразу за ними?',
          options: ['0, 1, 100, 101', '25, 50, 75', 'Только 50', '10, 20, 30'],
          correct: 0,
          explanation: 'Значения 1 и 100 проверяют допустимые границы, а 0 и 101 — ближайшие недопустимые значения.'
        },
        {
          id: 'testing-regression', type: 'choice',
          prompt: 'После изменения формы заявки нужно убедиться, что сохранение в избранное и календарь по-прежнему работают. Как называется такая проверка?',
          options: ['Только проверка орфографии', 'Регрессионное тестирование', 'Архивирование проекта', 'Дизайн-исследование'],
          correct: 1,
          explanation: 'Регрессионное тестирование помогает обнаружить, не нарушили ли изменения ранее работавшие функции.'
        },
        {
          id: 'testing-expected', type: 'choice',
          prompt: 'Какой ожидаемый результат подходит для проверки отправки формы с пустым обязательным полем?',
          options: ['Приложение должно закрыться', 'Нужно молча отправить пустые данные', 'Должна исчезнуть вся страница', 'Форма не отправляется и понятно указывает незаполненное поле'],
          correct: 3,
          explanation: 'Проверка обязательного поля должна предотвратить некорректную отправку и помочь пользователю исправить ввод.'
        },
        {
          id: 'testing-bug', type: 'word',
          prompt: 'Как одним коротким словом обычно называют ошибку программы? Можно ответить по-русски или по-английски.',
          accepted: ['баг', 'bug', 'дефект'],
          explanation: 'Баг (bug) — распространённое название дефекта программы. В отчёте важно описать его конкретно и воспроизводимо.'
        },
        {
          id: 'testing-not-found', type: 'word',
          prompt: 'Какой HTTP-код означает «ресурс не найден»? Ответь одним трёхзначным числом.',
          accepted: ['404'],
          explanation: 'HTTP 404 Not Found сообщает, что сервер не нашёл запрошенный ресурс.'
        }
      ]
    }
  };

  function freeze(value) {
    Object.freeze(value);
    Object.values(value).forEach(child => { if (child && typeof child === 'object' && !Object.isFrozen(child)) freeze(child); });
    return value;
  }
  freeze(assessments);
  let activeAssessments=assessments;

  function normalize(value) {
    if (typeof value !== 'string' && typeof value !== 'number') return '';
    return String(value).normalize('NFKC').toLocaleLowerCase('ru-RU').replace(/ё/g, 'е').trim()
      .replace(/^[\s"'«»„“”‘’.,:;!?()[\]{}=]+|[\s"'«»„“”‘’.,:;!?()[\]{}=]+$/g, '');
  }

  function get(id) {
    return Object.prototype.hasOwnProperty.call(activeAssessments, id) ? activeAssessments[id] : null;
  }

  function grade(id, answers = {}) {
    const assessment = get(id);
    if (!assessment) throw new RangeError('Для этой практики нет первичного тестирования.');
    const source = answers && typeof answers === 'object' && !Array.isArray(answers) ? answers : {};
    const results = assessment.questions.map(question => {
      const raw = Object.prototype.hasOwnProperty.call(source, question.id) ? source[question.id] : '';
      const answer = typeof raw === 'string' || typeof raw === 'number' ? String(raw).trim().slice(0, 300) : '';
      const normalized = normalize(raw);
      let correct = false;
      if (question.type === 'choice') {
        correct = /^\d+$/.test(answer) && Number(answer) === question.correct;
      } else {
        // A short answer must be a single token. Do not accept sentences containing a keyword.
        correct = normalized.length > 0 && !/\s/.test(normalized) && (question.accepted||[]).some(expected => normalize(expected) === normalized);
      }
      return {
        id: question.id,
        correct,
        answered: answer.length > 0,
        answer,
        expected: question.type === 'choice' ? question.options[question.correct] : (question.accepted||[])[0],
        explanation: question.explanation
      };
    });
    const correct = results.filter(result => result.correct).length;
    return { correct, total: results.length, percent: Math.round(correct / results.length * 100), passed: correct >= assessment.passCount, results };
  }

  window.Svod = window.Svod || {};
  Svod.assessments = Object.freeze({ version: 1, get, grade, normalize,
    get ids(){return Object.freeze(Object.keys(activeAssessments));},
    definitions(){return structuredClone(Object.values(activeAssessments));},
    setDefinitions(definitions){
      if(!Array.isArray(definitions)||definitions.length>500)throw new TypeError('Некорректный каталог тестов.');
      const next={};for(const source of definitions){
        if(!source||typeof source.id!=='string'||!/^[\w-]{1,100}$/.test(source.id)||!Array.isArray(source.questions)||!source.questions.length||source.questions.length>50||!Number.isInteger(source.passCount)||source.passCount<0||source.passCount>source.questions.length)throw new TypeError('Некорректный тест.');
        const ids=new Set();for(const q of source.questions){if(!q||typeof q.id!=='string'||ids.has(q.id)||!['choice','word'].includes(q.type)||typeof q.prompt!=='string'&&typeof q.text!=='string'||q.type==='choice'&&(!Array.isArray(q.options)||!q.options.length||q.options.some(x=>typeof x!=='string')))throw new TypeError('Некорректный вопрос.');ids.add(q.id);}
        next[source.id]=structuredClone(source);
      }
      activeAssessments=freeze(next);
    }
  });
})();
