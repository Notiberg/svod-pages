(function () {
  'use strict';
  const S=Svod.state,D=Svod.domain,clone=x=>structuredClone(x),uid=prefix=>prefix+'-'+(globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+'-'+Math.random().toString(36).slice(2));
  const now=()=>new Date().toISOString();
  class RepositoryError extends Error{constructor(code,message,details={}){super(message);this.name='RepositoryError';this.code=code;this.details=details;}}
  const fail=(code,message,details)=>{throw new RepositoryError(code,message,details);};
  const check=(ok,message)=>{if(!ok)fail('VALIDATION',message);};
  let sessionAdapter=null,remoteSession=null;
  const session={
    get:()=>sessionAdapter?{...sessionAdapter.get(),serverAuthorizationRequired:true}:adapter&&remoteSession?{...remoteSession,serverAuthorizationRequired:true}:({...S.get().session,studentId:'student-'+S.db().active,mode:'demo',serverAuthorizationRequired:true}),
    hydrate(value){check(value&&['active','expired','denied','signed-out'].includes(value.status),'Некорректная модель сессии.');remoteSession=clone(value);},
    setAdapter(value){check(value&&typeof value.get==='function','Адаптер сессии должен возвращать кешированную модель через get().');sessionAdapter=value;},
    can(permission){const value=this.get();if(value.status!=='active')return false;if(Array.isArray(value.permissions))return value.permissions.includes(permission);return value.status==='active'&&(['student.read','student.write'].includes(permission)||permission==='demo.manage'&&value.mode==='demo');},
    setDemoStatus(status){return command('setSession',{status});}
  };
  let adapter=null,fault={delay:0,error:null,once:false},queue=Promise.resolve();
  async function wait(){const selected={...fault};if(selected.once)fault={delay:0,error:null,once:false};if(selected.delay)await new Promise(resolve=>setTimeout(resolve,selected.delay));if(selected.error)fail(selected.error,({OFFLINE:'Нет сети. Черновик сохранён; повтори отправку позже.',NETWORK:'Не удалось выполнить запрос. Повтори действие.',FORBIDDEN:'Недостаточно прав для этого действия.',SESSION_EXPIRED:'Сессия истекла. Открой демонстрационный вход.'})[selected.error]||'Не удалось загрузить данные.');}
  function authorize(name,options,scenarioId=S.db().active){
    if(['setSession','changeScenario','import','reset'].includes(name))return;
    const status=sessionAdapter?session.get().status:S.db().scenarios[scenarioId].session.status;
    if(status==='expired'||status==='signed-out')fail('SESSION_EXPIRED','Сессия истекла. Черновики сохранены; войди в демо-кабинет.');
    if(status==='denied')fail('FORBIDDEN','Нет доступа к данным этого профиля.');
    if(name.startsWith('demo')&&!options.demo)fail('FORBIDDEN','Решение принадлежит вузу или компании. Открой явно обозначенные инструменты демонстрации.');
  }
  function requireOffer(id,category){const value=D.findOffer(id);if(!value||category&&value.category!==category)fail('NOT_FOUND','Предложение больше недоступно.');return value;}
  function report(state){const value=D.latestReport(state);if(!value)fail('NOT_FOUND','Сначала передай отчёт на проверку.');return value;}
  function reply(text){
    const q=text.toLowerCase();if(/практик|тест|заявк/.test(q))return 'Учебный помощник: открой практику, пройди тематический тест и подай заявку после успешного результата. Решение принимает вуз или компания; в прототипе его можно воспроизвести в инструментах демонстрации.';
    if(/резюм|портфолио/.test(q))return 'Учебный помощник: добавь цель, навыки и конкретный проект. Сохрани резюме, затем версию: заявка отправляет неизменяемый снимок, а черновик остаётся отдельно.';
    if(/отчёт|отчет|документ/.test(q))return 'Учебный помощник: прикрепи PDF, DOCX или TXT до 10 МБ в кабинете практики. В демо сохраняются только сведения о файле. При замечаниях отправь новую версию; решение о принятии принадлежит вузу.';
    if(/мероприят|событи|встреч/.test(q))return 'Учебный помощник: в карточке события видны дата, время Москвы и состояние записи. Отменить запись и скачать ICS можно в «Моих мероприятиях».';
    return 'Это автоматическая локальная подсказка, а не ответ куратора. Уточни вопрос о практике, резюме, отчёте или мероприятии. Реальная доставка появится после подключения API.';
  }
  const handlers={
    configure(state,payload,database){
      const allowed=['focus','widgets','hiddenWidgets','interests','weights','excluded','preferences','resumeDesign','calendarPeriod','calendarView','catalogFilters','onboarded','compare','hidden','read','filters'];
      for(const [key,value] of Object.entries(payload.values||{})){check(allowed.includes(key),'Это поле недоступно для настройки.');state[key]=clone(value);}
      if(payload.values?.read){state.notificationReadAt||={};for(const id of payload.values.read)state.notificationReadAt[id]||=now();}
      if(payload.appearance){if(payload.appearance.theme!==undefined){check(['light','dark','system'].includes(payload.appearance.theme),'Неизвестная тема.');database.theme=payload.appearance.theme;}if(payload.appearance.collapsed!==undefined)database.collapsed=!!payload.appearance.collapsed;}
      return true;
    },
    toggle(state,{key,id}){
      check(['favorites','hidden','compare','read','subscriptions','done','visits'].includes(key),'Неизвестная операция.');
      if(['hidden','compare','visits'].includes(key))requireOffer(id);
      if(key==='favorites')check(!!D.findOffer(id)||Svod.data.companies.some(c=>'company-'+c.id===id),'Материал больше недоступен.');
      if(key==='done'&&D.isDerivedTask(id))fail('VALIDATION','Эта задача завершается по результату действия, а не вручную. Открой её и выполни следующий шаг.');
      const values=state[key],index=values.indexOf(id);if(index<0){if(key==='compare')check(values.length<3,'Можно сравнить не больше трёх предложений.');values.push(id);}else values.splice(index,1);
      if(key==='read'){state.notificationReadAt||={};if(index<0)state.notificationReadAt[id]=now();else delete state.notificationReadAt[id];}
      return index<0;
    },
    visitOffer(state,{offerId}){requireOffer(offerId);if(!state.visits.includes(offerId))state.visits.push(offerId);return true;},
    visitCompany(state,{companyId}){check(Svod.data.companies.some(x=>x.id===companyId),'Компания не найдена.');state.companyVisits||=[];if(!state.companyVisits.includes(companyId))state.companyVisits.push(companyId);return true;},
    readChat(state,{chatId}){check(Svod.data.chats.some(x=>x.id===chatId),'Разговор не найден.');const key='chat-'+chatId;if(!state.read.includes(key))state.read.push(key);state.notificationReadAt||={};state.notificationReadAt[key]=now();return true;},
    submitApplication(state,{offerId},database,scenarioId){
      const item=requireOffer(offerId);check(item.category!=='events','Для события используй регистрацию.');
      check(!item.publication||item.publication==='published','Набор закрыт. Выберите другое предложение или уточните сроки у компании.');if(item.closesAt)check(item.closesAt>=new Intl.DateTimeFormat('en-CA',{timeZone:'Europe/Moscow'}).format(new Date()),'Срок отклика завершён. Выберите другое предложение.');
      const existing=state.applicationRecords.find(x=>x.offerId===offerId&&['submitted','approved'].includes(x.status));if(existing)return clone(existing);
      if(item.category==='internships'){const attempt=state.assessmentAttempts[offerId];check(attempt?.submittedAt&&(attempt.result||Svod.assessments.grade(offerId,attempt.answers)).passed,'Сначала успешно пройди учебный тест.');}
      check(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(state.resume.email),'Добавь корректный email в сохранённое резюме.');
      const matching=state.versions.find(v=>JSON.stringify(v.resume)===JSON.stringify(state.resume)&&JSON.stringify(v.design)===JSON.stringify(state.resumeDesign));
      const application={id:'application-'+scenarioId+'-'+offerId+'-'+(state.applicationRecords.filter(x=>x.offerId===offerId).length+1),offerId,status:'submitted',submittedAt:now(),resumeVersionId:matching?.id||null,resumeSnapshot:{resume:clone(state.resume),design:clone(state.resumeDesign),official:D.officialProfile(scenarioId)},history:[{status:'submitted',at:now(),actor:'student-'+scenarioId}]};
      if(Svod.multirole){application.studentId='student-'+scenarioId;application.companyId=item.companyId;application.universityId=Svod.multirole.universityId;application.offerSnapshot=clone(item);application.assessmentSnapshot=clone(state.assessmentAttempts[offerId]||null);}
      state.applicationRecords.push(application);return clone(application);
    },
    withdrawApplication(state,{applicationId,offerId}){
      const application=state.applicationRecords.find(x=>x.id===applicationId||x.offerId===offerId&&x.status!=='withdrawn');if(!application)fail('NOT_FOUND','Заявка не найдена.');
      check(!(state.practice?.offerId===application.offerId&&state.practice.status==='active'),'Для выбранного места сначала используй «Изменить место практики».');
      if(application.status==='withdrawn')return clone(application);application.status='withdrawn';application.history.push({status:'withdrawn',at:now(),actor:'student'});return clone(application);
    },
    demoChoosePractice(state,{offerId},database,scenarioId){
      const item=requireOffer(offerId,'internships'),application=state.applicationRecords.find(x=>x.offerId===offerId&&['submitted','approved'].includes(x.status));check(application,'Сначала подай заявку.');
      if(state.practice?.offerId===offerId&&state.practice.status==='active')return clone(state.practice);
      check(!state.practice||['cancelled','completed'].includes(state.practice.status),'Сначала заверши или измени текущее место практики.');
      application.status='approved';if(Svod.multirole){application.companyDecision={status:'ready',actorId:'demo-company',at:now(),comment:'Демонстрационное решение'};application.universityDecision={status:'approved',actorId:'demo-university',at:now(),comment:'Демонстрационное решение'};}application.history.push({status:'approved',at:now(),actor:'demo-university'});
      state.practice=D.makePractice(item,scenarioId);state.report=null;state.checklist=[];state.practiceComplete=false;return clone(state.practice);
    },
    resubmitApplication(state,{applicationId,expectedVersion,workload,start,end}){
      const a=state.applicationRecords.find(x=>x.id===applicationId);if(!a)fail('NOT_FOUND','Заявка больше недоступна.');
      check(a.status==='submitted'&&a.universityDecision?.status==='clarification','Уточнение по этой заявке не запрошено.');
      if(a.version!==expectedVersion)fail('CONFLICT','Заявка изменилась. Обнови данные; черновик сохранён.');
      check(typeof workload==='string'&&workload.trim().length>0&&workload.length<=500,'Укажи согласованную нагрузку.');
      const date=v=>/^\d{4}-\d{2}-\d{2}$/.test(v||'')&&!Number.isNaN(Date.parse(v))&&new Date(v+'T12:00:00Z').toISOString().slice(0,10)===v;
      check(date(start)&&date(end)&&start<end,'Укажи корректный период практики.');
      a.placement={...a.placement,workload:workload.trim(),start,end};a.decisionHistory.push({action:'student.resubmitted',actorId:a.studentId,at:now(),comment:workload.trim()});
      a.universityDecision={status:'pending',actorId:null,at:null,comment:''};return clone(a);
    },
    changePractice(state){
      if(!state.practice)return true;check(state.practice.status!=='completed','Завершённая практика остаётся в истории.');
      state.practiceHistory||=[];state.practice.status='cancelled';state.practiceHistory.push(clone(state.practice));
      const app=state.applicationRecords.find(x=>x.offerId===state.practice.offerId&&x.status==='approved');if(app){app.status='withdrawn';app.history.push({status:'withdrawn',at:now(),actor:'student',reason:'change-place'});}
      state.practice=null;state.practiceId='';state.practiceComplete=false;state.checklist=[];state.report=null;return true;
    },
    updateTask(state,payload){
      const id=payload.id||uid('task'),existing=state.tasks.find(x=>x.id===id);
      const title=String(payload.title??existing?.title??'').trim(),date=payload.date??existing?.date;
      check(title.length>0&&title.length<=120,'Название задачи должно содержать от 1 до 120 символов.');
      check(typeof date==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(date)&&!Number.isNaN(Date.parse(date+'T12:00:00'))&&Svod.dayKey(new Date(date+'T12:00:00'))===date,'Укажи существующую дату.');
      const task={id,title,date,completed:payload.completed??state.done.includes(id)};
      if(existing)Object.assign(existing,task);else{check(state.tasks.length<200,'Достигнут лимит 200 личных задач.');state.tasks.push(task);}
      if(task.completed&&!state.done.includes(id))state.done.push(id);if(!task.completed)state.done=state.done.filter(x=>x!==id);return clone(task);
    },
    deleteTask(state,{id}){const task=state.tasks.find(x=>x.id===id);if(!task)fail('NOT_FOUND','Задача уже удалена.');state.tasks=state.tasks.filter(x=>x.id!==id);state.done=state.done.filter(x=>x!==id);return clone(task);},
    registerEvent(state,{eventId},database,scenarioId){
      const event=requireOffer(eventId,'events'),condition=D.eventState(state,event);
      const existing=state.eventRegistrations.find(x=>x.eventId===eventId&&x.status==='registered');if(existing)return clone(existing);
      check(condition.canRegister,condition.past?'Мероприятие уже прошло.':condition.closed?'Запись закрыта.':'Свободных мест нет.');
      const registration={id:'registration-'+scenarioId+'-'+eventId+'-'+(state.eventRegistrations.filter(x=>x.eventId===eventId).length+1),eventId,status:'registered',registeredAt:now()};state.eventRegistrations.push(registration);return clone(registration);
    },
    cancelRegistration(state,{eventId}){for(const r of state.eventRegistrations.filter(x=>x.eventId===eventId&&x.status==='registered')){r.status='cancelled';r.cancelledAt=now();}return true;},
    submitReport(state,{file}){
      check(state.practice?.status==='active','Для отчёта нужна активная практика.');
      check(file&&typeof file.name==='string'&&/\.(pdf|docx|txt)$/i.test(file.name)&&file.name.length<=255,'Прикрепи PDF, DOCX или TXT.');
      check(Number.isFinite(file.size)&&file.size>0&&file.size<=10*1024*1024,'Файл должен быть не пустым и не больше 10 МБ.');
      const old=D.latestReport(state),version=(old?.version||0)+1;
      const value={id:'report-'+state.practice.id+'-'+version,practiceId:state.practice.id,version,name:file.name,size:file.size,type:file.type||'',status:'review',submittedAt:now(),reviewerId:null,comment:''};state.reports.push(value);
      state.practice.stages.find(x=>x.id==='report').status='pending';state.practice.status='active';state.practiceComplete=false;return clone(value);
    },
    demoReviewReport(state,{status,comment=''}){
      check(['accepted','revision'].includes(status),'Неизвестное решение проверки.');const value=report(state);check(['review','revision','accepted'].includes(value.status),'Отчёт недоступен для проверки.');
      value.status=status;value.comment=String(comment).slice(0,2000);value.reviewedAt=now();value.reviewerId='university-curator';
      state.practice.stages.find(x=>x.id==='report').status=status==='accepted'?'confirmed':'pending';
      if(status==='revision'){state.practice.status='active';state.practiceComplete=false;state.practice.stages.find(x=>x.id==='review').status='pending';}
      return clone(value);
    },
    updateStage(state,{stageId,completed}){
      check(state.practice?.status==='active','Практика сейчас недоступна для изменений.');const stage=state.practice.stages.find(x=>x.id===stageId);check(stage,'Этап не найден.');check(stage.owner==='student','Этот этап подтверждает вуз или компания.');stage.status=completed?'done':'pending';return clone(stage);
    },
    demoConfirmStage(state,{stageId}){check(state.practice?.status==='active','Нет активной практики.');const stage=state.practice.stages.find(x=>x.id===stageId);check(stage,'Этап не найден.');if(stageId==='report')check(D.latestReport(state)?.status==='accepted','Сначала прими отчёт в инструментах проверки.');stage.status='confirmed';return clone(stage);},
    completePractice(state){check(D.progress(state).canComplete,'Дождись подтверждения всех этапов и принятия отчёта.');state.practice.status='completed';state.practice.completedAt=now();return clone(state.practice);},
    saveResume(state,{resume,design}){check(Svod.resumeFields.valid(resume?.details),'Проверь дополнительные поля резюме.');for(const key of ['about','skills','project','email'])check(typeof resume?.[key]==='string'&&resume[key].length<=5000,'Некорректное поле резюме.');check(/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(resume.email),'Укажи корректный email.');state.resume=clone(resume);if(design)state.resumeDesign=clone(design);return clone(state.resume);},
    saveVersion(state,{name,resume,design}){check(String(name||'').trim().length>0&&name.length<=80,'Название версии — от 1 до 80 символов.');check(state.versions.length<10,'Можно сохранить до 10 версий. Удали ненужную версию.');check(Svod.resumeFields.valid((resume||state.resume).details),'Проверь дополнительные поля резюме.');const version={id:uid('resume'),name:name.trim(),resume:clone(resume||state.resume),design:clone(design||state.resumeDesign),createdAt:now()};state.versions.push(version);return clone(version);},
    deleteVersion(state,{id}){const value=state.versions.find(x=>x.id===id);if(!value)fail('NOT_FOUND','Версия уже удалена.');state.versions=state.versions.filter(x=>x.id!==id);return clone(value);},
    updateProfile(state,{personal,resume}){
      check(personal&&typeof personal.phone==='string'&&typeof personal.portfolio==='string','Некорректные контакты.');
      check(!personal.phone||/^\+?[\d\s()\-]{10,25}$/.test(personal.phone)&&personal.phone.replace(/\D/g,'').length>=10&&personal.phone.replace(/\D/g,'').length<=15,'Проверь номер телефона.');
      if(personal.portfolio){let url;try{url=new URL(personal.portfolio);}catch(_){}check(url&&['http:','https:'].includes(url.protocol),'Портфолио должно быть ссылкой http или https.');}
      state.personal=clone(personal);if(resume)handlers.saveResume(state,{resume});return clone(state.personal);
    },
    sendMessage(state,{chatId,text,clientId},database,scenarioId){
      check(Svod.data.chats.some(x=>x.id===chatId),'Разговор не найден.');text=String(text||'').trim();check(text.length>0&&text.length<=2000,'Сообщение должно содержать от 1 до 2000 символов.');
      const existing=clientId&&state.messages.find(m=>m.clientId===clientId);if(existing)return {messages:[clone(existing)]};
      const incoming=chatId==='mentor'?[...state.messages].reverse().find(m=>m.chatId==='mentor'&&m.companyId&&m.applicationId):null;const application=chatId==='mentor'?(state.applicationRecords.find(a=>a.id===(incoming?.applicationId||state.practice?.applicationId))||state.applicationRecords.filter(a=>a.status!=='withdrawn').at(-1)):null;
      const message={...(application?{companyId:application.companyId,applicationId:application.id,recipientId:incoming?.senderId||'mentor-'+application.companyId}:{}),id:uid('message'),clientId:clientId||uid('client'),chatId,channel:chatId,senderId:'student-'+scenarioId,from:'student',text,time:now(),createdAt:now(),status:'sent'};
      const response={id:uid('message'),chatId,channel:chatId,senderId:'local-assistant',from:'assistant',text:reply(text),time:now(),createdAt:now(),status:'local'};
      check(state.messages.length<=198,'В демо сохраняется до 200 сообщений. Экспортируй историю перед очисткой.');state.messages.push(message,response);return {messages:clone([message,response])};
    },
    saveAssessmentDraft(state,{offerId,answers}){const test=Svod.assessments.get(offerId);check(test,'Тест не найден.');if(state.assessmentAttempts[offerId]?.submittedAt)return clone(state.assessmentAttempts[offerId]);state.assessmentAttempts[offerId]={id:'attempt-'+offerId,testId:offerId,testVersion:test.version||Svod.assessments.version,answers:clone(answers),submittedAt:null,trusted:false,mode:'local-learning'};return clone(state.assessmentAttempts[offerId]);},
    submitAssessment(state,{offerId,answers}){const test=Svod.assessments.get(offerId);check(test,'Тест не найден.');const result=Svod.assessments.grade(offerId,answers);check(test.questions.every(q=>String(answers[q.id]||'').trim()),'Ответь на все вопросы.');state.assessmentAttempts[offerId]={id:uid('attempt'),testId:offerId,testVersion:test.version||Svod.assessments.version,answers:clone(answers),submittedAt:now(),trusted:false,mode:'local-learning',testSnapshot:clone(test),result:clone(result)};return clone(result);},
    retryAssessment(state,{offerId}){state.assessmentHistory||=[];if(state.assessmentAttempts[offerId]?.submittedAt)state.assessmentHistory.push(clone(state.assessmentAttempts[offerId]));delete state.assessmentAttempts[offerId];return true;},
    setSession(state,{status}){check(['active','expired','denied','signed-out'].includes(status),'Неизвестное состояние сессии.');state.session={status,mode:'demo',roles:['student']};return clone(state.session);}
  };
  async function query(name,args={}){
    if(name.startsWith('company.'))return adapter?adapter.query(name,args,{context:Svod.companyRepository.context()}):Svod.companyRepository.query(name.slice(8),args);
    if(name.startsWith('university.'))return adapter?adapter.query(name,args,{context:Svod.universityRepository.context()}):Svod.universityRepository.query(name.slice(11),args);
    const scenarioId=S.db().active;
    if(adapter)return adapter.query(name,args);await wait();S.sync();if(name==='session')return session.get();authorize(name,{},scenarioId);if(name==='conflicts')return clone(S.db().conflicts||[]);const state=clone(S.db().scenarios[scenarioId]);D.normalize(state,scenarioId);
    state.messages=state.messages.filter(m=>m.chatId!=='company-curator');
    if(name==='workspace')return state;
    if(name==='bootstrap')return {workspace:state,catalog:{...clone(Object.fromEntries(['recommendations','companies','news','articles','schedule','checklist','chats','semester','exams'].map(key=>[key,key==='recommendations'?Svod.data[key].filter(o=>o.publication!=='draft'):Svod.data[key]]))),assessments:Svod.assessments.definitions()},officialProfile:D.officialProfile(scenarioId),session:session.get()};
    if(name==='offers')return clone(D.recommendedOffers(state,args.category,args.filters));
    if(name==='profile')return {official:D.officialProfile(scenarioId),personal:clone(state.personal)};
    if(name==='session')return session.get();
    fail('NOT_FOUND','Неизвестный запрос.');
  }
  function command(name,payload={},options={}){
    if(name.startsWith('company.'))return adapter?adapter.command(name,payload,{...options,context:options.context||Svod.companyRepository.context()}):Svod.companyRepository.command(name.slice(8),payload,options);
    if(name.startsWith('university.'))return adapter?adapter.command(name,payload,{...options,context:options.context||Svod.universityRepository.context()}):Svod.universityRepository.command(name.slice(11),payload,options);
    const scenarioId=S.db().active;
    if(adapter)return adapter.command(name,payload,options);
    const run=async()=>{
      await wait();S.sync();authorize(name,options,scenarioId);
      if(name==='changeScenario'){S.changeScenario(payload.id);return clone(S.get());}
      if(name==='reset'){if(!S.reset())fail(S.lastError()?.code||'STORAGE',S.lastError()?.message);return clone(S.get());}
      if(name==='import'){S.import(payload.payload);return clone(S.get());}
      if(name==='resolveConflict'){if(!S.resolveConflict(payload.id,payload.keepIncoming===true))fail(S.lastError()?.code||'CONFLICT',S.lastError()?.message||'Не удалось разрешить конфликт.');return true;}
      const handler=handlers[name];if(!handler)fail('NOT_FOUND','Неизвестная команда.');
      let value;const key=options.idempotencyKey;
      const saved=S.transact((state,database)=>{
        D.normalize(state,scenarioId);
        if(key&&state.commandReceipts[key]){value=clone(state.commandReceipts[key].value);return;}
        const beforePractice=clone(state.practice),beforeApps=clone(state.applicationRecords),beforeReports=clone(state.reports);
        value=handler(state,payload,database,scenarioId);D.project(state);
        if(Svod.multirole){
          if(state.practice&&beforePractice?.id===state.practice.id&&JSON.stringify(beforePractice)!==JSON.stringify(state.practice))state.practice.version=(beforePractice.version||1)+1;
          for(const [items,previous,key] of [[state.applicationRecords,beforeApps,'version'],[state.reports,beforeReports,'revision']])for(const item of items){const old=previous.find(x=>x.id===item.id);if(old&&JSON.stringify(old)!==JSON.stringify(item))item[key]=(old[key]||1)+1;}
          if(value?.id)value=clone([...state.applicationRecords,...state.reports,state.practice].filter(Boolean).find(x=>x.id===value.id)||value);
        }
        if(key){state.commandReceipts[key]={at:now(),value:clone(value)};const keys=Object.keys(state.commandReceipts);if(keys.length>200)delete state.commandReceipts[keys[0]];}
      },scenarioId);
      if(!saved)fail(S.lastError()?.code||'STORAGE',S.lastError()?.message||'Не удалось сохранить данные.');return clone(value);
    };
    const locked=()=>typeof navigator!=='undefined'&&navigator.locks?navigator.locks.request('svod-shared-role-command',run):run();const promise=queue.then(locked,locked);queue=promise.catch(()=>{});return promise;
  }
  const subscribers=new Set();let externalTimer;
  if(typeof addEventListener==='function')addEventListener('storage',event=>{
    if(event.key!==null&&event.key!=='svod.dashboard.v1'&&!event.key.startsWith('svod.operation.v3.'))return;
    clearTimeout(externalTimer);externalTimer=setTimeout(()=>{S.sync();for(const listener of subscribers)listener({kind:'external',conflicts:S.db().conflicts||[]});},25);
  });
  Svod.session=session;
  Svod.repository={query,command,RepositoryError,subscribe(listener){subscribers.add(listener);return()=>subscribers.delete(listener);},setAdapter(value){check(value&&typeof value.query==='function'&&typeof value.command==='function','Адаптер должен реализовать query и command.');adapter=value;},mode:()=>adapter?'api':'local',useLocal(){adapter=null;remoteSession=null;sessionAdapter=null;},setFault(value={}){fault={delay:Math.max(0,Math.min(10000,value.delay||0)),error:value.error||null,once:value.once===true};},getFault:()=>({...fault})};
})();
