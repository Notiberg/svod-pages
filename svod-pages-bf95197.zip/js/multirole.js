/* Shared role identities and deterministic demonstration fixtures. No production authorization. */
(function(){
 'use strict';
 const universityId='polytech-demo',period='2026-autumn';
 const organizations={ 'polytech-demo':{id:universityId,name:'Московский Политех',department:'Факультет информационных технологий',departmentShort:'ФИТ',logo:'assets/images/mospolytech-logo.svg'},'other-university':{id:'other-university',name:'Северный учебный университет · демо',department:'Инженерный институт',departmentShort:'ИИ'}};
 const users=[
 {id:'curator-anna',name:'Анна Волкова',role:'curator',universityId,groupIds:['241-321','241-322','ПИ-24-01','ПИ-26-01','ПИ-23-01','ПИ-22-01'],permissions:['university.read','university.decide','university.message','university.export'],email:'anna@example.test'},
 {id:'curator-oleg',name:'Олег Миронов',role:'curator',universityId,groupIds:['241-323'],permissions:['university.read','university.decide','university.message','university.export'],email:'oleg@example.test'},
 {id:'coordinator-irina',name:'Ирина Белова',role:'coordinator',universityId,groupIds:['241-321','241-322','241-323','ПИ-24-01','ПИ-26-01','ПИ-23-01','ПИ-22-01'],permissions:['university.read','university.decide','university.message','university.export'],email:'irina@example.test'},
 {id:'curator-empty',name:'Нина Орлова',role:'curator',universityId,groupIds:[],permissions:['university.read'],email:'nina@example.test'},
 {id:'curator-other',name:'Павел Волков',role:'curator',universityId:'other-university',groupIds:['other-101'],permissions:['university.read','university.decide'],email:'pavel@example.test'}
 ];
 const names=[['student-junior','Александр Смирнов','241-321','junior'],['student-freshman','Мария Новикова','241-321','freshman'],['student-senior','Дмитрий Ковалёв','241-322','senior'],['student-graduate','Екатерина Морозова','241-322','graduate'],['student-lena','Елена Лебедева','241-321'],['student-ivan','Иван Петров','241-322'],['student-alina','Алина Захарова','241-322'],['student-max','Максим Соколов','241-321'],['student-sonya','Софья Васильева','241-323'],['student-other','Никита Фёдоров','other-101']];
 const students=names.map(([id,fullName,group,scenarioId])=>({id,fullName,group,scenarioId:scenarioId||null,universityId:id==='student-other'?'other-university':universityId,program:group==='241-321'?'Информационные системы':'Прикладная информатика',period,year:3,curatorId:group==='241-323'?'curator-oleg':group==='other-101'?'curator-other':'curator-anna',assignmentId:'assignment-'+group,readOnly:true}));
 for(const st of students.filter(s=>s.scenarioId)){const official=Svod.data.officialProfiles[st.scenarioId];Object.assign(st,{fullName:official.fullName,group:official.group,program:official.program,year:official.year,assignmentId:'assignment-'+official.group});}
 const decision=(status,actorId=null,comment='')=>({status,actorId,at:actorId?'2026-11-17T10:00:00+03:00':null,comment});
 function enrich(state,studentId){
  if(state.practice&&state.practice.status!=='cancelled'&&state.resume&&!state.applicationRecords.some(a=>a.offerId===state.practice.offerId)){
   const p=state.practice,id=p.studentId||studentId,official=Object.values(Svod.data.officialProfiles).find(x=>x.id===id);
   state.applicationRecords.push({id:'application-legacy-'+p.id,offerId:p.offerId,status:'approved',studentId:id,companyId:p.companyId,universityId,submittedAt:'2026-11-16T00:00:00Z',resumeVersionId:null,resumeSnapshot:{resume:structuredClone(state.resume),design:structuredClone(state.resumeDesign),official:structuredClone(official||{id,fullName:'Демонстрационный студент'})},history:[{status:'approved',at:'2026-11-16T00:00:00Z',actor:'legacy-demo'}]});
  }
  for(const a of state.applicationRecords||[]){const offer=Svod.data.recommendations.find(o=>o.id===a.offerId);if(!offer||offer.category==='events')continue;
   a.studentId ||= studentId||a.resumeSnapshot?.official?.id;a.companyId ||= offer.companyId;a.universityId ||= universityId;a.version ||= 1;a.candidateStage ||= 'received';
   if(a.status==='rejected'&&!a.companyDecision&&!a.universityDecision)a.legacyDecision={status:'rejected',comment:'В прежней демонстрационной копии владелец отказа не указан.'};
   a.companyDecision ||= decision(a.status==='approved'?'ready':'pending',a.status==='approved'?'legacy-demo-company':null);
   a.universityDecision ||= decision(a.status==='approved'?'approved':'pending',a.status==='approved'?'legacy-demo-university':null);
   a.decisionHistory ||= [];a.placement ||= {start:offer.practicePeriod?.start||'',end:offer.practicePeriod?.end||'',workload:offer.workload||'20 часов в неделю',format:offer.format,conditionsConfirmed:true,mentorId:offer.mentorId||'mentor-'+a.companyId};
   if(a.status!=='withdrawn')a.status=a.legacyDecision?.status==='rejected'&&a.universityDecision.status==='pending'&&a.companyDecision.status==='pending'?'rejected':a.universityDecision.status==='rejected'||a.companyDecision.status==='declined'?'rejected':(offer.category==='jobs'||a.universityDecision.status==='approved')&&a.companyDecision.status==='ready'?'approved':'submitted';
  }
  if(state.practice){const p=state.practice;p.version ||= 1;p.universityId ||= universityId;p.applicationId ||= state.applicationRecords?.find(a=>a.offerId===p.offerId&&a.status==='approved')?.id||null;p.history ||= [];p.meetings ||= p.studentId==='student-ivan'?[{id:'meeting-student-ivan',title:'Обсуждение результатов с наставником',startsAt:'2026-11-20T15:00:00+03:00',endsAt:'2026-11-20T15:30:00+03:00',timezone:'Europe/Moscow'}]:[];p.plan ||= {goal:'Применить навыки разработки в рабочем проекте',tasks:'Подготовить прототип, проверить решение и описать результат',result:'Прототип и отчёт о выполненных задачах',status:p.stages.find(s=>s.id==='plan')?.status==='confirmed'?'confirmed':'draft',studentId:p.studentId,curatorId:p.participants.curatorId,mentorId:p.participants.mentorId};}
  for(const r of state.reports||[]){r.revision ||= 1;r.history ||= [];r.fileId ??= null;r.downloadUrl ??= null;}
  return state;
 }
 function seed(){
  const workspaces={};
  for(const st of students.filter(s=>!s.scenarioId)){
   const item=Svod.data.recommendations.find(x=>x.id==='sber-frontend'),w={applicationRecords:[],practice:null,reports:[],messages:[],practiceHistory:[]};
   const a={id:'application-'+st.id+'-sber-frontend-1',studentId:st.id,offerId:item.id,companyId:item.companyId,universityId:st.universityId,status:'submitted',submittedAt:'2026-11-14T10:00:00+03:00',resumeVersionId:null,resumeSnapshot:{official:st,resume:{about:'Учебный проект',skills:'JavaScript, HTML, CSS',project:'Прототип сервиса',email:'student@example.test'},design:{template:'minimal',color:'blue',background:'paper',blocks:'plain'}},history:[{status:'submitted',at:'2026-11-14T10:00:00+03:00',actor:st.id}],companyDecision:decision(st.id==='student-max'?'pending':'ready','demo-company'),universityDecision:decision('pending'),version:1};
   w.applicationRecords.push(a);enrich(w,st.id);a.universityId=st.universityId;
   if(['student-ivan','student-alina'].includes(st.id)){
    a.universityDecision=decision('approved','curator-anna');a.status='approved';w.practice=Svod.domain.makePractice(item,st.id,['intro','plan','project']);Object.assign(w.practice,{id:'practice-'+st.id,studentId:st.id,applicationId:a.id,universityId:st.universityId});w.practice.participants={studentId:st.id,curatorId:'curator-anna',mentorId:'mentor-'+item.companyId};
    w.practice.stages.find(s=>s.id==='report').dueDate='2026-11-16';
    w.reports=[{id:'report-'+st.id+'-1',practiceId:w.practice.id,version:1,name:'Отчёт-версия-1.pdf',size:2048,type:'application/pdf',submittedAt:'2026-11-15T12:00:00+03:00',status:'revision',comment:'Добавьте описание результата и выводы.',reviewerId:'curator-anna',reviewedAt:'2026-11-16T09:00:00+03:00',history:[]}];
    if(st.id==='student-ivan')w.reports.push({id:'report-'+st.id+'-2',practiceId:w.practice.id,version:2,name:'Отчёт-версия-2.pdf',size:4096,type:'application/pdf',submittedAt:'2026-11-17T11:00:00+03:00',status:'review',comment:'',reviewerId:null,history:[]});
    enrich(w,st.id);
   }
   workspaces[st.id]=w;
  }
  return {schemaVersion:1,workspaces,preferences:{},readByUser:{},receipts:{}};
 }
 const contacts=Svod.data.companies.map(c=>({id:'mentor-'+c.id,companyId:c.id,name:c.id==='sber'?'Дмитрий Соколов':c.id==='yandex'?'Марина Кузнецова':c.id==='vk'?'Сергей Павлов':'Виктория Алексеева',email:'mentor-'+c.id+'@example.test',role:'Наставник · демонстрационный контакт'}));
 function actorName(id){return users.find(u=>u.id===id)?.name||students.find(s=>s.id===id)?.fullName||contacts.find(c=>c.id===id)?.name||({'university-curator':'Анна Волкова','company-mentor':'Дмитрий Соколов','demo-company':'Компания · демонстрация','legacy-demo-company':'Компания · импорт демо','legacy-demo-university':'Вуз · импорт демо','demo-university':'Вуз · демонстрация'})[id]||'Участник демонстрации';}
 const actionLabels={'company.reviewing':'Начато рассмотрение компанией','company.clarification':'Компания запросила уточнения','company.invited':'Компания назначила встречу','company.declined':'Компания отказала','company.saveFeedback':'Сохранён отзыв компании','company.confirmStage':'Подтверждён этап компании','company.assignMentor':'Назначен наставник',savePlan:'План сохранён',confirmPlan:'План подтверждён',changeDeadline:'Срок изменён','university.approved':'Место согласовано','university.clarification':'Запрошено уточнение','university.rejected':'Место отклонено','company.ready':'Компания готова принять','student.resubmitted':'Студент уточнил сведения','report.accepted':'Отчёт принят','report.revision':'Отчёт возвращён',confirmStage:'Этап подтверждён'};
 const actionName=action=>actionLabels[action]||'Изменение записи';
 const organizationContext=(id,cached)=>organizations[id]||(cached&&cached.id===id?cached:organizations[universityId]);
 Svod.multirole={organizationContext,actionName,contacts,actorName,universityId,period,organizations,users,students,decision,enrich,seed};
})();
