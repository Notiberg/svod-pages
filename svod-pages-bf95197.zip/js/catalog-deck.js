(function(){
 'use strict';
 const reviewed=new Map();
 const ranked=(offers,score)=>[...offers].sort((a,b)=>score(b)-score(a)||a.id.localeCompare(b.id));
 function render(offers,{key,logo,score,state}){
  const e=Svod.ui.escape,seen=reviewed.get(key)||new Set();
  const queue=ranked(offers,score).filter(x=>!seen.has(x.id)&&!state?.favorites?.includes(x.id));
  return `<section class="offer-deck swipe-deck" data-deck-key="${e(key)}" aria-label="Предложения СВОДом"><p class="offer-deck-legend">Вправо — в избранное · влево — пропустить. Нажми на карточку, чтобы узнать больше. На клавиатуре — стрелки.</p><div class="offer-deck-track">${queue.map((x,i)=>`<article class="offer-deck-panel is-active" data-offer-id="${e(x.id)}" data-direction="${e(x.direction)}" ${i?'hidden':''}><a href="#offer/${e(x.id)}" class="offer-deck-content" aria-label="Подробнее: ${e(x.title)}"><div class="offer-deck-brand">${logo(x)}<span>${e(x.company)}<small>${e(x.type)} · учебное предложение</small></span></div><span class="offer-deck-match">${score(x)}% соответствие · ${e(x.direction)}</span><h2>${e(x.title)}</h2><p class="offer-deck-description">${e(x.description)}</p><div class="offer-deck-facts"><span>${e(x.format)}</span><span>${e(x.city)}</span><span>${e(x.salary||x.duration)}</span></div><span class="offer-deck-read">Нажми, чтобы прочитать подробнее ↗</span></a><span class="swipe-sticker" aria-hidden="true"></span></article>`).join('')}</div><p class="swipe-result" role="status" aria-live="polite">${queue.length?'Осталось предложений: '+queue.length:'Все предложения просмотрены. Сохранённые доступны в избранном.'}</p></section>`;
 }
 function mount(root,{decide=async()=>{}}={}){
  const deck=root.querySelector('.swipe-deck');if(!deck)return;
  const track=deck.querySelector('.offer-deck-track'),key=deck.dataset.deckKey;
  let busy=false,start=null,moved=false;
  const active=()=>track.querySelector('article:not([hidden])');
  function reset(card){card.classList.remove('swipe-enter');card.style.transform='';card.querySelector('.swipe-sticker').textContent='';}
  async function commit(card,right){
   if(busy)return;busy=true;start=null;card.classList.remove('swipe-enter');
   const sticker=card.querySelector('.swipe-sticker');sticker.innerHTML=right?Svod.icon('bookmark'):Svod.icon('close');sticker.dataset.choice=right?'save':'skip';
   card.style.transform=`translateX(${right?120:-120}%) rotate(${right?16:-16}deg)`;
   deck.setAttribute('aria-busy','true');
   try{
    await Promise.all([decide(card.dataset.offerId,right),new Promise(resolve=>setTimeout(resolve,matchMedia('(prefers-reduced-motion: reduce)').matches?0:320))]);
    if(!deck.isConnected)return;
    if(!reviewed.has(key))reviewed.set(key,new Set());reviewed.get(key).add(card.dataset.offerId);
    card.hidden=true;const next=card.nextElementSibling;if(!next)track.hidden=true;if(next){next.hidden=false;next.classList.add('swipe-enter');if(document.activeElement===card.querySelector('a'))next.querySelector('a').focus({preventScroll:true});}
    deck.querySelector('.swipe-result').textContent=(right?'Добавлено в избранное. ':'Предложение пропущено. ')+(next?'Осталось: '+[...track.children].filter(x=>!reviewed.get(key).has(x.dataset.offerId)).length:'Все предложения просмотрены. Сохранённые доступны в избранном.');
   }catch(_){reset(card);deck.querySelector('.swipe-result').textContent='Не удалось сохранить решение. Карточка осталась — попробуй ещё раз.';}
   finally{busy=false;deck.removeAttribute('aria-busy');}
  }
  track.addEventListener('pointerdown',event=>{if(!busy&&event.isPrimary&&event.button===0){start={x:event.clientX,y:event.clientY,card:active(),pointer:event.pointerId};moved=false;}});
  track.addEventListener('pointermove',event=>{
   if(!start||!start.card)return;const dx=event.clientX-start.x,dy=event.clientY-start.y;
   if(!moved&&Math.abs(dy)>14&&Math.abs(dy)>Math.abs(dx)){start=null;return;}
   if(Math.abs(dx)>12&&Math.abs(dx)>Math.abs(dy)*1.2){moved=true;track.setPointerCapture(event.pointerId);const card=start.card;card.classList.remove('swipe-enter');card.style.transform=`translateX(${dx}px) rotate(${dx/25}deg)`;const sticker=card.querySelector('.swipe-sticker');const choice=dx>0?'save':'skip';if(sticker.dataset.choice!==choice||!sticker.innerHTML){sticker.innerHTML=dx>0?Svod.icon('bookmark'):Svod.icon('close');sticker.dataset.choice=choice;}}
  });
  track.addEventListener('pointerup',event=>{if(!start)return;const {card,x}=start,dx=event.clientX-x;start=null;if(moved&&Math.abs(dx)>Math.min(90,track.clientWidth*.23))commit(card,dx>0);else reset(card);});
  track.addEventListener('pointercancel',()=>{if(start?.card)reset(start.card);start=null;});
  track.addEventListener('click',event=>{if(moved||busy){event.preventDefault();event.stopPropagation();moved=false;}},true);
  track.addEventListener('keydown',event=>{if(['ArrowLeft','ArrowRight'].includes(event.key)&&active()){event.preventDefault();commit(active(),event.key==='ArrowRight');}});
 }
 Svod.catalogDeck={render,mount,ranked};
})();
