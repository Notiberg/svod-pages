/* Prepared training results and real demo resume assets; never replaces a submitted student snapshot. */
(function(){
 'use strict';
 const clone=x=>structuredClone(x),ids=['student-max','student-lena','student-ivan'];
 const files=Object.fromEntries(ids.map(id=>[id,{id:'resume-file-'+id+'-1',name:'Резюме-'+id.replace('student-','')+'-Liquid-Glass.pdf',url:'assets/resumes/'+id+'-liquid-glass.pdf',htmlUrl:'assets/resumes/'+id+'-liquid-glass.html',type:'application/pdf',design:'glass',mode:'fictional-demo',contentAvailable:true}]));
 function makeResult(studentId){const test=clone(Svod.assessments.get('sber-frontend')),correct=studentId==='student-lena'?6:studentId==='student-max'?5:4,answers=Object.fromEntries(test.questions.map((q,i)=>[q.id,i<correct?q.type==='choice'?String(q.correct):q.accepted[0]:q.type==='choice'?String((q.correct+1)%q.options.length):'demo']));return {id:'attempt-fixture-'+studentId+'-1',testId:test.id,testVersion:test.version||1,testSnapshot:test,answers,result:clone(Svod.assessments.grade(test.id,answers)),submittedAt:'2026-11-14T08:30:00Z',trusted:false,mode:'local-learning',source:'fictional-demo-fixture'};}
 const results=Object.fromEntries(ids.map(id=>[id,makeResult(id)]));
 function result(studentId){return clone(results[studentId]);}
 const matches=r=>r&&r.about==='Учебный проект'&&r.project==='Прототип сервиса'&&r.skills==='JavaScript, HTML, CSS'&&r.email==='student@example.test'&&!r.details;
 function enrich(workspace,student){if(!ids.includes(student.id))return workspace;for(const a of workspace.applicationRecords||[]){if(a.id!=='application-'+student.id+'-sber-frontend-1')continue;a.assessmentSnapshot ||= result(student.id);if(matches(a.resumeSnapshot?.resume))a.resumeFile ||= clone(files[student.id]);}return workspace;}
 Svod.companyFixtures={files,ids,result,enrich};
})();
