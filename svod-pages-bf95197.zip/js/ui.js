/* Shared, buildless UI contracts. Text generated from data is escaped at this boundary. */
(function (global) {
  'use strict';
  const Svod = global.Svod = global.Svod || {};
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const icon = name => Svod.icon ? Svod.icon(name) : '';
  const attr = (action, id = '') => `data-action="${escape(action)}" data-id="${escape(id)}"`;
  function button(text, action, id = '', cls = 'secondary-button', symbol = '', options = {}) {
    const labels = { 'month-prev': 'Предыдущий месяц', 'month-next': 'Следующий месяц', 'delete-version': 'Удалить версию резюме' };
    const label = options.label || (String(text).startsWith('<svg') ? labels[action] || 'Открыть' : '');
    // Existing call sites may pass trusted icon markup; user strings must use escape().
    return `<button type="${options.type === 'submit' ? 'submit' : 'button'}" class="${escape(cls)}" ${attr(action, id)}${label ? ` aria-label="${escape(label)}"` : ''}${options.disabled ? ' disabled' : ''}>${symbol ? icon(symbol) : ''}${text}</button>`;
  }
  function safeUrl(value, options = {}) {
    const source = String(value || '').trim();
    if (!source || /[\u0000-\u0020\u007f]/.test(source)) return '';
    if (/^https?:\/\//i.test(source)) {
      try { const result = new URL(source); return result.hostname && !result.username && !result.password ? result.href : ''; } catch (_) { return ''; }
    }
    if (options.local && /^(?:#|\.\.?\/|assets\/|css\/|js\/)/.test(source) && !source.startsWith('//') && !source.includes('\\')) return source;
    return '';
  }
  function link(text, path, cls = 'text-button', symbol = 'arrow-right') {
    const destination = /^https?:\/\//i.test(path) ? safeUrl(path) : '#' + String(path || 'main').replace(/^#/, '');
    return `<a href="${escape(destination || '#main')}" class="${escape(cls)}"${/^https?:/.test(destination) ? ' target="_blank" rel="noopener noreferrer"' : ''}>${symbol ? icon(symbol) : ''}${text}</a>`;
  }
  function field(config) {
    const { id, name = id, label, value = '', type = 'text', help = '', error = '', required = false, maxlength, min, max, placeholder = '', autocomplete = '' } = config;
    const helpId = id + '-hint', errorId = id + '-error';
    const description = [help && helpId, error && errorId].filter(Boolean).join(' ');
    const common = `id="${escape(id)}" name="${escape(name)}"${required ? ' required aria-required="true"' : ''}${description ? ` aria-describedby="${escape(description)}"` : ''} aria-invalid="${!!error}"${maxlength ? ` maxlength="${Number(maxlength)}"` : ''}${min ? ` min="${escape(min)}"` : ''}${max ? ` max="${escape(max)}"` : ''}${placeholder ? ` placeholder="${escape(placeholder)}"` : ''}${autocomplete ? ` autocomplete="${escape(autocomplete)}"` : ''}`;
    const input = type === 'textarea' ? `<textarea ${common}>${escape(value)}</textarea>` : `<input type="${escape(type)}" ${common} value="${escape(value)}">`;
    return `<div class="form-row"><label for="${escape(id)}">${escape(label)}${required ? '<span class="field-required"> (обязательно)</span>' : ''}</label>${input}${help ? `<small class="field-hint" id="${escape(helpId)}">${escape(help)}</small>` : ''}<p class="field-error form-error" id="${escape(errorId)}" role="alert"${error ? '' : ' hidden'}>${escape(error)}</p></div>`;
  }
  const badge = (text, tone = 'neutral') => `<span class="status-badge" data-tone="${escape(tone)}">${escape(text)}</span>`;
  const empty = (title, text, path = '', cta = 'Посмотреть возможности') => `<div class="empty-state">${icon('compass')}<strong>${escape(title)}</strong><p>${escape(text)}</p>${path ? link(escape(cta), path, 'secondary-button') : ''}</div>`;
  const loading = (message = 'Загружаем данные…') => `<div class="async-state" role="status" aria-live="polite" aria-busy="true">${icon('clock')}<p>${escape(message)}</p></div>`;
  const error = (message, action = 'retry', id = '') => `<div class="async-state error-state" role="alert"><strong>Не удалось выполнить действие</strong><p>${escape(message)}</p>${button('Повторить', action, id)}</div>`;
  /** @param {{src?:string,alt?:string,decorative?:boolean,width?:number,height?:number,aspectRatio?:number,position?:string,mobilePosition?:string}} data */
  function media(data = {}, options = {}) {
    const kind = ['logo', 'hero', 'cover'].includes(options.kind) ? options.kind : 'cover';
    const src = safeUrl(data.src, { local: true });
    const width = Math.max(1, Math.min(8000, Number(data.width) || (kind === 'logo' ? 64 : 1200)));
    const height = Math.max(1, Math.min(8000, Number(data.height) || (kind === 'logo' ? 64 : 675)));
    const ratio = Math.max(.2, Math.min(5, Number(data.aspectRatio) || width / height));
    const position = value => /^(?:\d{1,3}%|center|left|right|top|bottom)(?: (?:\d{1,3}%|center|left|right|top|bottom))?$/.test(value || '') ? value : 'center';
    const decorative = data.decorative === true;
    const label = decorative ? '' : String(data.alt || options.fallback || 'Изображение недоступно');
    return `<span class="media-slot ${escape(options.className || '')}" data-kind="${kind}" data-state="${src ? 'ready' : 'empty'}" style="--media-ratio:${ratio};--media-position:${position(data.position)};--media-position-mobile:${position(data.mobilePosition || data.position)}"${decorative ? ' aria-hidden="true"' : ''}>${src ? `<img class="media-image" src="${escape(src)}" alt="${escape(label)}" width="${width}" height="${height}" loading="${kind === 'hero' ? 'eager' : 'lazy'}" decoding="async">` : ''}<span class="media-fallback"${src ? ' hidden' : ''}${decorative ? '' : ` role="img" aria-label="${escape(label)}"`}>${escape(options.fallback || (kind === 'logo' ? 'С' : ''))}</span></span>`;
  }
  let mediaBound = false;
  function installMediaFallback(root = global.document) {
    if (!root || mediaBound) return;
    mediaBound = true;
    root.addEventListener('error', event => {
      const image = event.target;
      if (!image?.classList?.contains('media-image')) return;
      const slot = image.closest('.media-slot');
      if (!slot) return;
      slot.dataset.state = 'error'; image.hidden = true;
      const fallback = slot.querySelector('.media-fallback'); if (fallback) fallback.hidden = false;
    }, true);
  }
  Svod.ui = { escape, attr, button, link, field, badge, empty, loading, error, safeUrl, media, installMediaFallback };
})(typeof window === 'undefined' ? globalThis : window);
