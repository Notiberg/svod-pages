/* Optional student information, shared by the editor, repository and backup validator.
 * No files or image bytes are stored in the resume or LocalStorage. */
(function (global) {
  'use strict';
  const V = global.Svod;
  const contacts = {
    phone: ['Телефон', 40, 'tel'], telegram: ['Telegram', 33, 'text'],
    city: ['Город', 120, 'text'], position: ['Желаемая должность', 160, 'text'],
    interests: ['Личные интересы', 500, 'text'], portfolio: ['Ссылка на портфолио', 500, 'url']
  };
  const groups = {
    experience: { title: 'Опыт работы', add: 'Добавить место опыта', fields: { company: ['Компания / организация', 160], role: ['Роль', 160], period: ['Период', 100], result: ['Что сделал — с результатом', 600, 'textarea'] } },
    activities: { title: 'Учёба, проекты и спорт', add: 'Добавить деятельность', fields: { type: ['Тип деятельности', 20, 'select'], title: ['Название', 160], period: ['Период', 100], role: ['Роль / результат', 200], description: ['Что это было', 600, 'textarea'] } },
    achievements: { title: 'Достижения', add: 'Добавить достижение', fields: { year: ['Год', 4, 'year'], title: ['Достижение', 250] } }
  };
  const types = ['Учебная', 'Проектная', 'Спортивная'];
  /** @typedef {{phone?:string,telegram?:string,city?:string,position?:string,portfolio?:string,interests?:string,experience?:Array<{company?:string,role?:string,period?:string,result?:string}>,activities?:Array<{type?:string,title?:string,period?:string,role?:string,description?:string}>,achievements?:Array<{year?:string,title?:string}>}} ResumeDetails */
  /** @param {ResumeDetails|undefined} details */
  function valid(details) {
    if (details === undefined) return true; // Existing versions and backups remain valid.
    if (!details || typeof details !== 'object' || Array.isArray(details)) return false;
    if (Object.keys(details).some(key => !Object.hasOwn(contacts,key) && !Object.hasOwn(groups,key))) return false;
    for (const [key, [,max]] of Object.entries(contacts)) if (details[key] !== undefined && (typeof details[key] !== 'string' || details[key].length > max)) return false;
    if(details.phone?.trim() && !/^[+\d\s().-]+$/.test(details.phone) || details.phone?.trim() && !/^\+?\d{10,15}$/.test(details.phone.replace(/[\s().-]/g,'')))return false;
    if(details.telegram?.trim() && !/^@?[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(details.telegram.trim()))return false;
    if(details.portfolio?.trim()) { try { const url=new URL(details.portfolio);if(!['https:','http:'].includes(url.protocol)||!url.hostname||url.username||url.password)return false; }catch(_){return false;} }
    for (const [key, group] of Object.entries(groups)) {
      if (details[key] === undefined) continue;
      if (!Array.isArray(details[key]) || details[key].length > 5) return false;
      for (const row of details[key]) {
        if (!row || typeof row !== 'object' || Array.isArray(row) || Object.keys(row).some(field => !Object.hasOwn(group.fields, field))) return false;
        for (const [field, [, max]] of Object.entries(group.fields)) if (row[field] !== undefined && (typeof row[field] !== 'string' || row[field].length > max)) return false;
        if (row.type && !types.includes(row.type) || row.year && !/^(19|20|21)\d{2}$/.test(row.year)) return false;
      }
    }
    return JSON.stringify(details).length <= 18000;
  }
  function parse(value) { try { const details=typeof value==='string'?JSON.parse(value):value; return valid(details)&&details ? details : {}; } catch (_) { return {}; } }
  function field(name, spec, value='') {
    const [label,max,kind='text']=spec, e=V.ui.escape, id='resume-'+name.replaceAll('.','-');
    const base=`id="${id}" name="detail.${name}" data-resume-field="${name}" maxlength="${max}"`;
    const control=kind==='textarea'?`<textarea ${base} rows="3">${e(value)}</textarea>`:kind==='select'?`<select ${base}>${types.map(type=>`<option ${value===type?'selected':''}>${type}</option>`).join('')}</select>`:`<input ${base} type="${kind==='year'?'text':kind}" ${kind==='year'?'inputmode="numeric" data-resume-year':''} ${name==='telegram'?'data-telegram':''} value="${e(value)}">`;
    return `<div class="form-row"><label for="${id}">${label}</label>${control}</div>`;
  }
  function rowHTML(key, row, index) {
    return `<fieldset class="resume-entry" data-resume-row="${key}"><legend>${groups[key].title} · ${index+1}</legend>${Object.entries(groups[key].fields).map(([name,spec])=>field(`${key}.${index}.${name}`,spec,row[name]||'')).join('')}<button type="button" class="text-button" data-resume-remove="${key}" data-index="${index}">Убрать запись ${index+1}</button></fieldset>`;
  }
  function editor(details={}) {
    const e=V.ui.escape;
    return `<input type="hidden" name="resumeDetails" value="${e(JSON.stringify(details))}"><div data-resume-details>${detailsHTML(details)}</div>`;
  }
  function detailsHTML(details) {
    return `<div class="resume-extra-fields"><h3>Контакты и цель</h3><p class="field-hint">Дополнительные поля необязательны. Если телефон или портфолио не указаны здесь, используются контакты профиля.</p><div class="resume-contact-fields">${Object.entries(contacts).filter(([key])=>key!=='interests').map(([key,spec])=>field(key,spec,details[key]||'')).join('')}</div>${Object.entries(groups).map(([key,group])=>`<section class="resume-entry-group" aria-label="${group.title}"><h3>${group.title}</h3><p class="field-hint">До 5 записей. ${key==='experience'?'Работа, стажировка, подработка — любой опыт с результатом. Можно оставить пустым.':key==='activities'?'Курсовой, хакатон, олимпиада, турнир или волонтёрство.':'Награды, стипендии и конкурсы — укажи год и результат.'}</p><div>${(details[key]||[]).map((row,i)=>rowHTML(key,row,i)).join('')}</div><button type="button" class="secondary-button" data-resume-add="${key}" ${(details[key]||[]).length>=5?'disabled':''}>${group.add}</button></section>`).join('')}<h3>Интересы</h3>${field('interests',contacts.interests,details.interests||'')}<p class="field-hint">Через запятую: фотография, настолки, бег, волейбол, чтение, робототехника. Личные интересы не меняют карьерные критерии подбора.</p><p data-resume-undo-status role="status"></p><button type="button" class="text-button" data-resume-undo hidden>Вернуть удалённую запись</button></div>`;
  }
  function hydrate(form, values) {
    if (form?.id!=='resume-form' || !Object.hasOwn(values||{},'resumeDetails')) return;
    const root=form.querySelector('[data-resume-details]'); if(root)root.innerHTML=detailsHTML(parse(values.resumeDetails));
  }
  function sync(form) {
    const hidden=form.elements.namedItem('resumeDetails'); if(!hidden)return;
    const details={};
    for(const input of form.querySelectorAll('[data-resume-field]')) {
      const parts=input.dataset.resumeField.split('.');
      if(parts.length===1)details[parts[0]]=input.value;
      else {const [group,index,key]=parts;details[group]||=[];details[group][Number(index)]||={};details[group][Number(index)][key]=input.value;}
    }
    hidden.value=JSON.stringify(details);
  }
  function sections(details={}) {
    const e=V.ui.escape;
    const section=(title,body)=>body?`<section><h2>${title}</h2>${body}</section>`:'';
    const rows=(key,render)=>(details[key]||[]).filter(row=>Object.entries(row).some(([k,v])=>k!=='type'&&v.trim())).map(row=>`<div class="resume-document-entry">${render(row)}</div>`).join('');
    return section('Опыт работы',rows('experience',r=>`<h3>${e([r.role,r.company].filter(Boolean).join(' · '))}</h3>${r.period?`<p>${e(r.period)}</p>`:''}<p>${e(r.result||'')}</p>`))+
      section('Учёба, проекты и спорт',rows('activities',r=>`<h3>${e(r.title||'')}</h3><p>${e([r.type,r.period,r.role].filter(Boolean).join(' · '))}</p><p>${e(r.description||'')}</p>`))+
      section('Достижения',rows('achievements',r=>`<p>${e([r.year,r.title].filter(Boolean).join(' · '))}</p>`))+
      section('Интересы',details.interests?`<p>${e(details.interests)}</p>`:'');
  }
  let installed=false;
  function install(document) {
    if(installed)return;installed=true;
    const removed=new WeakMap();
    const changed=form=>{sync(form);form.elements.namedItem('resumeDetails').dispatchEvent(new Event('input',{bubbles:true}));};
    document.addEventListener('input',event=>{if(event.target.matches?.('[data-resume-field]'))sync(event.target.form);},true);
    document.addEventListener('change',event=>{if(event.target.matches?.('[data-resume-field]'))sync(event.target.form);},true);
    document.addEventListener('click',event=>{
      const button=event.target.closest?.('[data-resume-add],[data-resume-remove],[data-resume-undo],[data-resume-skill]');if(!button)return;
      const form=button.closest('form');if(!form)return;event.preventDefault();sync(form);
      const input=form.elements.namedItem('resumeDetails'), details=parse(input.value);
      if(button.dataset.resumeSkill){const skills=form.elements.namedItem('skills'),tokens=skills.value.split(',').map(x=>x.trim()).filter(Boolean);if(!tokens.some(x=>x.toLowerCase()===button.dataset.resumeSkill.toLowerCase()))tokens.push(button.dataset.resumeSkill);skills.value=tokens.join(', ');skills.dispatchEvent(new Event('input',{bubbles:true}));return;}
      const key=button.dataset.resumeAdd||button.dataset.resumeRemove;
      if(button.hasAttribute('data-resume-add')) {details[key]||=[];if(details[key].length>=5)return;details[key].push(key==='activities'?{type:types[0]}:{});}
      else if(button.hasAttribute('data-resume-remove')){removed.set(form,{key,index:Number(button.dataset.index),row:details[key].splice(Number(button.dataset.index),1)[0]});}
      else {const item=removed.get(form);if(!item)return;details[item.key]||=[];if(details[item.key].length>=5)return;details[item.key].splice(item.index,0,item.row);removed.delete(form);}
      input.value=JSON.stringify(details);hydrate(form,{resumeDetails:input.value});
      const undo=form.querySelector('[data-resume-undo]');undo.hidden=!removed.has(form);
      if(!undo.hidden)form.querySelector('[data-resume-undo-status]').textContent='Запись убрана из черновика. Её можно вернуть до ухода со страницы.';
      changed(form);
      const rows=button.hasAttribute('data-resume-add')?form.querySelectorAll(`[data-resume-row="${key}"]`):[];
      (rows.length?rows[rows.length-1].querySelector('input,select,textarea'):form.querySelector(`[data-resume-add="${key||'experience'}"]`))?.focus();
    });
  }
  V.resumeFields=Object.freeze({valid,parse,editor,hydrate,sync,sections,install,groups});
})(window);
