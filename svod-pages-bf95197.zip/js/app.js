(function () {
  'use strict';
  const D = Svod.data, S = Svod.state, $ = (q, root = document) => root.querySelector(q);
  const {escape:e,attr,button:btn,link,empty} = Svod.ui;
  let workspace = Svod.domain.normalize(structuredClone(S.get()),S.db().active);
  const icon = Svod.icon, s = () => workspace, scenario = () => S.scenario(), official = () => Svod.domain.officialProfile(S.db().active);
  const note = (text = 'Демонстрационный сценарий. Данные и действия сохраняются только в этом браузере; вуз и компании их не получают.') => `<p class="demo-note">${icon('info')}<span>${text}</span></p>`;
  const chip = text => `<span class="meta-chip">${e(text)}</span>`;
  const day = key => new Date(key + 'T12:00:00');
  const dateText = (key, options = { day: 'numeric', month: 'long' }) => day(key).toLocaleDateString('ru-RU', options);
  const addDays = (key, amount) => { const d = day(key); d.setDate(d.getDate() + amount); return Svod.dayKey(d); };
  const today = Svod.today;
  const weekStart = key => addDays(key, -((day(key).getDay() + 6) % 7));
  const calendarAnchor = period => period === 'session' ? '2027-01-12' : today;
  let selectedDate = calendarAnchor(s().calendarPeriod), monthDate = selectedDate, calendarFilter = 'all';
  let searchKind = 'all', chatChannel = 'curator', chatOpen = false, registrationRole = 'student', registrationMethod = 'university', registrationStep = 'phone', registrationPhone = '', developerVisible = false;
  const catalogStates = Object.fromEntries(['internships','jobs','events'].map(id => [id, {query:'',direction:'',format:'',sort:'match'}]));
  const catalogState = category => catalogStates[category || $('#catalog-results')?.dataset.category || 'internships'];
  const chatDraftKey = () => 'chat:' + chatChannel;
  function saveViewContext() {
    try { sessionStorage.setItem('svod.view.'+S.db().active,JSON.stringify({catalogStates,selectedDate,monthDate,calendarFilter,chatChannel})); } catch (_) { /* Optional navigation context, never domain data. */ }
  }
  function restoreViewContext() {
    let value;try{value=JSON.parse(sessionStorage.getItem('svod.view.'+S.db().active)||'null');}catch(_){value=null;}
    selectedDate=value?.selectedDate&&Svod.forms.validDate(value.selectedDate)?value.selectedDate:calendarAnchor(s().calendarPeriod);monthDate=value?.monthDate&&Svod.forms.validDate(value.monthDate)?value.monthDate:selectedDate;
    calendarFilter=['all','study','career','practice','personal'].includes(value?.calendarFilter)?value.calendarFilter:'all';chatChannel=['curator','mentor','group'].includes(value?.chatChannel)?value.chatChannel:'curator';
    for(const id of Object.keys(catalogStates)){const c=value?.catalogStates?.[id];Object.assign(catalogStates[id],{query:typeof c?.query==='string'?c.query.slice(0,200):'',direction:['Дизайн','Разработка','Аналитика','Менеджмент','Карьера'].includes(c?.direction)?c.direction:'',format:['Удалённо','Гибрид','Очно','Онлайн'].includes(c?.format)?c.format:'',sort:c?.sort==='title'?'title':'match',mode:c?.mode==='deck'?'deck':'list'});}
  }
  const resumeTemplates = [{id:'minimal',title:'Минимализм',text:'Чистый лист, воздух и точная типографика'},{id:'modern',title:'Современный',text:'Геометрия, графика и выразительные акценты'},{id:'glass',title:'Liquid Glass',text:'Прозрачные слои и мягкий свет iOS 26'}];
  const resumeColors = {blue:{label:'Синий',value:'#426b8b'},sage:{label:'Шалфей',value:'#477463'},violet:{label:'Лаванда',value:'#7056a1'},graphite:{label:'Графит',value:'#394553'},terracotta:{label:'Терракота',value:'#a5513d'}};
  const resumeBackgrounds=[{id:'paper',label:'Чистый лист'},{id:'warm',label:'Тёплая бумага'},{id:'mesh',label:'Аврора'},{id:'blueprint',label:'Графика'},{id:'midnight',label:'Ночной'}];
  const resumeBlocks=[{id:'plain',label:'Линии',symbol:'file'},{id:'cards',label:'Карточки',symbol:'building'},{id:'rail',label:'Акценты',symbol:'sliders'}];
  const resumePresets={minimal:{background:'paper',blocks:'plain'},modern:{background:'blueprint',blocks:'rail'},glass:{background:'mesh',blocks:'cards'}};
  const systemTheme = matchMedia('(prefers-color-scheme: dark)');
  const dialog = $('#app-dialog');
  const main = $('#main'), home = document.createElement('div'), page = document.createElement('div');
  home.id = 'dashboard-view';
  while (main.firstChild) home.append(main.firstChild);
  page.id = 'section-view'; page.hidden = true; main.append(home, page);
  const printArea = document.createElement('div'); printArea.id = 'print-resume'; printArea.hidden = true; document.body.append(printArea);
  let route = '', lastPage = 'main', modalOpener = null, modalOpenerDescription = null;
  const titles = { main: 'Главная', career: 'Карьера', internships: 'Практики и стажировки', jobs: 'Вакансии', companies: 'Компании', applications: 'Мои заявки', practice: 'Моя практика', schedule: 'Расписание', events: 'Новости и события', registrations: 'Мои мероприятия', messages: 'Сообщения', profile: 'Мой профиль', resume: 'Моё резюме', favorites: 'Избранное', settings: 'Настройки', achievements: 'Достижения', register: 'Регистрация', login: 'Вход в пространство' };
  const pageRoutes = new Set(Object.keys(titles));
  const companyLogo = item => {const company=D.companies.find(c=>c.id===(item.companyId||item.id)), asset=Svod.brandAssets?.[item.brand];const media=(company?.logoUrl?{src:company.logoUrl,decorative:true,width:64,height:64}:null)||company?.logoMedia || (asset?{src:asset.src,decorative:true,width:64,height:64}:{});return `<span class="company-logo ${e(item.brand)}" aria-hidden="true">${Svod.ui.media(media,{kind:'logo',fallback:item.logo||company?.name?.slice(0,1)||'С'})}</span>`;};
  const findOffer = id => D.recommendations.find(x => x.id === id);
  const allTasks = () => {
    const sets = {
      freshman: [{id:'orientation',title:'Найди то, что тебе интересно',subtitle:'Выбери направления и настрой свои рекомендации',tag:'+50 XP',type:'onboarding'},{...D.tasks[2]},{id:'first-company',title:'Познакомься с командами',subtitle:'Исследуй направления в каталоге компаний',tag:'Твой первый шаг',type:'companies'}],
      junior: D.tasks,
      senior: [{id:'practice-plan',title:'Согласуй план практики',subtitle:'Обсуди задачи и сроки с наставником',tag:'До 20 ноя',date:'2026-11-20',type:'checklist'},{id:'practice-report',title:'Собери результат в отчёт',subtitle:'Сохрани задачи, решения и выводы',tag:'До 25 дек',date:'2026-12-25',type:'report'},{...D.tasks[0]}],
      graduate: [{...D.tasks[0]},{id:'first-job',title:'Найди свою первую команду',subtitle:'Выбери вакансию и сохрани демо-отклик',tag:'Новый этап',type:'jobs'},{id:'interview',title:'Подготовься к знакомству',subtitle:'Продумай рассказ о себе и вопросы команде',tag:'+50 XP',type:'interview'}]
    };
    return [...sets[S.db().active].map(t => ({ ...t, date: t.date || (t.id==='practice'?'2026-11-30':t.id==='event'?'2026-11-19':'') })), ...s().tasks.map(t => ({ ...t, subtitle: 'Личная задача', type: 'personal' }))];
  };
  const resumePercent = () => Math.round(['about', 'skills', 'project', 'email'].filter(k => s().resume[k].trim()).length / 4 * 100);
  const xp = () => Svod.domain.xp(s());
  const taskDone = id => Svod.domain.taskCompleted(s(),id);
  function toast(text, error = false) {
    const el = document.createElement('div'); el.className = 'toast' + (error ? ' error' : '');
    el.innerHTML = icon(error ? 'info' : 'check') + `<span>${e(text)}</span>`; $('#toast-container').append(el);
    setTimeout(() => { el.classList.add('exiting'); setTimeout(() => el.remove(), 300); }, 3800);
  }
  function applyTheme() {
    const dark=S.db().theme==='dark'||S.db().theme==='system'&&systemTheme.matches;
    document.documentElement.dataset.theme=dark?'dark':'light';
    document.documentElement.style.colorScheme=dark?'dark':'light';
    $('meta[name="theme-color"]').content=dark?'#111d2b':'#e7eef4';
    document.querySelectorAll('[data-action="toggle-theme"]').forEach(button=>{
      button.innerHTML=icon(dark?'sun':'moon');button.setAttribute('aria-label',dark?'Включить светлую тему':'Включить тёмную тему');button.title=button.getAttribute('aria-label');button.setAttribute('aria-pressed',String(dark));
    });
  }
  let router;
  function go(path) { closeSidebar(); router.go(path); }
  function rememberModalOpener() {
    modalOpener = document.activeElement;
    modalOpenerDescription = modalOpener ? {
      id: modalOpener.id, href: modalOpener.getAttribute('href'), action: modalOpener.dataset?.action,
      actionId: modalOpener.dataset?.id, section: modalOpener.dataset?.section, label: modalOpener.getAttribute('aria-label')
    } : null;
  }
  function restoreModalFocus() {
    let target = modalOpener?.isConnected && !modalOpener.closest('[hidden]') ? modalOpener : null;
    const descriptor = modalOpenerDescription;
    if (!target && descriptor) {
      if (descriptor.id) target = document.getElementById(descriptor.id);
      if (!target && (descriptor.href || descriptor.action)) target = [...document.querySelectorAll('a[href],button[data-action]')].find(element =>
        !element.disabled && !element.closest('[hidden]') && (descriptor.href ? element.getAttribute('href') === descriptor.href :
          element.dataset.action === descriptor.action && element.dataset.id === descriptor.actionId && element.dataset.section === descriptor.section && (!descriptor.label || element.getAttribute('aria-label') === descriptor.label)));
    }
    (target || main).focus({preventScroll:true});
  }
  function closeTransientDialog() { Svod.forms.flush(); dialog.close(); restoreModalFocus(); }
  function showDialog(title, body, subtitle = '') {
    if (!dialog.open) rememberModalOpener();
    Svod.forms?.flush();
    $('#dialog-content').innerHTML = `<header class="dialog-header"><div><h2 id="dialog-title">${e(title)}</h2>${subtitle ? `<p>${e(subtitle)}</p>` : ''}</div><button type="button" class="icon-button" data-action="close-dialog" aria-label="Закрыть">${icon('close')}</button></header><div class="dialog-body">${body}</div>`;
    if (!dialog.open) dialog.showModal();
    dialog.scrollTop = 0;
    $('.dialog-body',dialog).scrollTop = 0;
    Svod.forms?.mount(dialog);
  }
  function closeDialog() { if(pageRoutes.has(router.current())||router.current().startsWith('assessment/'))closeTransientDialog();else router.close(); }
  function pageLayout(title, intro, body, actions = '', kicker = 'ТВОЁ ПРОСТРАНСТВО') {
    return `<header class="page-heading"><div><p class="eyebrow">${e(kicker)}</p><h1>${e(titles[route] || title)}</h1><p>${e(title !== titles[route] ? title + ". " + intro : intro)}</p></div><div class="page-actions">${actions}</div></header>${body}<footer class="page-footer"><span>СВОД × Московский Политех</span><span>Демо-пространство студента</span></footer>`;
  }
  const careerTabs = active => `<div class="career-tabs-rail"><button type="button" class="icon-button career-tabs-arrow" data-action="career-tabs-scroll" data-id="prev" aria-label="Прокрутить разделы влево">${icon('chevron-left')}</button><nav class="page-tabs" aria-label="Разделы карьеры">${[['career','Обзор'],['internships','Практики'],['jobs','Вакансии'],['companies','Компании'],['applications','Мои заявки'],['practice','Моя практика']].sort((a,b)=>active==='career'?0:Number(b[0]===active)-Number(a[0]===active)).map(([id, label]) => `<a href="#${id}" class="${active === id ? 'active' : ''}" ${active === id ? 'aria-current="page"' : ''}>${label}</a>`).join('')}</nav><button type="button" class="icon-button career-tabs-arrow" data-action="career-tabs-scroll" data-id="next" aria-label="Прокрутить разделы вправо">${icon('chevron-right')}</button></div>`;
  function score(item) {
    return Svod.domain.score(s(),item);
  }
  function recommendationCard(item) {
    const saved = s().favorites.includes(item.id), compared = s().compare.includes(item.id), event=item.category==='events'?Svod.domain.eventState(s(),item):null;
    return `<article class="recommendation-card"><div class="recommendation-card-header">${companyLogo(item)}<div><div class="company-name">${e(item.company)}</div><div class="company-caption">${e(item.type)} · демо</div></div><button type="button" class="icon-button bookmark-button ${saved ? 'saved' : ''}" ${attr('favorite', item.id)} aria-label="${saved ? 'Убрать из' : 'Добавить в'} избранное: ${e(item.title)}" aria-pressed="${saved}">${icon('bookmark')}</button></div>${link(e(item.title),'offer/'+item.id,'recommendation-title','')}<div class="recommendation-meta">${chip(item.format)}${chip(item.category === 'events' ? item.city : item.direction)}</div><p class="recommendation-duration">${icon(item.category === 'events' ? 'calendar' : 'clock')}${e(item.category==='events'?dateText(item.date,{day:'numeric',month:'long',year:'numeric'})+' · '+item.time+' МСК':item.salary || item.duration)}</p><div class="recommendation-bottom"><button type="button" class="match-score" ${attr('offer', item.id)} aria-label="Почему подходит: ${e(item.title)}">${icon('sparkles')}${score(item)}% совпадение</button><button type="button" class="recommendation-open" ${attr('offer', item.id)} aria-label="Открыть: ${e(item.title)}">${icon('arrow-up-right')}</button></div>${!event&&s().applications.includes(item.id)?Svod.ui.badge(s().practiceId===item.id?'Место согласовано':'Заявка на рассмотрении'):''}${event?`<p class="event-status">${Svod.ui.badge(event.label,event.registered?'approved':event.past||event.closed?'closed':'neutral')} <span>${event.seats} свободных мест</span></p><div class="detail-actions">${event.registered?btn('Отменить запись','register',item.id,'text-button')+btn('В календарь .ics','event-ics',item.id,'text-button','download'):event.canRegister?btn('Записаться','register',item.id,'secondary-button','calendar'):''}</div>`:''}${item.category !== 'events' ? `<button type="button" class="compare-link ${compared ? 'selected' : ''}" ${attr('compare-toggle', item.id)} aria-pressed="${compared}">${icon(compared ? 'check' : 'plus')}${compared ? 'В сравнении' : 'Сравнить'}</button>` : ''}</article>`;
  }
  function newsCards(items=D.news){return `<div class="news-grid">${items.map(n=>`<article class="news-card ${e(n.style)}">${Svod.ui.media(n.media||{decorative:true,width:1200,height:675},{kind:'cover',className:'news-media'})}<span class="news-tag">${e(n.tag)}</span><h3>${link(e(n.title),'news/'+n.id,'news-title-link','')}</h3><p>${e(n.text)}</p><span class="news-bottom"><span>${e(n.date)}</span>${icon(n.icon)}</span></article>`).join('')}</div>`;}
  function scheduleItems(key,period=null) { return Svod.domain.calendarEvents(s(),key,period); }
  function agenda(key, filter = 'all', period = null) {
    const items = scheduleItems(key,period).filter(x => filter === 'all' || x.category === filter);
    return items.length ? items.map(x => `<button type="button" class="schedule-item ${e(x.category)}" ${attr(x.offer ? 'offer' : x.personal ? 'task' : 'class',x.offer || x.personal ? x.id : `${key}/${x.id}`)}><span class="schedule-time">${e(x.time)}<small>${e(x.end)}</small></span><span class="schedule-info"><strong>${e(x.title)}</strong><small>${icon(x.location.includes('Онлайн') ? 'video' : 'location')}${e(x.location)}</small><span class="schedule-kind">${e(x.kind)}</span></span></button>`).join('') : empty('Свободный день', 'Можно отдохнуть или запланировать что-то своё.', 'add-task', 'Добавить задачу');
  }
  function noticeItem(n, full = false) { return `<button type="button" class="${full ? 'dialog-notice' : 'notice-item'} ${s().read.includes(n.id) ? 'read' : ''}" ${attr('notice',n.id)}><span class="notice-icon ${n.color}">${icon(n.icon)}</span><span class="notice-copy"><strong>${e(n.title)}</strong><small>${e(n.text)}</small>${full ? `<time>${e(n.time)} · демо</time>` : ''}</span><span class="notice-arrow">${icon('chevron-right')}</span></button>`; }
  const statusLabels={submitted:'На рассмотрении',approved:'Место согласовано',withdrawn:'Отозвана',rejected:'Отклонена',review:'На проверке',accepted:'Принят',revision:'На доработку'};
  function syncChatViewport() {
    if(!document.body.classList.contains('messages-page')){
      document.documentElement.style.setProperty('--mobile-keyboard-inset','0px');document.body.classList.remove('chat-keyboard-open','chat-viewport-compact');return;
    }
    const viewport=window.visualViewport;
    const height=viewport&&Math.abs(viewport.scale-1)<.02?viewport.height:window.innerHeight;
    document.documentElement.style.setProperty('--chat-viewport-height',Math.round(height)+'px');
    const inset=viewport&&Math.abs(viewport.scale-1)<.02?Math.max(0,window.innerHeight-viewport.height-viewport.offsetTop):0;
    document.documentElement.style.setProperty('--mobile-keyboard-inset',Math.round(inset)+'px');
    document.body.classList.toggle('chat-keyboard-open',innerWidth<=760&&inset>120);
    document.body.classList.toggle('chat-viewport-compact',innerWidth<=760&&height<420);
  }
  const view = () => Object.freeze({ selectedDate, monthDate, calendarFilter, chatChannel, chatOpen, registrationRole, registrationMethod, registrationStep, registrationPhone, developerVisible, searchKind, route });
  const { renderTasks, renderSchedule, renderDashboard, renderCatalog, updateCatalog, careerPage, calendarPage, companiesPage, applicationsPage, practicePage, demoTools, eventsPage, profilePage, readResumeDraft, resumeDocument, updateResumePreview, resumePage, favoritesPage, achievementsPage, chatBubble, messagesPage, settingsPage, loginPage, registrationPage, getAssessmentAttempt, assessmentPage } = Svod.createPages(Object.freeze({
    D, S, $, s, scenario, official, e, icon, attr, btn, link, empty, note, chip, day, dateText, addDays, today, weekStart, companyLogo, findOffer, allTasks, resumePercent, xp, pageLayout, careerTabs, score, recommendationCard, newsCards, scheduleItems, agenda, noticeItem, catalogState, chatDraftKey, resumeTemplates, resumeColors, resumeBackgrounds, resumeBlocks, statusLabels, view, taskDone,
    decideOffer:async(id,right)=>{const key=right?'favorites':'hidden';if(!s()[key].includes(id))await Svod.repository.command('toggle',{key,id});workspace=await Svod.repository.query('workspace');}
  }));
  const { applicationSnapshot, showOffer, showCompany, showArticle, showTask, showAddTask, showCustomize, showPreferences, showCompare, showSearch, updateSearch, showEditProfile, showGuide, showPriority, showConfirmation, resumeTips, notFound, showClass, showUtility } = Svod.createDialogs(Object.freeze({
    D, S, $, s, scenario, official, e, icon, attr, btn, link, empty, note, chip, day, dateText, addDays, today, companyLogo, findOffer, allTasks, score, showDialog, pageRoutes, titles, view, taskDone, renderRoute, noticeItem, scheduleItems, dialog, closeTransientDialog, getRouter: () => router
  }));
  function renderView(options = {}) {
    try {route=options.path || decodeURIComponent(location.hash.slice(1) || 'main');}catch(_){route='main';}
    if(route==='/' || route==='')route='main';
    const parts=route.split('/'),key=parts[0],id=parts[1];
    if(!pageRoutes.has(route)&&key!=='assessment')lastPage=router?.parent() || 'main';
    const assessmentRoute=key==='assessment';
    if(pageRoutes.has(route)||assessmentRoute) {
      const wasDialogOpen=dialog.open;
      if(wasDialogOpen)dialog.close();
      const changed=lastPage!==route;if(changed&&route==='messages')chatOpen=false; lastPage=route;
      document.body.dataset.page=route;
      document.body.classList.toggle('messages-page',route==='messages');
      syncChatViewport();
      home.hidden=route!=='main';page.hidden=route==='main';
      const pages={career:careerPage,companies:companiesPage,applications:applicationsPage,practice:practicePage,schedule:calendarPage,events:()=>eventsPage(false),registrations:()=>eventsPage(true),profile:profilePage,resume:resumePage,favorites:favoritesPage,achievements:achievementsPage,messages:messagesPage,settings:settingsPage,login:loginPage,register:registrationPage};
      if(assessmentRoute)page.innerHTML=assessmentPage(id);
      else if(route==='internships'||route==='jobs')page.innerHTML=pageLayout(route==='internships'?'Найди опыт, который вдохновляет':'Найди команду для своего старта',route==='internships'?'Практики и стажировки под твои интересы, навыки и ритм.':'Первые карьерные возможности для начинающих специалистов.',careerTabs(route)+renderCatalog(route),link('Критерии подбора','preferences','secondary-button','sliders')+`<details class="catalog-view-picker"><summary class="secondary-button">${icon('sliders')}Режим просмотра</summary><div role="group" aria-label="Режим просмотра">${btn('Списком','catalog-view','list',catalogState(route).mode!=='deck'?'active':'')}${btn('СВОДом','catalog-view','deck',catalogState(route).mode==='deck'?'active':'')}</div></details>`);
      else if(route!=='main')page.innerHTML=pages[route]();
      if(route==='settings')$('.page-actions',page).insertAdjacentHTML('beforeend',btn('Завершить демо-сессию','demo-signout','','secondary-button','arrow-right'));
  
      const isCareerSection=['career','internships','jobs','companies','applications','practice'].includes(route);
      document.body.dataset.careerSection=String(isCareerSection);
      if(isCareerSection && route!=='career') {
        const rail=$('.career-tabs-rail',page);
        if(rail){const row=document.createElement('div');row.className='career-navigation-row';rail.before(row);row.append(rail);row.insertAdjacentHTML('beforeend',link('Моё резюме','resume','primary-button career-resume-link','file'));}
      }
      const calendarLink=$('.mobile-calendar-link');if(route==='schedule')calendarLink.setAttribute('aria-current','page');else calendarLink.removeAttribute('aria-current');
      Svod.forms.mount(page);
      if(route==='resume')updateResumePreview();
      if($('#catalog-results'))updateCatalog();
      if(route==='messages'){const thread=$('#chat-thread');thread.scrollTop=thread.scrollHeight;}
      if(wasDialogOpen&&!changed)restoreModalFocus();
      else if(changed && options.focus!==false){window.scrollTo({top:0,behavior:'instant'});main.focus({preventScroll:true});}
      const navGroup=assessmentRoute||['career','internships','jobs','companies','applications','practice'].includes(route)?'career':['events','registrations'].includes(route)?'events':['profile','resume','favorites','achievements','settings'].includes(route)?'profile':route;
      document.querySelectorAll('.main-nav .nav-item').forEach(el=>{const match=el.dataset.section===navGroup || el.dataset.action===navGroup || navGroup==='main'&&el.tagName==='A';el.classList.toggle('active',match);const dot=$('.active-dot',el);if(dot)dot.hidden=!match;if(match)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current');});
      const mobileGroup=['events','registrations'].includes(navGroup)?'main':navGroup==='login'?'profile':navGroup;
      document.querySelectorAll('.mobile-nav-item').forEach(el=>{const active=el.dataset.mobileSection===mobileGroup;el.classList.toggle('active',active);if(active)el.setAttribute('aria-current','page');else el.removeAttribute('aria-current');});
      const title=assessmentRoute?'Первичное тестирование':titles[route];$('.breadcrumb strong').textContent=title;document.title=title+' · СВОД × Московский Политех';
      return;
    }
    if(key==='offer')return showOffer(id);
    if(key==='company')return showCompany(id);
    if(key==='news')return showArticle(id);
    if(key==='application-resume')return applicationSnapshot(id);
    if(key==='task')return showTask(id);
    if(key==='edit-task')return showAddTask(id);
    if(key==='class')return showClass(id,parts[2]);
    return showUtility(route);
  }
  function syncShellData(){
    const unread=Svod.domain.notices(s()).filter(n=>!s().read.includes(n.id)).length;
    $('.notification-dot').hidden=!unread||!s().preferences.notifications;
    $('.notification-trigger').setAttribute('aria-label','Уведомления: '+unread+' непрочитанных');
    const unreadChats=Svod.domain.unreadMessages(s());$('.nav-count').textContent=unreadChats||'';$('.nav-count').hidden=!unreadChats;$('.mobile-message-count').hidden=!unreadChats;
    const count=s().favorites.length;$('.favorite-count').textContent=count;$('.favorite-count').hidden=!count;
  }
  function acceptBootstrap(result){
    workspace=result.workspace;
    for(const [key,value] of Object.entries(result.catalog||{}))if(['recommendations','companies','news','articles','schedule','checklist','chats','semester','exams','tasks','faq'].includes(key))D[key]=value;
    if(result.catalog?.assessments)Svod.assessments.setDefinitions?.(result.catalog.assessments);
    if(result.officialProfile)D.officialProfiles[S.db().active]=result.officialProfile;
    Svod.session.hydrate?.(result.session);syncShellData();
  }
  function showAccessState(status){
    if(dialog.open)dialog.close();document.body.classList.remove('messages-page');home.hidden=true;page.hidden=false;
    page.innerHTML=`<header class="page-heading"><h1>${status==='denied'?'Нет доступа':'Сессия завершена'}</h1></header><section class="card content-card"><p>${status==='denied'?'Нет разрешения на просмотр этого профиля.':'Введённые данные сохранены в черновиках. Войди в локальный демо-кабинет, чтобы продолжить.'}</p>${link('Открыть демо-вход','login','primary-button')}</section>`;main.focus({preventScroll:true});
  }
  async function renderRoute(options={}) {
    Svod.forms.flush();
    const token=++renderGeneration,path=router?.current() || location.hash.slice(1) || 'main';
    const isPage=pageRoutes.has(path)||path.startsWith('assessment/');
    if(path.startsWith('company/')){Svod.university.leave();await Svod.company.render(path,options);return;}
    Svod.company.leave();
    if(path.startsWith('university/')){await Svod.university.render(path,options);return;}
    Svod.university.leave();
    const status=Svod.session.get().status;
    if(!['login','register'].includes(path) && status!=='active' && Svod.repository.mode?.()!=='api') { showAccessState(status);return; }
    if(isPage && path!==lastPage && !['login','register'].includes(path)){home.hidden=true;page.hidden=false;page.innerHTML=Svod.ui.loading();}
    try {
      if(!['login','register'].includes(path)){const result=await Svod.repository.query('bootstrap');if(token!==renderGeneration)return;acceptBootstrap(result);if(result.session.status!=='active'){showAccessState(result.session.status);return;}}
      else workspace=Svod.domain.normalize(structuredClone(S.get()),S.db().active);
      if(token!==renderGeneration || (router?.current()||'main')!==path)return;
      if(!isPage && (home.hidden && !page.dataset.pageContent || lastPage!==router.parent()))renderView({path:router.parent(),focus:false});
      renderView({...options,path});
      applyTheme();
      page.setAttribute('data-page-content',path);
      if(path==='main')renderDashboard();
      if(S.repairWarnings().length&&!document.querySelector('.repair-warning')){const message=document.createElement('p');message.className='storage-warning repair-warning';message.textContent='Часть повреждённых или устаревших данных восстановлена. Остальные данные сохранены; сведения — в настройках.';document.body.append(message);}
    } catch(error) {
      if(token!==renderGeneration)return;
      if(['SESSION_EXPIRED','FORBIDDEN'].includes(error.code)){showAccessState(error.code==='FORBIDDEN'?'denied':'expired');return;}
      home.hidden=true;page.hidden=false;document.body.classList.remove('messages-page');page.innerHTML=Svod.ui.error(error.message,'retry-route');
      $('[data-action="retry-route"]',page).addEventListener('click',()=>renderRoute(options));
    }
  }
  function refresh() {if(lastPage==='main')renderDashboard();renderRoute({focus:false});}
  function closeSidebar() {document.body.classList.remove('sidebar-open');$('.workspace').inert=false;$('[data-action="open-sidebar"]').setAttribute('aria-expanded','false');}
  function openSidebar() {document.body.classList.add('sidebar-open');$('.workspace').inert=true;$('[data-action="open-sidebar"]').setAttribute('aria-expanded','true');$('.sidebar .brand').focus();}
  function download(content,filename,type) {
    const url=URL.createObjectURL(new Blob([content],{type})),anchor=document.createElement('a');anchor.href=url;anchor.download=filename;document.body.append(anchor);anchor.click();anchor.remove();setTimeout(()=>URL.revokeObjectURL(url),10000);
  }
  function eventIcs(id) {
    const x=findOffer(id);if(!x||!x.date)return;
    const start=new Date(x.startsAt),end=new Date(x.endsAt);
    const stamp=d=>d.toISOString().replace(/[-:]/g,'').replace(/\.\d{3}/,'');
    const icsEscape=value=>value.replace(/\\/g,'\\\\').replace(/\n/g,'\\n').replace(/,/g,'\\,').replace(/;/g,'\\;');
    download(['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//SVOD//Student Space//RU','BEGIN:VEVENT','UID:'+x.id+'@svod.demo','DTSTAMP:'+stamp(new Date()),'DTSTART:'+stamp(start),'DTEND:'+stamp(end),'SUMMARY:'+icsEscape(x.title),'LOCATION:'+icsEscape(x.city),'DESCRIPTION:Демонстрационное событие СВОД.','END:VEVENT','END:VCALENDAR',''].join('\r\n'),x.id+'.ics','text/calendar;charset=utf-8');
  }
  const pendingCommands = new Set();
  let renderGeneration = 0;
  function actionError(error, retry, container = dialog.open ? $('.dialog-body',dialog) : page.hidden ? home : page) {
    $('.action-error',container)?.remove();
    const box=document.createElement('div');box.className='action-error form-error';box.setAttribute('role','alert');
    box.innerHTML=`<strong>${e(error.code==='FORBIDDEN'?'Нет доступа':error.code==='SESSION_EXPIRED'?'Сессия истекла':'Действие не выполнено')}</strong><p>${e(error.message || 'Попробуй ещё раз. Введённые данные сохранены.')}</p>`;
    if(retry){const button=document.createElement('button');button.type='button';button.className='secondary-button';button.textContent='Повторить';button.addEventListener('click',()=>{box.remove();retry();});box.append(button);}
    container.prepend(box);
    Svod.forms?.flush();
  }
  async function execute(name,payload={},options={}) {
    const key=name+':'+(payload.id||payload.offerId||payload.eventId||payload.chatId||JSON.stringify(payload));
    if(pendingCommands.has(key))return false;
    const context=router.current(),scenarioId=S.db().active,element=options.element || document.activeElement;
    const requestKey=options.requestKey || (globalThis.crypto?.randomUUID?.() || Date.now()+'-'+Math.random());
    pendingCommands.add(key);
    const isForm=element?.tagName==='FORM';
    const editable=isForm&&element.id!=='chat-form'?[...element.querySelectorAll('input,select,textarea,button')]:[];
    const disabledBefore=new Map(editable.map(input=>[input,input.disabled]));
    editable.forEach(input=>input.disabled=true);
    const controls=isForm?[...element.querySelectorAll('button[type="submit"]')]:element?.tagName==='BUTTON'?[element]:[];
    controls.forEach(control=>{control.disabled=true;control.setAttribute('aria-busy','true');});
    try {
      const result=await Svod.repository.command(name,payload,{idempotencyKey:requestKey,demo:options.demo===true});
      if(name!=='setSession'){const nextWorkspace=await Svod.repository.query('workspace');const expectedScenario=name==='changeScenario'?payload.id:scenarioId;if(S.db().active===expectedScenario){workspace=nextWorkspace;syncShellData();}}
      if(S.db().active===scenarioId && router.current()===context || options.allowContextChange){
        if(options.after)await options.after(result);else if(options.refresh!==false)refresh();
        if(options.success)toast(options.success);
      }
      return true;
    } catch(error) {
      if(S.db().active===scenarioId && router.current()===context)actionError(error,()=>execute(name,payload,{...options,requestKey}));
      return false;
    } finally {pendingCommands.delete(key);controls.forEach(control=>{control.disabled=false;control.removeAttribute('aria-busy');});disabledBefore.forEach((disabled,input)=>input.disabled=disabled);}
  }
  async function sendChat(text) {
    if(!text.trim())return;
    const channel=chatChannel, form=$('#chat-form'), thread=$('#chat-thread'), input=$('#chat-text'), submittedInput=$('#chat-text')?.value;
    const oldIds=new Set(s().messages.map(m=>m.id));
    return execute('sendMessage',{chatId:channel,text:text.trim()},{element:form,refresh:false,after:()=>{
      const clearInput=input?.value===submittedInput && submittedInput?.trim()===text.trim();
      if(clearInput)Svod.forms.clear('chat:'+channel);else if(form?.isConnected){Svod.forms.queue(form);Svod.forms.flush();}
      if(thread?.isConnected){const additions=s().messages.filter(m=>m.chatId===channel&&!oldIds.has(m.id));thread.insertAdjacentHTML('beforeend',additions.map(chatBubble).join(''));thread.scrollTop=thread.scrollHeight;}
      if(input?.isConnected){if(clearInput){input.value='';form.classList.remove('has-text');}input.focus({preventScroll:true});}
    }});
  }
  document.addEventListener('click',async event=>{
    const el=event.target.closest('[data-action]');if(!el || el.disabled)return;
    const action=el.dataset.action,id=el.dataset.id || '';
    const cmd=(name,payload={},extra={})=>execute(name,payload,{element:el,...extra});
    if(action==='career-tabs-scroll'){const nav=el.closest('.career-tabs-rail').querySelector('.page-tabs');nav.scrollBy({left:(id==='prev'?-1:1)*Math.max(140,nav.clientWidth*.7),behavior:'smooth'});return;}
    if(action==='toggle-theme'&&['login','register'].includes(router.current())){
      const theme=document.documentElement.dataset.theme==='dark'?'light':'dark';
      // Public appearance is a local device preference, independent of student authorization.
      if(!S.transact((state,database)=>{database.theme=theme;})){actionError(S.lastError()||{message:'Не удалось сохранить тему.'});return;}
      applyTheme();return;
    }
    if(action==='toggle-theme')return cmd('configure',{appearance:{theme:document.documentElement.dataset.theme==='dark'?'light':'dark'}},{refresh:false,after:()=>{applyTheme();const select=$('#theme-select');if(select)select.value=S.db().theme;}});
    if(['resume-design','resume-color','resume-background','resume-blocks'].includes(action)){
      const key={'resume-design':'template','resume-color':'color','resume-background':'background','resume-blocks':'blocks'}[action];
      const valid=action==='resume-design'?resumeTemplates.some(t=>t.id===id):action==='resume-color'?Object.hasOwn(resumeColors,id):action==='resume-background'?resumeBackgrounds.some(b=>b.id===id):resumeBlocks.some(b=>b.id===id);if(!valid)return;
      return cmd('configure',{values:{resumeDesign:{...s().resumeDesign,...(key==='template'?resumePresets[id]:{}),[key]:id}}},{refresh:false,after:updateResumePreview});
    }
    const routes={schedule:'schedule',profile:'profile',messages:'messages',favorites:'favorites',notifications:'notifications',search:'search',quick:'quick',help:'help',guide:'guide',university:'university',customize:'customize',priority:'priority','add-task':'add-task','task-history':'task-history','resume-tips':'resume-tips'};
    if(routes[action])return go(routes[action]);
    if(action==='nav')return go(id);
    if(action==='register-role'){registrationRole=['student','university','company'].includes(id)?id:'student';await renderRoute({focus:false});document.querySelector('[data-action="register-role"][data-id="'+registrationRole+'"]')?.focus({preventScroll:true});return;}
    if(action==='register-method'){registrationMethod=id==='phone'?'phone':'university';registrationStep='phone';return refresh();}
    if(action==='register-phone-reset'){registrationStep='phone';return refresh();}
    if(action==='demo-login')return cmd('setSession',{status:'active'},{allowContextChange:true,after:()=>{go(s().onboarded?'main':'onboarding');}});
    if(action==='demo-signout')return cmd('setSession',{status:'signed-out'},{after:()=>go('login')});
    if(action==='section')return go(el.dataset.section);
    if(['offer','task','company','class','edit-task'].includes(action))return go(action+'/'+id);
    if(action==='article')return go('news/'+id);
    if(action==='close-dialog')return closeDialog();
    if(action==='skip-onboarding'){Svod.forms.clear('preferences-form','discarded');return cmd('configure',{values:{onboarded:true}},{after:()=>{toast('Настройка пропущена. Сохранённые интересы не изменились.');go('main');}});}
    if(action==='open-sidebar')return openSidebar();
    if(action==='close-sidebar')return closeSidebar();
    if(action==='collapse')return cmd('configure',{appearance:{collapsed:!S.db().collapsed}},{after:renderDashboard});
    if(action==='hero')return go(Svod.domain.nextStep(s(),S.db().active).action);
    if(action==='set-priority')return cmd('configure',{values:{focus:id}},{success:'Главный акцент обновлён',after:()=>go('main')});
    if(action==='rec-tab')return cmd('configure',{values:{filters:{...s().filters,recommendation:id}}},{after:renderDashboard});
    if(action==='favorite')return cmd('toggle',{key:'favorites',id},{success:s().favorites.includes(id)?'Убрано из избранного':'Сохранено в избранное'});
    if(action==='task-toggle')return cmd('toggle',{key:'done',id},{success:'Состояние задачи обновлено'});
    if(action==='delete-task')return showConfirmation('Удалить личную задачу?','Задача и отметка выполнения будут удалены.',()=>cmd('deleteTask',{id},{success:'Задача удалена',after:()=>go(lastPage)}));
    if(action==='week-prev'||action==='week-next'){selectedDate=addDays(selectedDate,action==='week-prev'?-7:7);saveViewContext();return renderSchedule();}
    if(action==='select-day'){selectedDate=id;saveViewContext();return renderSchedule();}
    if(action==='calendar-day'){selectedDate=id;monthDate=id;saveViewContext();return refresh();}
    if(action==='month-prev'||action==='month-next'){const d=day(monthDate);d.setDate(1);d.setMonth(d.getMonth()+(action==='month-prev'?-1:1));monthDate=Svod.dayKey(d);saveViewContext();return refresh();}
    if(action==='calendar-today'){selectedDate=today;monthDate=today;saveViewContext();return refresh();}
    if(action==='calendar-filter'){calendarFilter=id;saveViewContext();return refresh();}
    if(action==='calendar-period'){if(!['semester','session','practice'].includes(id))return;return cmd('configure',{values:{calendarPeriod:id}},{after:()=>{selectedDate=calendarAnchor(id);monthDate=selectedDate;calendarFilter='all';saveViewContext();refresh();}});}
    if(action==='catalog-view'){if(!['list','deck'].includes(id))return;catalogState().mode=id;saveViewContext();return renderRoute({focus:false});}
    if(action==='catalog-reset'){Object.assign(catalogState(),{query:'',direction:'',format:'',sort:'match'});saveViewContext();return renderRoute({focus:false});}
    if(action==='compare-toggle')return cmd('toggle',{key:'compare',id},{success:'Сравнение обновлено'});
    if(action==='apply'){const item=findOffer(id);if(!item)return;if(item.category==='internships')return go('assessment/'+id);return cmd('submitApplication',{offerId:id},{success:'Заявка сохранена со снимком резюме'});}
    if(action==='assessment-retry')return cmd('retryAssessment',{offerId:id});
    if(action==='submit-practice-application')return cmd('submitApplication',{offerId:id},{success:'Заявка сохранена со снимком резюме',after:()=>go('applications')});
    if(action==='withdraw')return showConfirmation('Отозвать заявку?','В истории останется запись об отзыве. Резюме и профиль сохранятся.',()=>cmd('withdrawApplication',{offerId:id},{success:'Заявка отозвана'}));
    if(action==='confirm-practice')return cmd('demoChoosePractice',{offerId:id},{demo:true,success:'Демо-решение вуза: место согласовано',after:()=>go('practice')});
    if(action==='change-practice')return showConfirmation('Изменить место практики?','Текущая практика будет отменена с сохранением истории. Профиль и резюме останутся.',()=>cmd('changePractice',{},{success:'Можно выбрать другое место',after:()=>go('applications')}));
    if(action==='register')return cmd(s().registrations.includes(id)?'cancelRegistration':'registerEvent',{eventId:id},{success:s().registrations.includes(id)?'Запись отменена':'Ты записан. Событие добавлено в календарь'});
    if(action==='event-ics')return eventIcs(id);
    if(action==='hide-offer')return cmd('toggle',{key:'hidden',id},{success:'Предложение скрыто из рекомендаций',after:()=>go(lastPage)});
    if(action==='restore-hidden')return cmd('configure',{values:{hidden:[]}},{success:'Предложения возвращены'});
    if(action==='subscribe')return cmd('toggle',{key:'subscriptions',id},{success:'Демо-подписки обновлены'});
    if(action==='notice'){const n=Svod.domain.notices(s()).find(x=>x.id===id);if(!n)return;return cmd('toggle',{key:'read',id},{after:()=>go(n.action)});}
    if(action==='read-all')return cmd('configure',{values:{read:[...new Set([...s().read,...Svod.domain.notices(s()).map(n=>n.id)])]}});
    if(action==='widget-toggle')return cmd('toggle',{key:'hiddenWidgets',id});
    if(action==='widget-up'||action==='widget-down'){const ids=[...new Set([...s().widgets,...D.widgets.map(w=>w.id)])],column=ids.filter(key=>D.widgets.find(w=>w.id===key)?.column===D.widgets.find(w=>w.id===id)?.column),position=column.indexOf(id),neighbor=column[position+(action==='widget-up'?-1:1)];if(neighbor){const i=ids.indexOf(id),j=ids.indexOf(neighbor);[ids[i],ids[j]]=[ids[j],ids[i]];}return cmd('configure',{values:{widgets:ids}});}
    if(action==='widgets-reset')return cmd('configure',{values:{widgets:D.widgets.map(w=>w.id),hiddenWidgets:[]}},{success:'Главная восстановлена'});
    if(action==='search-kind'){const query=$('#global-search').value;searchKind=id;document.querySelectorAll('.search-categories button').forEach(b=>b.classList.toggle('active',b.dataset.id===id));return updateSearch(query);}
    if(action==='channel'){Svod.forms.flush();chatChannel=id;chatOpen=true;saveViewContext();return refresh();}
    if(action==='chat-back'){Svod.forms.flush();chatOpen=false;return refresh();}
    if(action==='chat-suggestion')return sendChat(id);
    if(action==='export'){Svod.forms.flush();download(S.export(),'svod-'+S.db().active+'-'+today+'.json','application/json');return toast('Резервная копия подготовлена');}
    if(action==='reset-confirm')return cmd('reset',{},{after:()=>{Svod.forms.clearScenario();toast('Текущий сценарий сброшен');go('settings');}});
    if(action==='scenario'){Svod.forms.flush();saveViewContext();return cmd('changeScenario',{id},{allowContextChange:true,after:()=>{restoreViewContext();refresh();toast('Сценарий: '+scenario().label);}});}
    if(action==='restore-draft'){Svod.forms.restoreArchive($('#resume-form'),id);updateResumePreview();return;}
    if(action==='load-version'){const v=s().versions.find(v=>v.id===id)||s().versions[Number(id)];if(!v)return;return showConfirmation('Загрузить версию?','Текущий черновик будет сохранён отдельно. Отправленные заявки не изменятся.',async()=>{Svod.forms.prepareReplacement($('#resume-form'),'Перед загрузкой версии');return cmd('saveResume',{resume:v.resume,design:v.design},{success:'Версия загружена',after:()=>{Svod.forms.clear('resume-form','discarded');go('resume');}});});}
    if(action==='delete-version'){const v=s().versions.find(v=>v.id===id)||s().versions[Number(id)];if(!v)return;return showConfirmation('Удалить версию резюме?',`Версия «${v.name}» будет удалена. Снимки в заявках сохранятся.`,()=>cmd('deleteVersion',{id:v.id},{success:'Версия удалена'}));}
    if(action==='print-resume'){printArea.innerHTML=resumeDocument(readResumeDraft());printArea.hidden=false;window.print();return;}
    if(action==='report-status')return cmd('demoReviewReport',{status:id,comment:id==='revision'?'Уточни свой вклад и добавь выводы по проекту.':'Результат подтверждён в учебном сценарии.'},{demo:true,success:'Демо-решение проверяющего сохранено'});
    if(action==='demo-stage')return cmd('demoConfirmStage',{stageId:id},{demo:true});
    if(action==='complete-practice')return cmd('completePractice',{},{success:'Практика завершена. Добавь опыт в резюме'});
    if(action==='demo-expire')return cmd('setSession',{status:'expired'},{after:()=>renderRoute()});
    if(action==='demo-deny')return cmd('setSession',{status:'denied'},{after:()=>renderRoute()});
    if(action==='resolve-conflict')return cmd('resolveConflict',{id:id.slice(2),keepIncoming:id.startsWith('i:')},{success:'Конфликт разрешён',after:()=>go('settings')});
    if(action==='demo-fault'){Svod.repository.setFault({error:id==='offline'?'OFFLINE':'SERVER',once:true,delay:500});return toast('Следующая операция вернёт демо-ошибку. Ввод сохранится.');}
  });
  document.addEventListener('submit',async event=>{
    const form=event.target;
    if(form.classList.contains('application-clarify-form')){event.preventDefault();if(!Svod.forms.validate(form))return;return execute('resubmitApplication',{applicationId:form.dataset.id,expectedVersion:Number(form.dataset.version),...Object.fromEntries(new FormData(form))},{element:form,success:'Уточнения отправлены на рассмотрение',after:()=>{Svod.forms.clear(form,'saved');refresh();}});}
    if(['registration-phone-form','registration-code-form'].includes(form.id)){
      event.preventDefault();if(!Svod.forms.validate(form))return;
      if(form.id==='registration-phone-form'){registrationPhone=Svod.forms.normalizePhone(form.elements.phone.value);registrationStep='code';await renderRoute({focus:false});document.querySelector('#registration-code')?.focus();return;}
      if(form.elements.code.value.trim()!=='123456'){Svod.forms.setError(form.elements.code,'В учебном режиме введи 123456.');form.elements.code.focus();return;}
      return execute('setSession',{status:'active'},{element:form,allowContextChange:true,after:()=>{registrationPhone='';registrationStep='phone';go(s().onboarded?'main':'onboarding');}});
    }
    if(!['task-form','resume-form','version-form','preferences-form','profile-form','chat-form','assessment-form'].includes(form.id))return;
    event.preventDefault();if(!Svod.forms.validate(form))return;
    Svod.forms.capture(form);Svod.forms.flush();
    const values=new FormData(form),value=name=>String(values.get(name)||'').trim();
    const cmd=(name,payload,extra={})=>execute(name,payload,{element:form,...extra});
    const clear=()=>Svod.forms.clear(form.dataset.draftKey||form.id);
    if(form.id==='assessment-form')return cmd('submitAssessment',{offerId:form.dataset.offer,answers:Object.fromEntries(Svod.assessments.get(form.dataset.offer).questions.map(q=>[q.id,value(q.id)]))},{after:()=>{clear();refresh();window.scrollTo({top:0,behavior:'instant'});}});
    if(form.id==='task-form')return cmd('updateTask',{...(form.dataset.task?{id:form.dataset.task}:{}),title:value('title'),date:value('date')},{success:form.dataset.task?'Задача изменена':'Задача добавлена',after:()=>{clear();go(lastPage);}});
    if(form.id==='resume-form')return cmd('saveResume',{resume:readResumeDraft()},{success:'Рабочее резюме сохранено',after:()=>{clear();refresh();}});
    if(form.id==='version-form'){if(!Svod.forms.validate($('#resume-form')))return;return cmd('saveVersion',{name:value('name'),resume:readResumeDraft(),design:s().resumeDesign},{success:'Отдельная версия сохранена',after:()=>{clear();refresh();}});}
    if(form.id==='profile-form')return cmd('updateProfile',{resume:{...s().resume,about:value('about'),email:value('email')},personal:{phone:value('phone'),portfolio:value('portfolio')}},{success:'Личные данные сохранены',after:()=>{clear();go('profile');}});
    if(form.id==='preferences-form')return cmd('configure',{values:{interests:values.getAll('interest').map(String),preferences:{...s().preferences,format:value('format')},weights:Object.fromEntries(['interests','skills','format'].map(k=>[k,Number(value('weight-'+k))])),excluded:value('excluded')?[value('excluded')]:[],onboarded:true}},{success:'Критерии сохранены',after:()=>{clear();go(lastPage);}});
    if(form.id==='chat-form')return sendChat(value('text'));
  });
  document.addEventListener('input',event=>{
    const el=event.target;
    if(el.closest('#resume-form'))updateResumePreview();
    if(el.id==='chat-text')$('#chat-form').classList.toggle('has-text',!!el.value);
    if(el.dataset.assessmentAnswer){const form=el.form,test=Svod.assessments.get(form.dataset.offer);const answers=Svod.forms.capture(form);const count=test.questions.filter(q=>String(answers[q.id]||'').trim()).length;$('#assessment-counter').textContent=count+' из '+test.questions.length;$('.assessment-progress>span').style.width=count/test.questions.length*100+'%';}
    if(el.id==='global-search')return updateSearch(el.value);
    if(el.id==='catalog-search'){catalogState().query=el.value;saveViewContext();return updateCatalog();}
    if(el.id==='chat-search'){const q=el.value.toLowerCase();document.querySelectorAll('.channel').forEach(c=>c.hidden=!c.textContent.toLowerCase().includes(q));}
    if(el.type==='range'){const output=$(`output[for="${el.id}"]`);if(output)output.value=el.value;}
  });
  document.addEventListener('change',async event=>{
    const el=event.target;
    if(el.id==='theme-select')return execute('configure',{appearance:{theme:el.value}},{refresh:false,after:applyTheme});
    if(['catalog-direction','catalog-format','catalog-sort'].includes(el.id)){catalogState()[el.id.replace('catalog-','')]=el.value;saveViewContext();return updateCatalog();}
    if(el.id==='notification-setting')return execute('configure',{values:{preferences:{...s().preferences,notifications:el.checked}}},{success:'Уведомления настроены'});
    if(el.dataset.checklist)return execute('updateStage',{stageId:el.dataset.checklist,completed:el.checked});
    if(el.id==='report-file'){
      const file=el.files[0];if(!file)return;
      const error=Svod.forms.file(file,{extensions:['pdf','docx','txt'],maxBytes:10*1024*1024});
      if(error){el.value='';return Svod.forms.setError(el,error);}
      return execute('submitReport',{file:{name:file.name,size:file.size,type:file.type}},{success:'Метаданные отчёта переданы на демо-проверку'});
    }
    if(el.id==='import-file'){
      const file=el.files[0];if(!file)return;
      try{const error=Svod.forms.file(file,{extensions:['json'],maxBytes:10*1024*1024});if(error)throw new Error(error);const payload=JSON.parse(await file.text());return showConfirmation('Восстановить резервную копию?','Данные указанного сценария будут заменены. Остальные сценарии и черновики останутся.',()=>execute('import',{payload},{allowContextChange:true,success:'Копия восстановлена',after:()=>{applyTheme();restoreViewContext();refresh();}}));}
      catch(error){Svod.forms.setError(el,error instanceof SyntaxError?'В файле нет корректного JSON.':error.message);}
    }
  });
  dialog.addEventListener('cancel',event=>{event.preventDefault();closeDialog();});
  dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)closeDialog();}});
  document.addEventListener('keydown',event=>{
    if((event.metaKey||event.ctrlKey)&&event.key.toLowerCase()==='k'){event.preventDefault();go('search');}
    if((event.metaKey||event.ctrlKey)&&event.shiftKey&&event.key.toLowerCase()==='d'){event.preventDefault();developerVisible=!developerVisible;go('settings');}
    if(event.key==='Escape'&&document.body.classList.contains('sidebar-open')){closeSidebar();$('[data-action="open-sidebar"]').focus();}
    if(event.key==='Tab'&&document.body.classList.contains('sidebar-open')){
      const items=[...document.querySelectorAll('.sidebar a,.sidebar button')].filter(x=>x.offsetParent!==null && !x.disabled),first=items[0],last=items[items.length-1];
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
    }
    if(event.key==='Enter'&&!event.isComposing&&event.target.id==='chat-text'){event.preventDefault();$('#chat-form').requestSubmit();}
  });

  window.addEventListener('resize',()=>{closeSidebar();syncChatViewport();});
  window.visualViewport?.addEventListener('resize',syncChatViewport);
  window.visualViewport?.addEventListener('scroll',syncChatViewport);
  window.addEventListener('afterprint',()=>{printArea.hidden=true;});
  Svod.repository.subscribe?.(()=>{if(Svod.company.active()){Svod.company.syncExternal();return;}if(Svod.university.active()){Svod.university.syncExternal();return;}Svod.forms.flush();applyTheme();renderRoute({focus:false});toast('Изменения из другой вкладки синхронизированы. Черновики сохранены.');});
  systemTheme.addEventListener('change',()=>{if(!Svod.company.active()&&!Svod.university.active()&&S.db().theme==='system')applyTheme();});
  $('.brand').setAttribute('href','#main');
  $('.university').innerHTML='<img src="assets/images/mospolytech-logo.svg" class="university-logo" alt="Московский Политех"><span class="nav-label"><strong>Московский Политех</strong><small>Студенческое пространство</small></span><span class="nav-label" data-icon="chevron-down"></span>';
  $('.university').setAttribute('aria-label','Московский Политех — полезные ссылки');
  $('.avatar').setAttribute('aria-label','Открыть профиль '+official().fullName);
  $('[data-action="open-sidebar"]').setAttribute('aria-expanded','false');
  const sidebarClose=document.createElement('button');sidebarClose.className='sidebar-close icon-button';sidebarClose.dataset.action='close-sidebar';sidebarClose.setAttribute('aria-label','Закрыть меню');sidebarClose.innerHTML=icon('close');$('.sidebar').prepend(sidebarClose);
  Svod.renderIcons();
  document.querySelectorAll('.main-nav .nav-item').forEach(el=>{const label=$('.nav-label',el)?.textContent.trim() || el.textContent.trim();el.setAttribute('aria-label',label);el.title=label;});
  const mobileDock=$('.mobile-bottom-nav');
  let dockTimer;
  function expandDock(){
    clearTimeout(dockTimer);mobileDock.classList.add('dock-expanded');
    dockTimer=setTimeout(()=>{
      if(mobileDock.contains(document.activeElement)&&document.activeElement.matches(':focus-visible'))return;
      mobileDock.classList.remove('dock-expanded');
    },4000);
  }
  mobileDock.querySelectorAll('a').forEach(item=>item.setAttribute('aria-label',$('.mobile-nav-label',item).textContent));
  mobileDock.addEventListener('pointerdown',expandDock);
  mobileDock.addEventListener('focusin',expandDock);
  mobileDock.addEventListener('focusout',expandDock);
  document.addEventListener('visibilitychange',()=>{if(document.hidden){clearTimeout(dockTimer);mobileDock.classList.remove('dock-expanded');}});
  document.addEventListener('scroll',()=>{clearTimeout(dockTimer);mobileDock.classList.remove('dock-expanded');},{capture:true,passive:true});
  expandDock();
  Svod.resumeFields.install(document);
  Svod.forms.configure({scenario:()=>S.db().active});
  document.addEventListener('draftrestored',()=>{updateResumePreview();});
  document.querySelector('.skip-link').addEventListener('click',event=>{event.preventDefault();main.focus({preventScroll:false});});
  document.addEventListener('click',event=>{
    const anchor=event.target.closest('a[href^="#"]');
    if(!anchor||anchor.classList.contains('skip-link')||event.defaultPrevented||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
    event.preventDefault();if(anchor.dataset.scrollTarget){document.getElementById(anchor.dataset.scrollTarget)?.scrollIntoView({behavior:'smooth'});return;}go(anchor.getAttribute('href').slice(1));
  });
  router=Svod.createRouter({
    defaultRoute:'register',
    initialRoute:Svod.telegramLaunch?.initialRoute||null,
    isPage:path=>pageRoutes.has(path)||path.startsWith('assessment/')||path.startsWith('university/')||path.startsWith('company/'),
    fallback:path=>{const [kind,id]=path.split('/');return kind==='offer'?(findOffer(id)?.category || 'career'):kind==='company'?'companies':kind==='news'?'events':kind==='class'?'schedule':['edit-profile','help','university'].includes(kind)?'profile':kind==='preferences'?'career':'main';},
    beforeChange:()=>Svod.forms.flush(),
    onChange:async(path)=>{
      closeSidebar();
      const [kind,id]=path.split('/');
      const operation=kind==='offer'?'visitOffer':kind==='company'?'visitCompany':path==='messages'?'readChat':null;
      if(operation){try{await Svod.repository.command(operation,kind==='offer'?{offerId:id}:kind==='company'?{companyId:id}:{chatId:chatChannel});}catch(_){ /* Reading remains possible if optional visit tracking fails. */ }}
      if(router.current()===path)renderRoute();
    }
  });
  Svod.university.install({page,home,main,go,applyTheme,toast,download,syncChatViewport});
  Svod.company.install({page,home,main,go,applyTheme,toast,download,syncChatViewport});
  Svod.ui.installMediaFallback();restoreViewContext();applyTheme();renderDashboard();router.start();
})();
