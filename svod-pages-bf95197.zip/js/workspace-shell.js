/* Shared shell primitives for configured role workspaces; keeps student nodes intact. */
(function(){
 'use strict';
 const U=Svod.ui,$=q=>document.querySelector(q);
 function capture(){return {nav:$('.main-nav').innerHTML,bottom:$('.sidebar-bottom').innerHTML,university:$('.university').outerHTML,actions:$('.topbar-actions').innerHTML,dock:$('.mobile-bottom-nav').innerHTML,caption:$('.nav-caption').textContent,breadcrumb:$('.breadcrumb').innerHTML,collapsed:document.body.classList.contains('sidebar-collapsed')};}
 function restore(v){if(!v)return;$('.main-nav').innerHTML=v.nav;$('.sidebar-bottom').innerHTML=v.bottom;$('.university').outerHTML=v.university;$('.topbar-actions').innerHTML=v.actions;$('.mobile-bottom-nav').innerHTML=v.dock;$('.nav-caption').textContent=v.caption;$('.breadcrumb').innerHTML=v.breadcrumb;document.body.classList.toggle('sidebar-collapsed',v.collapsed);$('.brand').href='#main';$('.mobile-header-brand').href='#main';}
 function navigation(namespace,items,current){return items.map(([id,label,icon])=>U.link(Svod.icon(icon)+'<span class="nav-label">'+U.escape(label)+'</span>',namespace+'/'+id,'nav-item '+(current===id?'active':''),'').replace('<a ',`<a aria-label="${U.escape(label)}" ${current===id?'aria-current="page" ':''}`)).join('');}
 function dock(namespace,items,current){return items.map(([id,label,icon])=>`<a href="#${namespace}/${id}" class="mobile-nav-item ${current===id?'active':''}" aria-label="${U.escape(label)}" ${current===id?'aria-current="page"':''}><span>${Svod.icon(icon)}</span><span class="mobile-nav-label">${U.escape(label)}</span></a>`).join('');}
 function mountFilters(root,selector){
  const compact=matchMedia('(max-width:760px)').matches;
  for(const form of root.querySelectorAll(selector)){
   let bar=form.querySelector('.role-filter-actions,.u-filter-actions');const submit=form.querySelector('button[type="submit"]');if(!submit)continue;
   if(!bar){bar=document.createElement('div');bar.className='detail-actions role-filter-actions';form.append(bar);}else bar.classList.add('role-filter-actions');
   submit.textContent='Применить';bar.prepend(submit);
   const grid=form.querySelector('.c-filter-grid,.u-filter-grid');if(grid){form.append(bar);for(const row of grid.querySelectorAll('.detail-actions')){for(const child of [...row.children])bar.append(child);row.remove();}}
   bar.hidden=true;const initial=JSON.stringify([...new FormData(form)]),update=()=>bar.hidden=JSON.stringify([...new FormData(form)])===initial;
   form.addEventListener('input',update);form.addEventListener('change',update);
   if(!form.closest('details')){const details=document.createElement('details');details.className='card role-filter-disclosure';details.dataset.mobileFilters='';details.open=!compact;const summary=document.createElement('summary');summary.innerHTML=Svod.icon('sliders')+'<span>Фильтры</span>'+Svod.icon('chevron-down');form.before(details);details.append(summary,form);}
  }
 }
 let mediaBound=false;
 function bindResponsiveFilters(){if(mediaBound)return;mediaBound=true;matchMedia('(max-width:760px)').addEventListener('change',ev=>{for(const el of document.querySelectorAll('details[data-mobile-filters]'))el.open=!ev.matches;});}
 Svod.workspaceShell={capture,restore,navigation,dock,mountFilters,bindResponsiveFilters};
})();
