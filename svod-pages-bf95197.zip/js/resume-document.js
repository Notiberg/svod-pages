/* One document renderer for the student editor, submitted snapshots and demo PDF fixtures. */
(function(){
 'use strict';
 const e=Svod.ui.escape;
 function render({resume:r,personal={},interests=[],official,design,accent='#426b8b'}){const details=r.details||{},color={value:accent};
    return `<article class="resume-sheet resume-${design.template}" data-background="${design.background}" data-blocks="${design.blocks}" style="--resume-accent:${color.value}"><div class="resume-document-top"><p>РЕЗЮМЕ</p><h1>${e(official.fullName)}</h1><span>${e(details.position)||(interests.length?e(interests.join(' · ')):'Начинающий специалист')}</span></div><p class="resume-contact">${e([r.email,details.phone||personal.phone,details.telegram,details.city].filter(Boolean).join(' · '))}</p><section><h2>О себе</h2><p>${e(r.about || 'Добавь несколько предложений о своём опыте и целях.')}</p></section><section><h2>Образование</h2><p>${e(official.university)}<br>${e(official.program)} · ${official.year} курс</p></section><section><h2>Навыки</h2><p>${e(r.skills || 'Добавь свои навыки')}</p></section><section><h2>Проекты и опыт</h2><p>${e(r.project || 'Опиши учебный или личный проект.')}</p></section>${Svod.resumeFields.sections(details)}${details.portfolio||personal.portfolio?`<section><h2>Портфолио</h2><p>${e(details.portfolio||personal.portfolio)}</p></section>`:''}</article>`;
 }
 Svod.resumeDocument={render};
})();
