/* Telegram safe areas are layout hints only, never authentication. */
(function(){
 'use strict';
 const root=document.documentElement;
 const parameters=/(?:^|[?#&])tgWebApp(?:Platform|Data|Version|StartParam|ThemeParams)=/;
 const freshLaunch=parameters.test(location.hash)||parameters.test(location.search)||!!window.Telegram?.WebApp?.initData;
 let remembered=false;try{remembered=sessionStorage.getItem('svod.telegram.context')==='true';if(freshLaunch)sessionStorage.setItem('svod.telegram.context','true');}catch(_){}
 const launched=freshLaunch||remembered;
 if(!launched)return;
 window.Svod=window.Svod||{};Svod.telegramLaunch=Object.freeze({initialRoute:freshLaunch?'register':null});
 root.dataset.telegram='true';root.style.setProperty('--telegram-safe-top','var(--telegram-fallback-top)');
 function sync(){const app=window.Telegram?.WebApp;root.style.setProperty('--telegram-safe-bottom',(Math.max(0,Number(app?.safeAreaInset?.bottom)||0)+Math.max(0,Number(app?.contentSafeAreaInset?.bottom)||0))+'px');if(app?.viewportHeight)root.style.setProperty('--telegram-viewport-height',app.viewportHeight+'px');const top=Math.max(0,Number(app?.safeAreaInset?.top)||0)+Math.max(0,Number(app?.contentSafeAreaInset?.top)||0);root.style.setProperty('--telegram-safe-top',top?top+'px':'var(--telegram-fallback-top)');}
 function connect(){const app=window.Telegram?.WebApp;if(!app)return;sync();for(const event of ['safeAreaChanged','contentSafeAreaChanged','viewportChanged','fullscreenChanged'])app.onEvent?.(event,sync);}
 if(window.Telegram?.WebApp)connect();else{const script=document.createElement('script');script.src='https://telegram.org/js/telegram-web-app.js';script.onload=connect;document.head.append(script);}
})();
