(function () {
  'use strict';
  window.Svod = window.Svod || {};
  Svod.brandAssets = {
    yandex: {
      name: 'Яндекс',
      src: 'assets/brands/yandex.png',
      source: 'https://yandex.ru/company/rules/logotype/',
      assetSource: 'https://yastatic.net/s3/home-static/_/f0/f0597b6727cc67dceebc4e3a87caf571.png'
    },
    sber: {
      name: 'Сбер',
      src: 'assets/brands/sber.jpg',
      source: 'https://sber.pro/',
      assetSource: 'https://sber.pro/apple-touch-icon.png'
    },
    tbank: {
      name: 'Т-Банк',
      src: 'assets/brands/tbank.svg',
      wordmark: 'assets/brands/tbank-wordmark.svg',
      source: 'https://www.tbank.ru/about/brand/',
      assetSource: 'https://upload.wikimedia.org/wikipedia/commons/1/17/T-Bank_RU_logo.svg'
    },
    vk: {
      name: 'VK',
      src: 'assets/brands/vk.svg',
      source: 'https://vk.company/ru/press/identity/',
      assetSource: 'https://vk.company/data/VK-logo/'
    }
  };
})();
