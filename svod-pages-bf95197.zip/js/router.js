(function () {
  'use strict';
  // Hash routes also work when index.html is opened directly with file://.
  Svod.createRouter = function ({ isPage, fallback, onChange, beforeChange = () => {}, defaultRoute = 'main', initialRoute = null }) {
    let lastSignature = '', started = false, launchHash = null;
    const read = () => { if (launchHash !== null && location.hash === launchHash && history.state?.svodRoute?.launchEntry) return initialRoute; try { return decodeURIComponent(location.hash.slice(1)) || defaultRoute; } catch (_) { return 'not-found'; } };
    const state = () => history.state?.svodRoute;
    function notify(force = false) {
      const path = read(), signature = path + ':' + JSON.stringify(state());
      if (!force && signature === lastSignature) return;
      beforeChange(); lastSignature = signature;
      onChange(path, { parent: state()?.parent || fallback(path), modal: !isPage(path) });
    }
    function write(path, replace, parent, openedInApp) {
      beforeChange();
      const data = { svodRoute: { parent, openedInApp: !!openedInApp, modal: !isPage(path) } };
      history[replace ? 'replaceState' : 'pushState'](data, '', '#' + path);
      notify(true);
    }
    return {
      current: read,
      parent: () => state()?.parent || fallback(read()),
      go(path, { replace = false } = {}) {
        if (read() === path) return notify(true);
        const wasModal = !isPage(read());
        const parent = isPage(path) ? path : wasModal ? (state()?.parent || fallback(read())) : read();
        write(path, replace || wasModal, parent, !isPage(path) && (!wasModal || state()?.openedInApp));
      },
      close() {
        if (isPage(read())) return;
        beforeChange();
        if (state()?.openedInApp) history.back();
        else write(state()?.parent || fallback(read()), true, '', false);
      },
      start() {
        if (started) return; started = true;
        // Keep Telegram's launch fragment intact for the asynchronously loaded SDK.
        if (initialRoute) { launchHash = location.hash; history.replaceState({ svodRoute: { parent: initialRoute, openedInApp: false, modal: !isPage(initialRoute), launchEntry: true } }, '', location.href); }
        else if (!location.hash || location.hash === '#') history.replaceState({ svodRoute: { parent: defaultRoute, openedInApp: false, modal: !isPage(defaultRoute) } }, '', '#' + defaultRoute);
        if (!state()) history.replaceState({ svodRoute: { parent: isPage(read()) ? read() : fallback(read()), openedInApp: false, modal: !isPage(read()) } }, '', location.href);
        window.addEventListener('popstate', () => notify());
        window.addEventListener('hashchange', () => {
          if (!state() || state().modal !== !isPage(read())) history.replaceState({ svodRoute: { parent: isPage(read()) ? read() : fallback(read()), openedInApp: false, modal: !isPage(read()) } }, '', location.href);
          notify();
        });
        notify(true);
      }
    };
  };
})();
