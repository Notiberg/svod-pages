(function () {
  'use strict';
  /** @typedef {{id:string, firstName:string, fullName:string, university:string, program:string, year:number, group:string, readOnly:true}} OfficialStudent */
  /** @typedef {{id:string, offerId:string, status:'submitted'|'approved'|'rejected'|'withdrawn', submittedAt:string, resumeVersionId:?string, resumeSnapshot:Object, history:Array<{status:string,at:string,actor:string}>}} Application */
  /** @typedef {{id:string, offerId:string, companyId:string, studentId:string, startsAt:string, endsAt:string, timezone:string, status:'active'|'completed'|'cancelled', participants:Object, stages:Array<{id:string,title:string,owner:string,dueDate:string,status:string}>}} Practice */
  /** @typedef {{id:string,practiceId:string,version:number,name:string,size:number,status:'review'|'accepted'|'revision',comment:string,reviewerId:?string}} Report */
  /** @typedef {{id:string,eventId:string,status:'registered'|'cancelled',registeredAt:string,cancelledAt?:string}} Registration */
  /** @typedef {{id:string,chatId:string,senderId:string,text:string,time:string,status:'pending'|'sent'|'delivered'|'read'|'failed'|'local'}} Message */
  /** @typedef {{id:string,source:string,startsAt:string,endsAt:string,timezone:string,title:string,category:string}} CalendarEvent */
  const D=Svod.data, clone=x=>structuredClone(x);
  const offer=id=>D.recommendations.find(x=>x.id===id), dateKey=d=>Svod.dayKey(new Date(d)), iso=()=>new Date().toISOString();
  const addDays=(key,n)=>{const d=new Date(key+'T12:00:00');d.setDate(d.getDate()+n);return dateKey(d);};
  const stageOwners={intro:'student',plan:'university',project:'student',report:'university',review:'company'};
  function officialProfile(scenarioId=Svod.state.db().active){return clone(D.officialProfiles[scenarioId]);}
  function makePractice(item,scenarioId,completed=[]){
    const period=item.practicePeriod;
    const offsets={intro:2,plan:7,project:28,report:45,review:52};
    return {id:'practice-'+scenarioId+'-'+item.id,offerId:item.id,companyId:item.companyId,studentId:'student-'+scenarioId,
      startsAt:period.start+'T10:00:00+03:00',endsAt:period.end+'T18:00:00+03:00',timezone:period.timezone,status:'active',
      participants:{studentId:'student-'+scenarioId,curatorId:'university-curator',mentorId:'company-mentor'},
      stages:D.checklist.map(x=>({id:x.id,title:x.title,hint:x.hint,owner:stageOwners[x.id],dueDate:addDays(period.start,Math.min(offsets[x.id],Math.round((Date.parse(period.end)-Date.parse(period.start))/86400000))),status:completed.includes(x.id)?'confirmed':'pending'}))};
  }
  function normalize(state,scenarioId){
    state.companyVisits ||= [];state.applicationRecords ||= [];state.eventRegistrations ||= [];state.reports ||= [];state.commandReceipts ||= {};
    state.versions=state.versions.map((v,i)=>({...v,id:v.id||`resume-${scenarioId}-${i}`,createdAt:v.createdAt||'2026-11-16T00:00:00.000Z'}));
    for(const id of state.applications){if(!state.applicationRecords.some(a=>a.offerId===id&&a.status!=='withdrawn'))state.applicationRecords.push({id:'application-'+scenarioId+'-'+id,offerId:id,status:state.practiceId===id?'approved':'submitted',submittedAt:'2026-11-16T00:00:00.000Z',resumeVersionId:null,resumeSnapshot:{resume:clone(state.resume),design:clone(state.resumeDesign),official:officialProfile(scenarioId)},history:[{status:'submitted',at:'2026-11-16T00:00:00.000Z',actor:'legacy-demo'}]});}
    for(const id of state.registrations){if(!state.eventRegistrations.some(r=>r.eventId===id&&r.status==='registered'))state.eventRegistrations.push({id:'registration-'+scenarioId+'-'+id,eventId:id,status:'registered',registeredAt:'2026-11-16T00:00:00.000Z'});}
    const item=offer(state.practiceId);
    if(item&&(!state.practice||state.practice.offerId!==item.id))state.practice=makePractice(item,scenarioId,state.checklist);
    if(state.practice&&state.practiceComplete){state.practice.status='completed';}
    if(state.report&&!state.reports.length&&state.practice)state.reports.push({...clone(state.report),id:'report-'+state.practice.id+'-1',practiceId:state.practice.id,version:1,submittedAt:'2026-11-16T00:00:00.000Z',comment:state.report.comment||'',reviewerId:state.report.status==='review'?null:'university-curator'});
    if(state.practiceComplete&&state.practice&&!state.reports.length){state.reports.push({id:'report-'+state.practice.id+'-legacy',practiceId:state.practice.id,version:1,name:'Демонстрационный итоговый отчёт.pdf',size:0,status:'accepted',submittedAt:'2026-11-16T00:00:00.000Z',comment:'Историческое состояние демонстрационного сценария.',reviewerId:'university-curator'});}
    state.messages=state.messages.map((m,i)=>({...m,id:m.id||`message-${scenarioId}-${i}`,chatId:m.chatId||m.channel||'curator',channel:m.channel||m.chatId||'curator',senderId:m.senderId||(m.from==='student'?'student-'+scenarioId:'local-assistant'),status:m.status||'sent',createdAt:m.createdAt||m.time}));
    Svod.multirole?.enrich(state,'student-'+scenarioId);
    project(state);return state;
  }
  function latestReport(state){return state.reports.filter(r=>r.practiceId===state.practice?.id).sort((a,b)=>b.version-a.version)[0]||null;}
  function project(state){
    Svod.multirole?.enrich(state);
    if(state.applicationRecords?.length)state.applications=[...new Set(state.applicationRecords.filter(a=>a.status!=='withdrawn'&&a.status!=='rejected').map(a=>a.offerId))];
    if(state.eventRegistrations?.length)state.registrations=[...new Set(state.eventRegistrations.filter(r=>r.status==='registered').map(r=>r.eventId))];
    if(state.practice){state.practiceId=state.practice.status==='cancelled'?'':state.practice.offerId;state.practiceComplete=state.practice.status==='completed';state.checklist=state.practice.stages.filter(x=>['done','confirmed'].includes(x.status)).map(x=>x.id);}
    state.report=latestReport(state);return state;
  }
  function progress(state){
    if(!state.practice)return {percent:0,completed:0,total:D.checklist.length,canComplete:false};
    const report=latestReport(state);
    const count=state.practice.stages.filter(x=>['done','confirmed'].includes(x.status)&& (x.id!=='report'||report?.status==='accepted')).length;
    return {percent:Math.round(count/state.practice.stages.length*100),completed:count,total:state.practice.stages.length,canComplete:count===state.practice.stages.length&&report?.status==='accepted'};
  }
  function score(state,item){
    const weights=state.weights,total=weights.interests+weights.skills+weights.format;if(!total)return 50;
    const skills=state.resume.skills.toLowerCase(),fit=item.skills.length?item.skills.filter(k=>skills.includes(k.toLowerCase())||k==='HTML / CSS'&&/html|css/.test(skills)).length/item.skills.length:.7;
    const interest=state.interests.includes(item.direction)||item.direction==='Карьера'?1:.25,format=state.preferences.format==='Любой'||state.preferences.format===item.format?1:.25;
    return Math.min(99,Math.round(40+58*(interest*weights.interests+fit*weights.skills+format*weights.format)/total));
  }
  function recommendedOffers(state,category,filters={}){
    const q=(filters.query||'').trim().toLowerCase();
    return D.recommendations.filter(x=>x.category===category&&(!x.publication||x.publication==='published')&&!state.hidden.includes(x.id)&&!state.excluded.includes(x.direction)&&(!filters.direction||x.direction===filters.direction)&&(!filters.format||x.format===filters.format)&&(!q||[x.title,x.company,x.direction,...x.skills].join(' ').toLowerCase().includes(q))).sort((a,b)=>filters.sort==='title'?a.title.localeCompare(b.title,'ru'):score(state,b)-score(state,a));
  }
  function nextStep(state,scenarioId){
    const focus=state.focus;
    if(focus==='resume')return {title:'Обнови резюме',hero:'Расскажи о своих<br>навыках и проектах.',description:'Ты выбрал резюме главным акцентом. Добавь актуальный опыт и сохрани версию.',cta:'Открыть резюме',action:'resume',deadline:'Твой выбранный акцент'};
    if(focus==='career'||focus==='explore'){const configured=D.scenarios[focus==='career'?'graduate':'freshman'];return {...configured,title:configured.cta,action:focus==='explore'?'career':'jobs',deadline:'Твой выбранный акцент'};}
    const report=latestReport(state);
    if(state.practice?.status==='completed'||state.practiceComplete)return {title:'Практика завершена',hero:'Практика завершена.<br>Сохрани свой результат.',description:'Добавь результат проекта в резюме и выбери следующий карьерный шаг.',cta:'Обновить резюме',action:'resume',deadline:'Твой опыт готов к следующему шагу'};
    if(state.practiceId)return report?.status==='revision'?{title:'Доработай отчёт',hero:'Есть обратная связь.<br>Улучши свой отчёт.',description:report.comment||'Открой замечания, обнови файл и передай новую версию на проверку.',cta:'Открыть замечания',action:'practice',deadline:'Отчёт ожидает доработки'}:{title:'Продолжить практику',hero:'Практика в процессе.<br>Твой следующий этап.',description:'План, сроки и обратная связь собраны в кабинете практики.',cta:'Открыть практику',action:'practice',deadline:'Следуй согласованному плану'};
    if(state.applicationRecords?.some(a=>a.status==='submitted')||state.applications.length)return {title:'Проверь заявки',hero:'Первый шаг сделан.<br>Следи за заявками.',description:'Заявка сохранена. Следующий шаг — решение вуза или компании.',cta:'Мои заявки',action:'applications',deadline:'Ожидается решение · учебный режим'};
    const scenario=D.scenarios[scenarioId]||D.scenarios.junior;return {...scenario,title:scenario.cta};
  }
  function notices(state){
    const items=D.notices.filter(n=>(n.id!=='practice-deadline'||!state.practiceId&&!state.applications.length)&&(n.id!=='resume-tip'||!taskCompleted(state,'resume')));
    if(state.practiceId){const report=latestReport(state);items.unshift({id:'practice-'+state.practice.id+'-'+(report?.status||state.practice.status),title:state.practiceComplete?'Практика завершена':report?.status==='revision'?'Отчёт на доработке':report?.status==='review'?'Отчёт проверяется':'Твой план практики',text:report?.comment||'Сроки и следующий шаг — в кабинете практики',time:'Актуально',action:'practice',color:report?.status==='revision'?'amber':'blue',icon:'briefcase'});}
    return items.map(n=>({...n,type:n.id.startsWith('practice')?'practice':n.id==='resume-tip'?'resume':'system',createdAt:n.createdAt||'2026-11-16T12:00:00.000Z',read:state.read.includes(n.id),readAt:state.notificationReadAt?.[n.id]||null,sourceId:n.id.startsWith('practice')?state.practice?.id||null:n.id}));
  }
  function eventState(state,event,at=new Date()){
    const registered=state.registrations.includes(event.id),past=Date.parse(event.endsAt)<at.getTime(),closed=event.status==='closed'||Date.parse(event.registrationClosesAt)<=at.getTime();
    const seats=Math.max(0,event.capacity-event.occupied-(registered?1:0));return {registered,past,closed,seats,canRegister:!registered&&!past&&!closed&&seats>0,label:registered?'Записан':past?'Завершено':closed?'Запись закрыта':seats===0?'Мест нет':'Запись открыта'};
  }
  function calendarEvents(state,key,period='semester'){
    const combined=period===null;period=period||'semester';
    const weekday=new Date(key+'T12:00:00').getDay(),items=[];
    const event=(item,source,category,kind)=>({...item,id:item.id,calendarId:source+':'+key+':'+item.id,date:key,source,category,kind,timezone:'Europe/Moscow',startsAt:key+'T'+(item.time==='—'?'12:00':item.time)+':00+03:00',endsAt:key+'T'+(item.end||'12:30')+':00+03:00'});
    if(period==='semester'&&key>=D.semester.start&&key<=D.semester.end&&weekday>0&&weekday<6)items.push(...D.schedule.map(x=>event(x,'demo-university','study',x.kind)));
    if(period==='session')items.push(...D.exams.filter(x=>x.date===key).map(x=>event({...x,description:'Учебный пример экзаменационного расписания.'},'demo-university','study','Экзамен')));
    const p=state.practice,place=offer(p?.offerId);
    if(p&&p.status!=='cancelled'&&(period==='practice'||combined)){
      if(key>=p.startsAt.slice(0,10)&&key<=p.endsAt.slice(0,10)&&[1,3,5].includes(weekday))items.push(event({id:'practice-shift',time:'10:00',end:'14:00',title:place.title,location:place.format==='Удалённо'?'Удалённо':place.company,description:'Демонстрационный график практики, а не официальное расписание компании.'},'practice','practice','Практика'));
      for(const meeting of p.meetings||[])if(meeting.startsAt.slice(0,10)===key)items.push(event({id:meeting.id,time:meeting.startsAt.slice(11,16),end:meeting.endsAt.slice(11,16),title:meeting.title,location:'Встреча по практике',description:'Демонстрационная встреча'},'practice-meeting','practice','Встреча'));
      items.push(...p.stages.filter(x=>x.dueDate===key).map(x=>event({id:'stage-'+x.id,time:'17:00',end:'18:00',title:x.title,location:'Этап практики',description:x.hint,stageId:x.id},'practice-stage','practice','Срок этапа')));
    }
    if(period==='practice'||combined)for(const a of state.applicationRecords||[])if(a.status!=='withdrawn')for(const m of a.meetings||[])if(m.startsAt.slice(0,10)===key)items.push(event({id:m.id,time:m.startsAt.slice(11,16),end:new Date(m.endsAt).toLocaleTimeString('ru-RU',{timeZone:'Europe/Moscow',hour:'2-digit',minute:'2-digit'}),title:m.title,location:m.location,description:'Встреча с компанией · локальная демонстрация'},'application-meeting','practice','Встреча'));
    if(period==='semester')items.push(...D.recommendations.filter(x=>x.category==='events'&&x.date===key&&state.registrations.includes(x.id)).map(x=>event({...x,location:x.city,offer:true,end:new Date(x.endsAt).toLocaleTimeString('ru-RU',{timeZone:'Europe/Moscow',hour:'2-digit',minute:'2-digit'})},'event-registration','career',x.type)));
    items.push(...state.tasks.filter(x=>x.date===key&&!state.done.includes(x.id)).map(x=>event({...x,time:'—',end:'',location:'Личная задача',personal:true},'personal','personal','Задача')));
    return items.sort((a,b)=>a.time.localeCompare(b.time));
  }
  const derivedTaskIds=new Set(['resume','practice','event','orientation','practice-plan','practice-report','first-job','first-company']);
  function taskCompleted(state,id){
    if(id==='resume')return ['about','skills','project','email'].every(k=>state.resume[k].trim());
    if(id==='practice')return !!state.practiceId;
    if(id==='event')return state.registrations.length>0;
    if(id==='orientation')return state.onboarded;
    if(id==='first-company')return (state.companyVisits?.length||0)>0;
    if(id==='practice-plan')return state.practice?.stages.find(x=>x.id==='plan')?.status==='confirmed';
    if(id==='practice-report')return latestReport(state)?.status==='accepted';
    if(id==='first-job')return state.applicationRecords?.some(x=>['submitted','approved'].includes(x.status)&&offer(x.offerId)?.category==='jobs');
    return state.done.includes(id);
  }
  function xp(state){const validTasks=new Set([...D.tasks.map(x=>x.id),...state.tasks.map(x=>x.id),'orientation','first-company','practice-plan','practice-report','first-job','interview']);return [...validTasks].filter(id=>taskCompleted(state,id)).length*50+state.registrations.length*30+(state.practice?progress(state).completed:state.checklist.length)*40;}
  function unreadMessages(state,chatId='curator'){const last=state.notificationReadAt?.['chat-'+chatId];const incoming=state.messages.filter(m=>(m.chatId||m.channel)===chatId&&m.from!=='student'&&m.senderId!=='local-assistant'&&last&&Date.parse(m.time)>Date.parse(last)).length;return incoming||(!state.read.includes('chat-'+chatId)?2:0);}
  Svod.domain={unreadMessages,officialProfile,makePractice,normalize,project,latestReport,progress,score,recommendedOffers,nextStep,notices,eventState,calendarEvents,xp,findOffer:offer,taskCompleted,isDerivedTask:id=>derivedTaskIds.has(id)};
})();
