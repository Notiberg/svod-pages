(function () {
  'use strict';
  const KEY = 'svod.dashboard.v1';
  const defaults = (scenario = 'junior') => ({ done: [], favorites: [], hidden: [], applications: [], registrations: [], read: [], tasks: [], resume: { about: '', skills: 'Figma, HTML, CSS', project: '', email: 'alex.student@example.com' }, focus: '', widgets: ['recommendations', 'news', 'progress', 'companies'], hiddenWidgets: [], interests: ['Дизайн', 'Разработка'], weights: { interests: 80, skills: 70, format: 60 }, excluded: [], messages: [], visits: [], checklist: scenario === 'graduate' ? ['intro', 'plan', 'project', 'report', 'review'] : scenario === 'senior' ? ['intro', 'plan'] : [], filters: { recommendation: scenario === 'graduate' ? 'jobs' : scenario === 'freshman' ? 'events' : 'internships' }, compare: [], subscriptions: [], practiceId: ['senior', 'graduate'].includes(scenario) ? 'sber-frontend' : '', practiceComplete: scenario === 'graduate', report: null, versions: [], personal: { phone: '', portfolio: '' }, preferences: { format: 'Любой', notifications: true }, onboarded: false, resumeDesign: { template: 'minimal', color: 'blue', background: 'paper', blocks: 'plain' }, calendarPeriod: 'semester', assessmentAttempts: {} });
  const isDesign = d => d && ['minimal', 'modern', 'glass'].includes(d.template) && ['blue', 'sage', 'violet', 'graphite', 'terracotta'].includes(d.color) && ['paper', 'warm', 'mesh', 'blueprint', 'midnight'].includes(d.background) && ['plain', 'cards', 'rail'].includes(d.blocks);
  function migrateDesign(design) {
    if (!design || typeof design !== 'object' || Array.isArray(design)) return design;
    const template = design.template === 'brutalist' ? 'glass' : design.template;
    const preset = template === 'glass' ? { background: 'mesh', blocks: 'cards' } : template === 'modern' ? { background: 'blueprint', blocks: 'rail' } : { background: 'paper', blocks: 'plain' };
    return { ...preset, ...design, template };
  }
  function migrateState(state) {
    return { ...state, resumeDesign: migrateDesign(state.resumeDesign), versions: Array.isArray(state.versions) ? state.versions.map(v => v && v.design ? { ...v, design: migrateDesign(v.design) } : v) : state.versions };
  }
  const stringArray = (a, limit = 500) => Array.isArray(a) && a.length <= limit && a.every(v => typeof v === 'string' && v.length < 500) && new Set(a).size === a.length;
  const validDate = value => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(new Date(value + 'T12:00:00').getTime()) && Svod.dayKey(new Date(value + 'T12:00:00')) === value;
  function validate(s) {
    if (!s || typeof s !== 'object' || Array.isArray(s)) return false;
    for (const key of ['done', 'favorites', 'hidden', 'applications', 'registrations', 'read', 'widgets', 'hiddenWidgets', 'interests', 'excluded', 'checklist', 'visits', 'compare', 'subscriptions']) if (!stringArray(s[key])) return false;
    if (s.compare.length > 3 || typeof s.practiceId !== 'string' || typeof s.practiceComplete !== 'boolean' || typeof s.onboarded !== 'boolean') return false;
    if (!s.personal || !['phone', 'portfolio'].every(k => typeof s.personal[k] === 'string' && s.personal[k].length <= 500)) return false;
    if (!s.preferences || !['Любой', 'Гибрид', 'Удалённо', 'Очно', 'Онлайн'].includes(s.preferences.format) || typeof s.preferences.notifications !== 'boolean') return false;
    if (!isDesign(s.resumeDesign) || !['semester', 'session', 'practice'].includes(s.calendarPeriod)) return false;
    if (!s.assessmentAttempts || typeof s.assessmentAttempts !== 'object' || Array.isArray(s.assessmentAttempts) || Object.keys(s.assessmentAttempts).length > 500) return false;
    for (const [id, attempt] of Object.entries(s.assessmentAttempts)) {
      if (!Svod.data.recommendations.some(x=>x.id===id&&x.category==='internships') || !attempt || typeof attempt !== 'object' || !attempt.answers || typeof attempt.answers !== 'object' || Array.isArray(attempt.answers) || Object.keys(attempt.answers).length > 50 || !(attempt.submittedAt === null || typeof attempt.submittedAt === 'string' && !Number.isNaN(Date.parse(attempt.submittedAt)))) return false;
      if (!Object.entries(attempt.answers).every(([key, value]) => /^[\w-]{1,80}$/.test(key) && typeof value === 'string' && value.length <= 120)) return false;
      const test = attempt.testSnapshot || Svod.assessments?.get(id);
      if (test) {
        if (!Object.entries(attempt.answers).every(([key, value]) => { const q = test.questions.find(q => q.id === key); return q && (q.type === 'word' || value === '' || /^\d$/.test(value) && Number(value) < q.options.length); })) return false;
        if (attempt.submittedAt && test.questions.some(q => !String(attempt.answers[q.id] || '').trim() || q.type === 'word' && /\s/.test(Svod.assessments.normalize(attempt.answers[q.id])))) return false;
      }
    }
    if (s.report !== null && (!s.report || typeof s.report.name !== 'string' || s.report.name.length > 255 || !Number.isFinite(s.report.size) || s.report.size < 0 || !['review', 'accepted', 'revision'].includes(s.report.status))) return false;
    if (!Array.isArray(s.versions) || s.versions.length > 10 || !s.versions.every(v => v && typeof v.name === 'string' && v.name.length <= 80 && v.resume && Svod.resumeFields.valid(v.resume.details) && ['about', 'skills', 'project', 'email'].every(k => typeof v.resume[k] === 'string' && v.resume[k].length <= 5000) && (v.design === undefined || isDesign(v.design)))) return false;
    if (!Array.isArray(s.tasks) || s.tasks.length > 200 || !s.tasks.every(t => t && typeof t.id === 'string' && /^task-[\w-]{1,100}$/.test(t.id) && typeof t.title === 'string' && t.title.trim().length > 0 && t.title.length <= 120 && validDate(t.date)) || new Set(s.tasks.map(t => t.id)).size !== s.tasks.length) return false;
    if (!s.resume || !Svod.resumeFields.valid(s.resume.details) || !['about', 'skills', 'project', 'email'].every(k => typeof s.resume[k] === 'string' && s.resume[k].length <= 5000)) return false;
    if (!s.filters || !['internships', 'jobs', 'events'].includes(s.filters.recommendation)) return false;
    if (!s.weights || !['interests', 'skills', 'format'].every(k => Number.isFinite(s.weights[k]) && s.weights[k] >= 0 && s.weights[k] <= 100)) return false;
    if (typeof s.focus !== 'string' || !['', 'explore', 'practice', 'career', 'resume'].includes(s.focus) || !Array.isArray(s.messages) || s.messages.length > 200 || !s.messages.every(m => m && typeof m.text === 'string' && m.text.trim().length > 0 && m.text.length <= 2000 && typeof m.time === 'string' && !Number.isNaN(Date.parse(m.time)) && ['student', 'curator', 'assistant'].includes(m.from))) return false;
    if (!s.widgets.every(id => Svod.data.widgets.some(w => w.id === id)) || !s.hiddenWidgets.every(id => Svod.data.widgets.some(w => w.id === id))) return false;
    return true;
  }
  const SCHEMA = 3, JOURNAL = 'svod.operation.v3.';
  const clone = value => value === undefined ? undefined : structuredClone(value);
  const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
  const now = () => new Date().toISOString();
  const uid = () => (globalThis.crypto?.randomUUID?.() || Date.now().toString(36) + '-' + Math.random().toString(36).slice(2));
  const SETS = new Set(['done','favorites','hidden','applications','registrations','read','hiddenWidgets','interests','excluded','checklist','visits','compare','subscriptions']);
  const ENTITIES = new Set(['tasks','versions','messages','applicationRecords','eventRegistrations','reports']);
  let persistent = true, error = null, db, baseline, origin, commits = [], repairWarnings = [], recoveryRaw=null, recoveryRecorded=false;
  const listeners = new Set();
  function extendedDefaults(id) {
    return { ...defaults(id), schemaVersion:3, companyVisits:[], notificationReadAt:{}, drafts: {}, catalogFilters: { internships: {}, jobs: {}, events: {} }, calendarView: {}, applicationRecords: [], eventRegistrations: [], practice: null, reports: [], commandReceipts: {}, session: { status: 'active', mode: 'demo', roles: ['student'] } };
  }
  function validEntityArray(value) { return Array.isArray(value) && value.length <= 500 && value.every(x => x && typeof x === 'object' && typeof x.id === 'string' && x.id.length < 180) && new Set(value.map(x=>x.id)).size === value.length; }
  function validateModels(state) {
    const offers=new Set(Svod.data.recommendations.filter(x=>x.category!=='events').map(x=>x.id));
    const events=new Set(Svod.data.recommendations.filter(x=>x.category==='events').map(x=>x.id));
    const stamp=x=>typeof x==='string'&&!Number.isNaN(Date.parse(x));
    const applications=validEntityArray(state.applicationRecords)&&state.applicationRecords.every(x=>offers.has(x.offerId)&&['submitted','approved','rejected','withdrawn'].includes(x.status)&&stamp(x.submittedAt)&&x.resumeSnapshot&&x.resumeSnapshot.resume&&Svod.resumeFields.valid(x.resumeSnapshot.resume.details)&&['about','skills','project','email'].every(k=>typeof x.resumeSnapshot.resume[k]==='string'&&x.resumeSnapshot.resume[k].length<=5000)&&isDesign(x.resumeSnapshot.design)&&x.resumeSnapshot.official&&typeof x.resumeSnapshot.official.fullName==='string'&&Array.isArray(x.history)&&x.history.every(h=>['submitted','approved','rejected','withdrawn'].includes(h.status)&&stamp(h.at)));
    const registrations=validEntityArray(state.eventRegistrations)&&state.eventRegistrations.every(x=>events.has(x.eventId)&&['registered','cancelled'].includes(x.status)&&stamp(x.registeredAt));
    const practice=state.practice===null||state.practice&&typeof state.practice.id==='string'&&Svod.data.recommendations.some(x=>x.id===state.practice.offerId&&x.category==='internships')&&['active','completed','cancelled'].includes(state.practice.status)&&stamp(state.practice.startsAt)&&stamp(state.practice.endsAt)&&Date.parse(state.practice.startsAt)<Date.parse(state.practice.endsAt)&&state.practice.timezone==='Europe/Moscow'&&state.practice.participants&&['studentId','curatorId','mentorId'].every(k=>typeof state.practice.participants[k]==='string')&&Array.isArray(state.practice.stages)&&state.practice.stages.length===5&&state.practice.stages.every(x=>x&&typeof x==='object')&&new Set(state.practice.stages.map(x=>x.id)).size===5&&state.practice.stages.every(x=>Svod.data.checklist.some(c=>c.id===x.id)&&['pending','done','confirmed'].includes(x.status)&&({intro:'student',plan:'university',project:'student',report:'university',review:'company'})[x.id]===x.owner&&typeof x.title==='string'&&typeof x.hint==='string'&&validDate(x.dueDate));
    const reports=validEntityArray(state.reports)&&state.reports.every(x=>typeof x.practiceId==='string'&&[state.practice?.id,...(Array.isArray(state.practiceHistory)?state.practiceHistory.map(p=>p?.id):[])].includes(x.practiceId)&&Number.isInteger(x.version)&&x.version>0&&['review','accepted','revision'].includes(x.status)&&typeof x.name==='string'&&x.name.length<256&&Number.isFinite(x.size)&&x.size>=0&&x.size<=10485760&&typeof x.comment==='string'&&x.comment.length<=2000&&!Object.hasOwn(x,'data')&&!Object.hasOwn(x,'content'));
    return !!(applications&&registrations&&practice&&reports);
  }
  function migrate1to2(value){return migrateState(value);}
  function migrate2to3(value){return {...value,schemaVersion:3,applicationRecords:value.applicationRecords||[],eventRegistrations:value.eventRegistrations||[],practice:value.practice||null,reports:value.reports||[]};}
  function migrateSchemas(source){
    let value=source||{},version=Number.isInteger(value.schemaVersion)?value.schemaVersion:1;
    while(version<SCHEMA){value=version===1?migrate1to2(value):migrate2to3(value);version++;}
    return value;
  }
  function sanitize(source, id, strict = false) {
    const base = extendedDefaults(id), input = migrateState({ ...base, ...migrateSchemas(source) });
    // Legacy schema 1 -> 2: IDs. Schema 2 -> 3: isolated UI state and explicit domain models.
    input.tasks = Array.isArray(input.tasks) ? input.tasks.map(t => ({ ...t, completed: input.done?.includes(t.id) || t.completed === true })) : input.tasks;
    input.versions = Array.isArray(input.versions) ? input.versions.map((v,i) => ({ ...v, id: v.id || `resume-${id}-${i}`, createdAt: v.createdAt || '2026-11-16T00:00:00.000Z' })) : input.versions;
    input.messages = Array.isArray(input.messages) ? input.messages.map((m,i) => ({ ...m, id: m.id || `message-${id}-${i}`, chatId: m.chatId || m.channel || 'curator', senderId: m.senderId || (m.from === 'student' ? `student-${id}` : 'local-assistant'), status: m.status || 'sent' })) : input.messages;
    if (!strict && input.resume?.details !== undefined && !Svod.resumeFields.valid(input.resume.details)) {
      const details=input.resume.details, repaired={};
      if(details && typeof details==='object' && !Array.isArray(details)) for(const [key,value] of Object.entries(details)) {
        if(Svod.resumeFields.valid({[key]:value})) repaired[key]=value;
        else if(Array.isArray(value)) { const rows=value.slice(0,5).filter(row=>Svod.resumeFields.valid({[key]:[row]})); if(Svod.resumeFields.valid({[key]:rows}))repaired[key]=rows; }
      }
      input.resume={...input.resume,details:repaired};repairWarnings.push(id+'.resume.details');
    }
    if (strict && (!validate(input)||!validateModels(input))) throw new Error('Файл содержит некорректные данные или связи СВОД.');
    if (!validate(input)) {
      // Repair independently; retain every valid field, including text in unrelated forms.
      for (const key of Object.keys(defaults(id))) {
        const trial = { ...defaults(id), [key]: input[key] };
        if (key === 'tasks') trial.done = Array.isArray(input.done) ? input.done : [];
        if (!validate(trial)) { input[key] = clone(base[key]); repairWarnings.push(`${id}.${key}`); }
      }
      if (!validate(input)) return { ...base, resume: input.resume && typeof input.resume.about === 'string' ? { ...base.resume, ...input.resume } : base.resume };
    }
    const offerIds = new Set(Svod.data.recommendations.map(x=>x.id));
    const eventIds = new Set(Svod.data.recommendations.filter(x=>x.category==='events').map(x=>x.id));
    const knownFavorite = key => offerIds.has(key) || key.startsWith('company-') && Svod.data.companies.some(x=>x.id===key.slice(8));
    if (persistent) input.favorites = input.favorites.filter(knownFavorite);
    for (const key of ['hidden','visits','compare']) input[key] = input[key].filter(x=>offerIds.has(x));
    input.applications = input.applications.filter(x=>offerIds.has(x) && !eventIds.has(x));
    input.registrations = input.registrations.filter(x=>eventIds.has(x));
    if (input.practiceId && !Svod.data.recommendations.some(x=>x.id===input.practiceId && x.category==='internships')) { input.practiceId=''; input.practice=null; input.practiceComplete=false; }
    input.checklist = input.checklist.filter(x=>Svod.data.checklist.some(c=>c.id===x));
    for (const key of ['drafts','catalogFilters','calendarView','commandReceipts']) if (!input[key] || typeof input[key] !== 'object' || Array.isArray(input[key])) input[key]=clone(base[key]);
    for (const key of ['applicationRecords','eventRegistrations','reports']) {
      if(!Array.isArray(input[key])){input[key]=[];repairWarnings.push(id+'.'+key);continue;}
      const ids=new Set();input[key]=input[key].filter(x=>{const ok=x&&typeof x.id==='string'&&!ids.has(x.id);if(ok)ids.add(x.id);else repairWarnings.push(id+'.'+key);return ok;}).slice(0,500);
    }
    input.applicationRecords=input.applicationRecords.filter(x=>offerIds.has(x.offerId) && ['submitted','approved','rejected','withdrawn'].includes(x.status));
    input.eventRegistrations=input.eventRegistrations.filter(x=>eventIds.has(x.eventId) && ['registered','cancelled'].includes(x.status));
    input.reports=input.reports.filter(x=>['review','accepted','revision'].includes(x.status) && typeof x.practiceId==='string');
    if (!input.session || !['active','expired','denied','signed-out'].includes(input.session.status)) input.session=clone(base.session);
    if (!validateModels(input)) {
      if(strict)throw new Error('Некорректные связи или состояния моделей СВОД.');
      const practiceTrial={...base,practice:input.practice};
      if(!validateModels(practiceTrial)){repairWarnings.push(id+'.practice');input.practice=null;input.practiceId='';input.practiceComplete=false;}
      for(const key of ['applicationRecords','eventRegistrations','reports']){
        input[key]=input[key].filter(value=>{const trial={...base,practice:input.practice,practiceHistory:input.practiceHistory,[key]:[value]};const ok=validateModels(trial);if(!ok)repairWarnings.push(id+'.'+key+'.'+value.id);return ok;});
      }
    }
    return input;
  }
  function fresh() { return { version: SCHEMA, active:'junior', collapsed:false, theme:'light', scenarios:Object.fromEntries(Object.keys(Svod.data.scenarios).map(id=>[id,extendedDefaults(id)])) }; }
  function cleanDB(raw) {
    const result=fresh();
    Svod.companyData?.syncCatalog(raw);
    if (!raw || typeof raw !== 'object') return result;
    if (Object.hasOwn(Svod.data.scenarios,raw.active)) result.active=raw.active;
    if (Svod.multirole) result.multirole=raw.multirole&&raw.multirole.schemaVersion===1?clone(raw.multirole):null;
    result.collapsed=raw.collapsed===true;
    if (['light','dark','system'].includes(raw.theme)) result.theme=raw.theme;
    for (const id of Object.keys(result.scenarios)) if (raw.scenarios?.[id]) result.scenarios[id]=sanitize(raw.scenarios[id],id);
    return result;
  }
  function pathGet(object,path) { return path.reduce((v,k)=>k.startsWith('@') ? Array.isArray(v)?v.find(x=>x.id===k.slice(1)):undefined : v?.[k],object); }
  function pathSet(object,path,value) {
    let target=object;
    for (let i=0;i<path.length-1;i++) {
      const key=path[i];
      if (key.startsWith('@')) target=Array.isArray(target)?target.find(x=>x.id===key.slice(1)):undefined;
      else { if (!target[key] || typeof target[key]!=='object') target[key]={}; target=target[key]; }
      if (!target) return;
    }
    const key=path.at(-1);
    if (key.startsWith('@')) { if(!Array.isArray(target))return;const index=target.findIndex(x=>x.id===key.slice(1)); if(value===undefined){if(index>=0)target.splice(index,1);}else if(index<0)target.push(clone(value));else target[index]=clone(value); }
    else if (value===undefined) delete target[key]; else target[key]=clone(value);
  }
  function diff(before,after,path=[],out=[]) {
    if(same(before,after))return out;
    const field=path.at(-1);
    if(Array.isArray(before)&&Array.isArray(after)&&SETS.has(field)) {
      for(const item of new Set([...before,...after]))if(before.includes(item)!==after.includes(item))out.push({path,kind:'member',member:item,before:before.includes(item),value:after.includes(item)});
    } else if(Array.isArray(before)&&Array.isArray(after)&&ENTITIES.has(field)&&[...before,...after].every(x=>x?.id)) {
      for(const id of new Set([...before,...after].map(x=>x.id)))if(!same(before.find(x=>x.id===id),after.find(x=>x.id===id)))out.push({path:[...path,'@'+id],before:clone(before.find(x=>x.id===id)),value:clone(after.find(x=>x.id===id))});
    } else if(before&&after&&typeof before==='object'&&typeof after==='object'&&!Array.isArray(before)&&!Array.isArray(after)) {
      for(const key of new Set([...Object.keys(before),...Object.keys(after)]))if(!['__proto__','prototype','constructor','conflicts','revision'].includes(key))diff(before[key],after[key],[...path,key],out);
    } else out.push({path,before:clone(before),value:clone(after)});
    return out;
  }
  function currentValue(database,change) { const value=pathGet(database,change.path);return change.kind==='member' ? Array.isArray(value)&&value.includes(change.member) : value; }
  function apply(database,change) {
    if(change.kind==='member') { const values=pathGet(database,change.path);if(!Array.isArray(values))return; const index=values.indexOf(change.member); if(change.value&&index<0)values.push(change.member);else if(!change.value&&index>=0)values.splice(index,1); }
    else pathSet(database,change.path,change.value);
  }
  function materialize(seed,log) {
    const result=clone(seed), conflicts=[];
    for(const commit of [...log].sort((a,b)=>(a.order||0)-(b.order||0)||a.at.localeCompare(b.at)||a.id.localeCompare(b.id))) {
      if(!Array.isArray(commit.changes))continue;
      const collisions=commit.changes.filter(change=>!same(currentValue(result,change),change.before)&&!same(currentValue(result,change),change.value));
      if(collisions.length) { conflicts.push({id:commit.id,at:commit.at,paths:collisions.map(x=>x.path.join('.')),changes:clone(commit.changes)});continue; }
      for(const change of commit.changes)apply(result,change);
    }
    Svod.companyData?.syncCatalog(result);
    const safe=Object.values(result.scenarios).every(s=>validate(s)&&validateModels(s))?result:cleanDB(result);
    safe.conflicts=conflicts.filter(c=>!Object.values(result.scenarios).some(s=>s.commandReceipts?.['conflict-'+c.id])).map(c=>({...c,changes:c.changes.map(change=>({...change,actualCurrent:clone(currentValue(safe,change))}))})); safe.revision=log.length;
    return safe;
  }
  function validCommit(value) {
    return value&&typeof value.id==='string'&&typeof value.at==='string'&&Array.isArray(value.changes)&&value.changes.length<=5000&&value.changes.every(x=>x&&Array.isArray(x.path)&&x.path.length>0&&x.path.length<15&&((x.path[0]==='scenarios'&&x.path.length>=3&&Object.hasOwn(Svod.data.scenarios,x.path[1]))||(['theme','collapsed','active'].includes(x.path[0])&&x.path.length===1)||(x.path[0]==='multirole'&&x.path.length>=1))&&x.path.every(k=>typeof k==='string'&&k.length<300&&!['__proto__','constructor','prototype'].includes(k))&&(!x.kind||x.kind==='member'&&typeof x.member==='string'));
  }
  function read() {
    let raw,rawText=null;const warningsBefore=repairWarnings.length;
    try {rawText=localStorage.getItem(KEY);raw=JSON.parse(rawText||'null');}catch(_){raw=null;if(rawText)repairWarnings.push('database.json');}
    let seed=raw?.format==='operations-v3' ? cleanDB(raw.origin) : cleanDB(raw);
    let operations=raw?.format==='operations-v3'&&Array.isArray(raw.commits)?raw.commits:[];
    const union=new Map(operations.filter(validCommit).map(x=>[x.id,x]));
    try {
      for(let i=0;i<localStorage.length;i++) { const key=localStorage.key(i);if(key?.startsWith(JOURNAL)){try{const op=JSON.parse(localStorage.getItem(key));if(validCommit(op))union.set(op.id,op);else repairWarnings.push(key);}catch(_){repairWarnings.push(key);}} }
    } catch(_){/* Minimal file:// storage implementations may not expose enumeration. */}
    operations=[...union.values()];
    if(repairWarnings.length>warningsBefore&&rawText&&!recoveryRaw)recoveryRaw=rawText;
    return {origin:seed,commits:operations,db:materialize(seed,operations)};
  }
  function notify(kind) { for(const listener of listeners)listener({kind,error,conflicts:db.conflicts||[]}); }
  function sync() { const active=db?.active;const loaded=read(); origin=loaded.origin;commits=loaded.commits;db=loaded.db;if(active&&Object.hasOwn(db.scenarios,active))db.active=active;baseline=clone(db);notify('sync');return db; }
  function save() {
    error=null;
    Svod.companyData?.syncCatalog(db);
    // Normalize legacy template fields before the diff; no writes happen on reads/renders.
    for(const id of Object.keys(db.scenarios)) { db.scenarios[id].resumeDesign=migrateDesign(db.scenarios[id].resumeDesign);db.scenarios[id].versions=db.scenarios[id].versions.map(v=>({...v,id:v.id||'resume-'+uid(),design:v.design?migrateDesign(v.design):undefined})); }
    for(const [scenarioId,state] of Object.entries(db.scenarios))if(!validate(state)||!validateModels(state)){
      error={code:'VALIDATION',message:'Некорректные поля или связи данных. Ввод сохранён в текущем окне.',scenarioId};notify('error');return false;
    }
    const changes=diff(baseline,db);
    if(!changes.length)return persistent;
    const latest=read();
    const collision=changes.find(x=>!same(currentValue(latest.db,x),x.before)&&!same(currentValue(latest.db,x),x.value));
    if(collision) { error={code:'CONFLICT',message:'Эта запись изменилась в другой вкладке. Твой ввод сохранён в текущем окне. Обнови данные и повтори действие.',path:collision.path.join('.')};notify('conflict');return false; }
    const commit={id:uid(),at:now(),order:Math.max(0,...latest.commits.map(x=>x.order||0))+1,changes};
    for(const change of changes)apply(latest.db,change);
    const nextCommits=[...latest.commits,commit];
    try {
      if(recoveryRaw&&!recoveryRecorded){localStorage.setItem('svod.recovery.v3.'+uid(),recoveryRaw);recoveryRecorded=true;}
      // Unique immutable journal keys cannot overwrite another tab, even if snapshots race.
      localStorage.setItem(JOURNAL+commit.id,JSON.stringify(commit));
      localStorage.setItem(KEY,JSON.stringify({format:'operations-v3',version:SCHEMA,origin:latest.origin,commits:nextCommits}));
      persistent=true;
    } catch(_) { persistent=false;error={code:'STORAGE',message:'Не удалось сохранить данные: хранилище недоступно или заполнено. Скачай резервную копию.'};notify('error');return false; }
    const selectedScenario=db.active;origin=latest.origin;commits=nextCommits;db=materialize(origin,commits);db.active=selectedScenario;baseline=clone(db);notify('change');return true;
  }
  const loaded=read();origin=loaded.origin;commits=loaded.commits;db=loaded.db;baseline=clone(db);
  try{const selected=sessionStorage.getItem('svod.active');if(Object.hasOwn(db.scenarios,selected)){db.active=selected;baseline.active=selected;}}catch(_){}
  try { if(!localStorage.getItem(KEY))localStorage.setItem(KEY,JSON.stringify({format:'operations-v3',version:SCHEMA,origin,commits})); } catch(_){persistent=false;}
  Svod.state={
    get:()=>db.scenarios[db.active],save,sync,db:()=>db,scenario:()=>Svod.data.scenarios[db.active],persistent:()=>persistent,lastError:()=>error,repairWarnings:()=>[...new Set(repairWarnings)],
    subscribe(listener){listeners.add(listener);return()=>listeners.delete(listener);},
    transact(mutate,scenarioId=db.active){ sync();const previous=clone(db);try{mutate(db.scenarios[scenarioId],db);return save();}catch(error){db=previous;baseline=clone(previous);throw error;} },
    changeScenario(id){if(Object.hasOwn(Svod.data.scenarios,id)){save();db.active=id;baseline.active=id;try{sessionStorage.setItem('svod.active',id);}catch(_){}notify('scenario');}},
    reset(){db.scenarios[db.active]=extendedDefaults(db.active);return save();},
    export(){return JSON.stringify({product:'SVOD',version:1,schemaVersion:SCHEMA,scenario:db.active,exportedAt:now(),appearance:{theme:db.theme},state:db.scenarios[db.active]},null,2);},
    import(payload){
      if(!payload||payload.product!=='SVOD'||payload.version!==1||payload.schemaVersion>SCHEMA||payload.state?.schemaVersion>SCHEMA||!Object.hasOwn(Svod.data.scenarios,payload.scenario)||!payload.state||typeof payload.state!=='object'||Array.isArray(payload.state))throw new Error('Файл не соответствует формату СВОД.');
      const added=['resumeDesign','calendarPeriod','assessmentAttempts'];
      if(!Object.keys(defaults(payload.scenario)).filter(k=>!added.includes(k)).every(k=>Object.hasOwn(payload.state,k)))throw new Error('В резервной копии не хватает обязательных данных СВОД.');
      if(payload.appearance&&!['light','dark','system'].includes(payload.appearance.theme))throw new Error('Некорректная тема интерфейса.');
      const candidate=sanitize(payload.state,payload.scenario,true),previous=clone(db);
      db.scenarios[payload.scenario]=candidate;db.active=payload.scenario;if(payload.appearance)db.theme=payload.appearance.theme;
      if(!save()){db=previous;throw new Error(error?.message||'Не удалось сохранить импорт.');}
    },
    toggle(key,id){const a=db.scenarios[db.active][key];if(!Array.isArray(a))return false;const i=a.indexOf(id);if(i<0)a.push(id);else a.splice(i,1);save();return i<0;},
    resolveConflict(id,keepIncoming){const conflict=db.conflicts.find(x=>x.id===id);if(!conflict)return false;const changes=clone(conflict.changes);sync();if(keepIncoming)for(const change of changes)apply(db,change);db.scenarios[db.active].commandReceipts['conflict-'+id]={resolvedAt:now(),incoming:keepIncoming};return save();}
  };
})();
