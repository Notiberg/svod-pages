/* Form drafts are separate from committed domain data. No binary values are stored. */
(function (global) {
  'use strict';
  const Svod = global.Svod = global.Svod || {};
  const PREFIX = 'svod.drafts.v2:';
  const uuid = () => global.crypto?.randomUUID?.() || Date.now().toString(36) + '-' + Math.random().toString(36).slice(2);
  const clone = value => JSON.parse(JSON.stringify(value));
  const fingerprint = value => JSON.stringify(Object.keys(value || {}).sort().map(key => [key, value[key]]));
  const knownForms = new Set(['resume-form', 'profile-form', 'task-form', 'preferences-form', 'version-form', 'chat-form', 'assessment-form']);
  const validValues = values => values && typeof values === 'object' && !Array.isArray(values) && Object.keys(values).length <= 200 && Object.entries(values).every(([key, value]) => !['__proto__', 'prototype', 'constructor'].includes(key) && key.length <= 120 && (typeof value === 'string' && value.length <= 20000 || typeof value === 'boolean' || Array.isArray(value) && value.length <= 100 && value.every(item => typeof item === 'string' && item.length <= 1000)));
  /**
   * A branch belongs to one page instance. Different tabs never overwrite each other's key.
   * A save/discard acknowledges exact revisions only; a newer competing draft is retained.
   * @param {Storage} storage
   */
  function createDraftStore(storage, options = {}) {
    const client = options.clientId || uuid();
    const now = options.now || (() => Date.now());
    const memory = new Map(), observed = new Map(), unpersisted = new Set();
    let persistent = true;
    const namespace = (scenario, name) => PREFIX + encodeURIComponent(scenario) + ':' + encodeURIComponent(name) + ':';
    const ref = record => record.client + ':' + record.seq;
    function records(scenario, name) {
      const prefix = namespace(scenario, name), result = new Map();
      try {
        for (let i = 0; i < storage.length; i++) {
          const key = storage.key(i); if (!key?.startsWith(prefix)) continue;
          try {
            const record = JSON.parse(storage.getItem(key));
            if (record && record.version === 2 && record.scenario === scenario && record.name === name && typeof record.client === 'string' && Number.isInteger(record.seq) && record.seq > 0 && Number.isFinite(record.updatedAt) && ['draft', 'saved', 'discarded'].includes(record.status) && validValues(record.values) && Array.isArray(record.resolved) && record.resolved.every(item => typeof item === 'string')) result.set(key, record);
          } catch (_) { /* A malformed branch does not invalidate other drafts. */ }
        }
      } catch (_) { persistent = false; }
      for (const [key, record] of memory) if (key.startsWith(prefix)) result.set(key, record);
      return [...result.values()];
    }
    function info(scenario, name) {
      const all = records(scenario, name), resolved = new Set(all.flatMap(record => record.resolved));
      const active = all.filter(record => record.status === 'draft' && !resolved.has(ref(record))).sort((a, b) => b.updatedAt - a.updatedAt || b.seq - a.seq || b.client.localeCompare(a.client));
      const unique = new Set(active.map(record => fingerprint(record.values)));
      return { persistent: persistent && unpersisted.size === 0, conflict: unique.size > 1, alternatives: active.map(record => ({ id: ref(record), values: clone(record.values), updatedAt: record.updatedAt })), record: active[0] || null };
    }
    function read(scenario, name) {
      const current = info(scenario, name);
      if (!current.record) return null;
      const same = current.alternatives.filter(item => fingerprint(item.values) === fingerprint(current.record.values)).map(item => item.id);
      observed.set(namespace(scenario, name), same);
      return clone(current.record.values);
    }
    function put(scenario, name, values, status, explicitRefs) {
      if (!validValues(values)) throw new TypeError('Черновик содержит неподдерживаемые значения. Файлы сохраняются отдельно.');
      const prefix = namespace(scenario, name), key = prefix + client;
      const own = records(scenario, name).find(record => record.client === client);
      const next = { version: 2, scenario, name, client, seq: (own?.seq || 0) + 1, updatedAt: now(), status, values: clone(values), resolved: [...new Set([...(own?.resolved || []), ...(explicitRefs || [])])].slice(-300) };
      // Commit to memory first. If the browser denies storage, the input remains recoverable
      // within this page and beforeunload protection is enabled by the controller.
      memory.set(key, next);
      try { storage.setItem(key, JSON.stringify(next)); unpersisted.delete(key); persistent = unpersisted.size === 0; } catch (_) { unpersisted.add(key); persistent = false; }
      return info(scenario, name);
    }
    function write(scenario, name, values) {
      const own = records(scenario, name).find(record => record.client === client && record.status === 'draft');
      if (own && fingerprint(own.values) === fingerprint(values)) return info(scenario, name);
      // Continue the exact revision restored into this form (including after reload).
      // A concurrent revision not observed by read() remains a separate branch.
      return put(scenario, name, values, 'draft', observed.get(namespace(scenario, name)) || []);
    }
    function clear(scenario, name, disposition = 'saved') {
      const own = records(scenario, name).find(record => record.client === client);
      const refs = [...(observed.get(namespace(scenario, name)) || []), ...(own ? [ref(own)] : [])];
      return put(scenario, name, {}, disposition === 'discarded' ? 'discarded' : 'saved', refs);
    }
    function choose(scenario, name, id) {
      const selected = info(scenario, name).alternatives.find(item => item.id === id);
      if (!selected) return null;
      observed.set(namespace(scenario, name), [id]);
      put(scenario, name, selected.values, 'draft', [id]);
      return clone(selected.values);
    }
    function resolve(scenario, name, values) {
      const refs = info(scenario, name).alternatives.map(item => item.id);
      return put(scenario, name, values, 'draft', refs);
    }
    function archive(scenario, name, values, label = 'Черновик перед заменой') {
      if (!validValues(values)) throw new TypeError('Некорректный черновик.');
      const item = { version: 1, id: uuid(), scenario, name, values: clone(values), label: String(label).slice(0, 120), createdAt: now() };
      const key = PREFIX + 'archive:' + encodeURIComponent(scenario) + ':' + encodeURIComponent(name) + ':' + item.id;
      memory.set(key, item);
      try { storage.setItem(key, JSON.stringify(item)); unpersisted.delete(key); persistent = unpersisted.size === 0; } catch (_) { unpersisted.add(key); persistent = false; }
      return clone(item);
    }
    function history(scenario, name) {
      const prefix = PREFIX + 'archive:' + encodeURIComponent(scenario) + ':' + encodeURIComponent(name) + ':';
      const values = new Map();
      try {
        for (let i = 0; i < storage.length; i++) {
          const key = storage.key(i); if (!key?.startsWith(prefix)) continue;
          try { const item = JSON.parse(storage.getItem(key)); if (item?.version === 1 && validValues(item.values) && item.scenario === scenario && item.name === name) values.set(key, item); } catch (_) { /* Isolate damaged archive. */ }
        }
      } catch (_) { persistent = false; }
      for (const [key, value] of memory) if (key.startsWith(prefix)) values.set(key, value);
      return [...values.values()].sort((a, b) => b.createdAt - a.createdAt || b.id.localeCompare(a.id)).map(clone);
    }
    function clearScenario(scenario) {
      const keys = new Set([...memory.keys()]);
      try { for (let i = 0; i < storage.length; i++) { const key = storage.key(i); if (key?.startsWith(PREFIX)) keys.add(key); } } catch (_) { persistent = false; }
      for (const key of keys) {
        let item = memory.get(key);
        if (!item) { try { item = JSON.parse(storage.getItem(key)); } catch (_) { continue; } }
        if (item?.scenario !== scenario) continue;
        memory.delete(key); unpersisted.delete(key); try { storage.removeItem(key); } catch (_) { persistent = false; }
      }
      for (const key of observed.keys()) if (key.startsWith(PREFIX + encodeURIComponent(scenario) + ':')) observed.delete(key);
    }
    return { read, write, clear, choose, resolve, archive, history, clearScenario, info, persistent: () => persistent && unpersisted.size === 0, hasUnpersisted: () => unpersisted.size > 0, client };
  }
  function validDate(value) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
    const date = new Date(value + 'T12:00:00Z');
    return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
  }
  function file(file, options = {}) {
    if (!file) return options.required ? 'Выбери файл.' : '';
    const extensions = options.extensions || ['pdf', 'docx', 'txt'];
    if (!extensions.some(ext => file.name?.toLowerCase().endsWith('.' + ext))) return 'Допустимые форматы: ' + extensions.map(ext => ext.toUpperCase()).join(', ') + '.';
    if (!Number.isFinite(file.size) || file.size < 0 || file.size > (options.maxBytes || 10 * 1024 * 1024)) return 'Файл слишком большой. Максимум ' + Math.round((options.maxBytes || 10 * 1024 * 1024) / 1024 / 1024) + ' МБ.';
    return '';
  }
  function normalizePhone(value) {
    const text = String(value || '').trim();
    if (!text) return '';
    let digits = text.replace(/\D/g, '');
    if (digits.length === 11 && digits[0] === '8') digits = '7' + digits.slice(1);
    return '+' + digits;
  }
  function fieldMessage(input) {
    const value = String(input.value || '').trim(), type = input.type || 'text';
    if (input.disabled || ['submit', 'button', 'reset', 'hidden'].includes(type)) return '';
    if (input.required && (type === 'checkbox' ? !input.checked : type === 'radio' ? !Array.from(input.form?.elements || [input]).some(item => item.name === input.name && item.checked) : !value)) return type === 'radio' ? 'Выбери один вариант ответа.' : 'Заполни обязательное поле.';
    if (!value && type !== 'file') return '';
    if (input.dataset?.maxTags && value.split(',').map(x=>x.trim()).filter(Boolean).length > Number(input.dataset.maxTags)) return 'Оставь до '+input.dataset.maxTags+' самых важных навыков.';
    if (input.dataset?.telegram !== undefined && !/^@?[a-zA-Z][a-zA-Z0-9_]{4,31}$/.test(value)) return 'Укажи Telegram в формате @username (5–32 символа).';
    if (input.dataset?.resumeYear !== undefined && !/^(19|20|21)\d{2}$/.test(value)) return 'Укажи год из четырёх цифр, например 2026.';
    if (type === 'email' && (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value) || value.length > 254)) return 'Укажи почту в формате name@example.com.';
    if (type === 'tel' && (!/^[+\d\s().-]+$/.test(value) || !/^\+?\d{10,15}$/.test(value.replace(/[\s().-]/g, '')))) return 'Укажи от 10 до 15 цифр, например +7 999 123-45-67.';
    if (type === 'url') {
      try { const url = new URL(value); if (!['https:', 'http:'].includes(url.protocol) || !url.hostname || url.username || url.password) throw new Error(); } catch (_) { return 'Укажи полную ссылку, начинающуюся с https:// или http://.'; }
    }
    if (type === 'date' && (!validDate(value) || input.min && value < input.min || input.max && value > input.max)) return 'Укажи существующую дату' + (input.min && input.max ? ` от ${input.min} до ${input.max}` : '') + '.';
    if (type === 'file') return file(input.files?.[0], { required: input.required, extensions: input.dataset?.extensions?.split(',') || undefined, maxBytes: Number(input.dataset?.maxBytes) || undefined });
    const max = Number(input.getAttribute?.('maxlength'));
    if (max > 0 && value.length > max) return `Сократи текст до ${max} символов.`;
    if (input.dataset?.oneWord !== undefined && /\s/.test(value)) return 'Ответь одним словом, без пробелов.';
    return '';
  }
  function fieldGroup(input) {
    return input.type === 'radio' ? input.closest('fieldset') || input.parentElement : input.closest('.form-row') || input.parentElement;
  }
  function setError(input, message) {
    if (!input) return;
    const group = fieldGroup(input); if (!group) return;
    if (!input.id) input.id = 'field-' + uuid();
    const id = (input.type === 'radio' ? 'field-' + input.name.replace(/[^\w-]/g, '-') : input.id) + '-error';
    let error = group.querySelector('#' + id);
    if (!error) { error = global.document.createElement('p'); error.id = id; error.className = 'field-error form-error'; error.setAttribute('role', 'alert'); group.append(error); }
    error.textContent = message || ''; error.hidden = !message;
    const controls = input.type === 'radio' ? Array.from(input.form?.elements || [input]).filter(item => item.name === input.name) : [input];
    controls.forEach(control => {
      control.setAttribute('aria-invalid', String(!!message));
      const ids = new Set((control.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean));
      if (message) ids.add(id); else ids.delete(id);
      if (ids.size) control.setAttribute('aria-describedby', [...ids].join(' ')); else control.removeAttribute('aria-describedby');
    });
  }
  function validate(form) {
    let first = null;
    const checked = new Set();
    for (const input of Array.from(form.elements || [])) {
      if (input.tagName && !['INPUT', 'SELECT', 'TEXTAREA'].includes(input.tagName) || input.disabled || ['submit', 'button', 'reset', 'hidden'].includes(input.type)) continue;
      if (input.type === 'radio' && checked.has(input.name)) continue;
      if (input.type === 'radio') checked.add(input.name);
      const message = fieldMessage(input); setError(input, message); if (message && !first) first = input;
    }
    if (first) { first.focus({ preventScroll: false }); return false; }
    return true;
  }
  function capture(form) {
    const values = Object.create(null), groups = new Map();
    for (const input of Array.from(form.elements || [])) {
      if (!input.name || input.disabled || ['submit', 'button', 'reset', 'file'].includes(input.type) || ['__proto__', 'prototype', 'constructor'].includes(input.name)) continue;
      if (!groups.has(input.name)) groups.set(input.name, []); groups.get(input.name).push(input);
    }
    for (const [name, controls] of groups) {
      const first = controls[0];
      if (first.type === 'checkbox') values[name] = controls.filter(input => input.checked).map(input => input.value);
      else if (first.type === 'radio') values[name] = controls.find(input => input.checked)?.value || '';
      else if (first.multiple) values[name] = Array.from(first.selectedOptions || []).map(option => option.value);
      else values[name] = String(first.value || '');
    }
    return values;
  }
  function apply(form, values) {
    if (!values) return;
    Svod.resumeFields?.hydrate(form, values);
    for (const input of Array.from(form.elements || [])) {
      if (!Object.hasOwn(values, input.name) || input.type === 'file') continue;
      const value = values[input.name];
      if (input.type === 'checkbox') input.checked = Array.isArray(value) ? value.includes(input.value) : !!value;
      else if (input.type === 'radio') input.checked = value === input.value;
      else if (input.multiple) Array.from(input.options || []).forEach(option => { option.selected = Array.isArray(value) && value.includes(option.value); });
      else input.value = String(value ?? '');
      if (input.type === 'range' && input.id) { const output = form.querySelector(`output[for="${input.id}"]`); if (output) output.value = input.value; }
    }
  }
  let getScenario = () => Svod.state?.db().active || 'junior';
  let onStatus = null, store = null, mounted = false;
  const pending = new Map(), timers = new Map(), activeForms = new Map();
  function draftStore() {
    if (!store) {
      let storage;
      try { storage = global.localStorage; } catch (_) { storage = null; }
      store = createDraftStore(storage || { get length() { throw new Error('Storage unavailable'); }, setItem() { throw new Error('Storage unavailable'); } });
    }
    return store;
  }
  const formName = form => form.dataset.draftKey || (form.id === 'assessment-form' ? 'assessment:' + form.dataset.offer : form.id);
  const identity = (scenario, name) => scenario + '\n' + name;
  function status(form, state, message) {
    if (!form) return;
    form.dataset.saveState = state;
    let output = form.querySelector('[data-draft-status]');
    if (!output) {
      output = global.document.createElement('output'); output.className = 'draft-status save-state' + ((form.id === 'chat-form' || form.classList.contains('chat-composer')) ? ' chat-draft-status' : ''); output.dataset.draftStatus = ''; output.setAttribute('role', 'status'); output.setAttribute('aria-live', 'polite'); form.append(output);
    }
    output.dataset.state = state; output.textContent = (form.id === 'chat-form' || form.classList.contains('chat-composer')) && ['draft','saved','pending'].includes(state) ? (state === 'draft' ? 'Черновик сохранён' : '') : message;
    if (state !== 'conflict') form.querySelector('.draft-conflicts')?.remove();
    onStatus?.({ form, state, message });
  }
  function storedStatus(form, info) {
    if (!info.persistent) return status(form, 'error', 'Черновик остаётся в открытой вкладке: хранилище недоступно. Не закрывай её до сохранения копии.');
    if (info.conflict) {
      status(form, 'conflict', 'В другой вкладке есть другая версия черновика. Твой ввод сохранён отдельно; выбери, с чем продолжить.');
      if (form) {
        form.querySelector('.draft-conflicts')?.remove();
        const controls = global.document.createElement('details'); controls.className = 'draft-conflicts';
        const summary = global.document.createElement('summary'); summary.textContent = 'Выбрать черновик'; controls.append(summary);
        const mine = global.document.createElement('button'); mine.type = 'button'; mine.dataset.draftKeep = ''; mine.textContent = 'Продолжить с моим вводом'; controls.append(mine);
        const seen = new Set();
        info.alternatives.forEach((item, index) => {
          const hash = fingerprint(item.values); if (seen.has(hash)) return; seen.add(hash);
          const button = global.document.createElement('button'); button.type = 'button'; button.dataset.draftChoose = item.id;
          const preview = Object.values(item.values).find(value => typeof value === 'string' && value.trim()) || '';
          button.textContent = `Вариант ${index + 1}: ${String(preview).slice(0, 45)} · ${new Date(item.updatedAt).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' })}`;
          controls.append(button);
        });
        form.append(controls);
      }
      return;
    }
    status(form, 'draft', 'Черновик сохранён на этом устройстве. Отправка и сохранение версии — отдельные действия.');
  }
  function queue(form) {
    if (!form || !knownForms.has(form.id) && !form.dataset.draftKey) return;
    const scenario = form.dataset.draftScenario || getScenario(), name = formName(form), id = identity(scenario, name);
    const value = { scenario, name, values: capture(form), form };
    pending.set(id, value); activeForms.set(id, form);
    clearTimeout(timers.get(id)); status(form, 'pending', 'Сохраняем черновик…');
    timers.set(id, setTimeout(() => flush(id), 180));
  }
  function flush(only = '') {
    for (const [id, item] of pending) {
      if (only && only !== id) continue;
      clearTimeout(timers.get(id)); timers.delete(id);
      const info = draftStore().write(item.scenario, item.name, item.values); pending.delete(id); storedStatus(item.form, info);
    }
  }
  function read(name, scenario = getScenario()) {
    const queued = pending.get(identity(scenario, name));
    return queued ? clone(queued.values) : draftStore().read(scenario, name);
  }
  function clear(nameOrForm, disposition = 'saved', scenario = getScenario()) {
    const name = typeof nameOrForm === 'string' ? nameOrForm : formName(nameOrForm);
    const id = identity(scenario, name);
    clearTimeout(timers.get(id)); timers.delete(id); pending.delete(id);
    const info = draftStore().clear(scenario, name, disposition);
    const form = typeof nameOrForm === 'string' ? activeForms.get(id) : nameOrForm;
    if (!info.persistent || info.conflict || info.record) storedStatus(form, info); else status(form, 'saved', disposition === 'discarded' ? 'Черновик отменён. Сохранённые данные не изменены.' : 'Сохранено. Несохранённых изменений нет.');
  }
  function restore(form) {
    const name = formName(form), scenario = getScenario(), id = identity(scenario, name);
    form.dataset.draftScenario = scenario; activeForms.set(id, form);
    const values = read(name, scenario);
    if (values) { apply(form, values); storedStatus(form, draftStore().info(scenario, name)); }
    else status(form, 'saved', (form.id === 'chat-form' || form.classList.contains('chat-composer')) ? '' : 'Несохранённых изменений нет.');
    return values;
  }
  function prepareFields(form) {
    form.noValidate = true;
    for (const input of Array.from(form.elements || [])) {
      if (!['INPUT', 'SELECT', 'TEXTAREA'].includes(input.tagName)) continue;
      if (input.required) {
        input.setAttribute('aria-required', 'true');
        const group = fieldGroup(input);
        if (!input.id) input.id = 'field-' + uuid();
        let label = input.type === 'radio' ? group?.querySelector('legend') : form.querySelector(`label[for="${input.id}"]`);
        if (!label && input.getAttribute('aria-label')) {
          label = global.document.createElement('label'); label.className = 'field-label'; label.htmlFor = input.id; label.textContent = input.getAttribute('aria-label'); input.before(label);
        }
        if (label && !label.querySelector('.field-required')) { const mark = global.document.createElement('span'); mark.className = 'field-required'; mark.textContent = ' (обязательно)'; label.append(mark); }
      }
      const hint = input.closest('.form-row')?.querySelector('small');
      if (hint) {
        if (!hint.id) hint.id = (input.id || 'field-' + uuid()) + '-hint';
        const ids = new Set((input.getAttribute('aria-describedby') || '').split(/\s+/).filter(Boolean)); ids.add(hint.id); input.setAttribute('aria-describedby', [...ids].join(' '));
      }
    }
  }
  function mount(root = global.document) {
    if (!root) return;
    for (const form of root.querySelectorAll('form')) {
      if (!knownForms.has(form.id) && !form.dataset.draftKey) continue;
      prepareFields(form);
      if (!form.dataset.draftMounted) { restore(form); form.dataset.draftMounted = 'true'; }
    }
    if (mounted) return;
    mounted = true;
    const saveInput = event => { const input = event.target, form = input?.form; if (!form) return; queue(form); if (input.getAttribute?.('aria-invalid') === 'true') setError(input, fieldMessage(input)); };
    global.document.addEventListener('click', event => {
      const button = event.target.closest?.('[data-draft-choose], [data-draft-keep]');
      const form = button?.closest('form'); if (!form) return;
      event.preventDefault();
      const scenario = form.dataset.draftScenario || getScenario(), name = formName(form);
      flush();
      const info = draftStore().info(scenario, name);
      // Resolving a conflict preserves all alternatives in the recoverable history first.
      info.alternatives.forEach(item => draftStore().archive(scenario, name, item.values, 'Перед выбором черновика вкладки'));
      const selected = button.dataset.draftChoose ? info.alternatives.find(item => item.id === button.dataset.draftChoose)?.values : capture(form);
      if (!selected) return;
      const next = draftStore().resolve(scenario, name, selected); apply(form, selected); storedStatus(form, next);
      form.dispatchEvent(new Event('draftrestored', { bubbles: true }));
    });
    global.document.addEventListener('input', saveInput);
    global.document.addEventListener('change', saveInput);
    global.addEventListener?.('hashchange', () => flush());
    global.addEventListener?.('pagehide', () => flush());
    global.addEventListener?.('beforeunload', event => { flush(); if (draftStore().hasUnpersisted()) { event.preventDefault(); event.returnValue = ''; } });
    global.addEventListener?.('storage', event => {
      if (!event.key?.startsWith(PREFIX)) return;
      for (const [id, form] of activeForms) {
        if (!form.isConnected) { activeForms.delete(id); continue; }
        const scenario = form.dataset.draftScenario, name = formName(form), info = draftStore().info(scenario, name);
        if (info.conflict) storedStatus(form, info);
      }
    });
  }
  Svod.forms = {
    createDraftStore, validDate, file, normalizePhone, fieldMessage, setError, validate, capture, apply,
    configure(options = {}) { if (options.scenario) getScenario = options.scenario; if (options.onStatus) onStatus = options.onStatus; if (options.storage) store = createDraftStore(options.storage, options); },
    mount, restore, read, queue, flush, clear,
    info(name, scenario = getScenario()) { return draftStore().info(scenario, name); },
    choose(form, id) { flush(); const value = draftStore().choose(form.dataset.draftScenario || getScenario(), formName(form), id); if (value) { apply(form, value); storedStatus(form, draftStore().info(form.dataset.draftScenario || getScenario(), formName(form))); } return value; },
    archive(form, label = 'Черновик перед заменой') {
      if (!form) return null; queue(form); flush();
      return draftStore().archive(form.dataset.draftScenario || getScenario(), formName(form), capture(form), label);
    },
    history(name, scenario = getScenario()) { return draftStore().history(scenario, name); },
    restoreArchive(form, id) {
      const scenario = form.dataset.draftScenario || getScenario(), name = formName(form);
      const item = draftStore().history(scenario, name).find(item => item.id === id); if (!item) return null;
      draftStore().archive(scenario, name, capture(form), 'Перед восстановлением черновика');
      apply(form, item.values); queue(form); flush(); return clone(item.values);
    },
    clearScenario(scenario = getScenario()) {
      for (const [id, item] of pending) if (item.scenario === scenario) { clearTimeout(timers.get(id)); timers.delete(id); pending.delete(id); }
      draftStore().clearScenario(scenario);
    },
    prepareReplacement(form, label = 'Перед загрузкой версии резюме') {
      if (!form) return null; queue(form); flush();
      draftStore().archive(form.dataset.draftScenario || getScenario(), formName(form), capture(form), label);
      return clone(capture(form));
    }
  };
})(typeof window === 'undefined' ? globalThis : window);
